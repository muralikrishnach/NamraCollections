package com.jayam.impactapp.database;

import java.util.ArrayList;

import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.LucDemandsDO;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class LUCDemandsBL extends BaseBusinessLayer<LucDemandsDO> {

    private ArrayList<LucDemandsDO> alregulardemnads;

    public void InsertArrayList(ArrayList<LucDemandsDO> alregulardemnads) {
	this.alregulardemnads = alregulardemnads;
	for (int i = 0; i < alregulardemnads.size(); i++) {
	    LucDemandsDO demandsDO = alregulardemnads.get(i);
	    Insert(demandsDO);
	}
    }

    @Override
    public boolean Insert(BaseDO object) {
	// TODO Auto-generated method stub
	LucDemandsDO parametrsDO = (LucDemandsDO) object;
	try {
	    DatabaseHelper.openDataBase();
	} catch (Exception e) {
	}
	ContentValues values = new ContentValues();
	values.put("CNo", parametrsDO.CNo);
	values.put("CName", parametrsDO.CName);
	values.put("GNo", parametrsDO.GNo);
	values.put("GName", parametrsDO.GName);
	values.put("MMI_Code", parametrsDO.MMI_Code);
	values.put("MName", parametrsDO.MName);
	values.put("DemandDate", parametrsDO.DemandDate);
	values.put("LoanID", parametrsDO.LoanID);
	values.put("LoanAmount", parametrsDO.LoanAmount);
	values.put("DisbDate", parametrsDO.DisbDate);
	values.put("PurposeID", parametrsDO.PurposeID);
	values.put("Purpose", parametrsDO.Purpose);
	values.put("SittingOrder", parametrsDO.SittingOrder);
	values.put("SO", parametrsDO.SO);
	try {
	    SQLiteDatabase _database = DatabaseHelper.openDataBase();
	    _database.insert("LUCDemands", null, values);
	} catch (Exception e) {
	}
	return false;
    }

    public boolean isAvailable(String date) {
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	String dateC = "";
	try {
	    c = _database.rawQuery("select DemandDate from LUCDemands", null);

	    c.moveToFirst();
	    dateC = c.getString(0);
	    Log.e("dateC", "" + dateC);
	    Log.e("date", "" + date);
	} catch (Exception e) {

	}

	if (dateC.equalsIgnoreCase(date)) {
	    return true;
	} else {
	    return false;
	}

    }

    public String getrowCount() {
	String totalODAmount = null;
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	try {
	    c = _database.rawQuery("select count (*)  from LUCDemands", null);
	    if (c.moveToFirst()) {
		do {
		    try {
			totalODAmount = c.getString(0);
		    } catch (Exception e) {
			Log.e("exception", "while getting from server");
		    }
		} while (c.moveToNext());
		c.close();
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
	return totalODAmount;

	// select SUM(ODAmount ) from RegularDemands
    }

    public ArrayList<LucDemandsDO> SelectAllCenters() {
	ArrayList<LucDemandsDO> vecRegularDemands = new ArrayList<LucDemandsDO>();
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	try {
	    c = _database.rawQuery("select DISTINCT CNo,CName from LUCDemands", null);
	    Log.e("query", "select DISTINCT CNo,CName from LUCDemands");
	    if (vecRegularDemands != null) {
		vecRegularDemands.clear();
	    }

	    if (c.moveToFirst()) {
		do {
		    LucDemandsDO obj = new LucDemandsDO();
		    obj.CNo = c.getString(0);
		    obj.CName = c.getString(1);
		    vecRegularDemands.add(obj);
		} while (c.moveToNext());

		c.close();
	    }
	} catch (Exception e) {
	    Log.e("error", "getting from database");
	    e.printStackTrace();
	}

	_database.close();
	return vecRegularDemands;
    }

    public ArrayList<LucDemandsDO> SelectAllGroups(String CNo) {
	ArrayList<LucDemandsDO> vecRegularDemands = new ArrayList<LucDemandsDO>();
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	try {
	    c = _database.rawQuery("select DISTINCT GNo,GName from LUCDemands where CNo='" + CNo + "'", null);
	    Log.e("query", "select DISTINCT GNo,GName from LUCDemands where CNo='" + CNo + "'");
	    if (vecRegularDemands != null) {
		vecRegularDemands.clear();
	    }

	    if (c.moveToFirst()) {
		do {
		    LucDemandsDO obj = new LucDemandsDO();
		    obj.GNo = c.getString(0);
		    obj.GName = c.getString(1);
		    vecRegularDemands.add(obj);
		} while (c.moveToNext());
		c.close();
	    }
	} catch (Exception e) {
	    Log.e("error", "getting from database");
	    e.printStackTrace();
	}

	_database.close();
	return vecRegularDemands;
    }

    public ArrayList<LucDemandsDO> SelectAllMembers(String GNo) {
	ArrayList<LucDemandsDO> vecRegularDemands = new ArrayList<LucDemandsDO>();
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	try {
	    c = _database.rawQuery(
		    "select DISTINCT MMI_Code,MName from LUCDemands where GNo='" + GNo + "' order by SittingOrder asc",
		    null);
	    Log.e("query",
		    "select DISTINCT MMI_Code,MName from LUCDemands where GNo='" + GNo + "' order by SittingOrder asc");
	    if (vecRegularDemands != null) {
		vecRegularDemands.clear();
	    }

	    if (c.moveToFirst()) {
		do {
		    LucDemandsDO obj = new LucDemandsDO();
		    obj.MMI_Code = c.getString(0);
		    obj.MName = c.getString(1);
		    vecRegularDemands.add(obj);
		} while (c.moveToNext());

		c.close();
	    }
	} catch (Exception e) {
	    Log.e("error", "getting from database");
	    e.printStackTrace();
	}

	_database.close();
	return vecRegularDemands;
    }

    public ArrayList<LucDemandsDO> SelectMemberDetails(String MNo) {
	ArrayList<LucDemandsDO> vecRegularDemands = new ArrayList<LucDemandsDO>();
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	try {
	    c = _database.rawQuery("select * from LUCDemands where MMI_Code='" + MNo + "'", null);
	    Log.e("query", "select * from LUCDemands where MMI_Code='" + MNo + "'");
	    if (vecRegularDemands != null) {
		vecRegularDemands.clear();
	    }

	    if (c.moveToFirst()) {
		do {
		    LucDemandsDO obj = new LucDemandsDO();
		    obj.CNo = c.getString(0);
		    obj.CName = c.getString(1);
		    obj.GNo = c.getString(2);
		    obj.GName = c.getString(3);
		    obj.MMI_Code = c.getString(4);
		    obj.MName = c.getString(5);
		    obj.DemandDate = c.getString(6);
		    obj.LoanID = c.getString(7);
		    obj.LoanAmount = c.getString(8);
		    obj.DisbDate = c.getString(9);
		    obj.PurposeID = c.getString(10);
		    obj.Purpose = c.getString(11);
		    obj.SittingOrder = c.getString(12);
		    obj.SO = c.getString(13);
		    obj.Result = c.getString(14);
		    obj.Reason = c.getString(15);
		    obj.Remark = c.getString(16);
		    obj.Confirmed = c.getString(17);
		    vecRegularDemands.add(obj);
		} while (c.moveToNext());

		c.close();
	    }
	} catch (Exception e) {
	    Log.e("error", "getting from database");
	    e.printStackTrace();
	}

	_database.close();
	return vecRegularDemands;
    }

    public ArrayList<LucDemandsDO> SelectAllMemberConfirmed() {
	ArrayList<LucDemandsDO> vecRegularDemands = new ArrayList<LucDemandsDO>();
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	try {
	    c = _database.rawQuery("select * from LUCDemands where Confirmed='yes'", null);
	    Log.e("query", "select * from LUCDemands where Confirmed='yes'");
	    if (vecRegularDemands != null) {
		vecRegularDemands.clear();
	    }

	    if (c.moveToFirst()) {
		do {
		    LucDemandsDO obj = new LucDemandsDO();
		    obj.CNo = c.getString(0);
		    obj.CName = c.getString(1);
		    obj.GNo = c.getString(2);
		    obj.GName = c.getString(3);
		    obj.MMI_Code = c.getString(4);
		    obj.MName = c.getString(5);
		    obj.DemandDate = c.getString(6);
		    obj.LoanID = c.getString(7);
		    obj.LoanAmount = c.getString(8);
		    obj.DisbDate = c.getString(9);
		    obj.PurposeID = c.getString(10);
		    obj.Purpose = c.getString(11);
		    obj.SittingOrder = c.getString(12);
		    obj.SO = c.getString(13);
		    obj.Result = c.getString(14);
		    obj.Reason = c.getString(15);
		    obj.Remark = c.getString(16);
		    obj.Confirmed = c.getString(17);
		    vecRegularDemands.add(obj);
		} while (c.moveToNext());

		c.close();
	    }
	} catch (Exception e) {
	    Log.e("error", "getting from database");
	    e.printStackTrace();
	}

	_database.close();
	return vecRegularDemands;
    }

    public String getConfirmedCount(String GNo, String type) {
	String totalODAmount = null;
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	String query = null;
	if (type.equalsIgnoreCase("Center")) {
	    query = "SELECT COUNT(*) FROM LUCDemands where Confirmed is NULL and CNo='" + GNo + "'";
	} else if (type.equalsIgnoreCase("Group")) {
	    query = "SELECT COUNT(*) FROM LUCDemands where Confirmed is NULL and GNo='" + GNo + "'";
	} else if (type.equalsIgnoreCase("Member")) {
	    query = "SELECT COUNT(*) FROM LUCDemands where Confirmed is NULL and MMI_Code='" + GNo + "'";
	}
	try {
	    c = _database.rawQuery(query, null);
	    if (c.moveToFirst()) {
		do {
		    try {
			totalODAmount = c.getString(0);
		    } catch (Exception e) {
			Log.e("exception", "while getting from server");
		    }

		} while (c.moveToNext());
		c.close();
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
	return totalODAmount;
    }

    public String getConfirmedStatus(String MNo) {
	String totalODAmount = null;
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	String query = "SELECT Confirmed FROM LUCDemands where MMI_Code='" + MNo + "'";
	try {
	    c = _database.rawQuery(query, null);
	    if (c.moveToFirst()) {
		do {
		    try {
			totalODAmount = c.getString(0);
		    } catch (Exception e) {
			Log.e("exception", "while getting from server");
		    }

		} while (c.moveToNext());
		c.close();
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
	return totalODAmount;
    }

    public String selectConfirmedCount() {
	String totalODAmount = null;
	SQLiteDatabase _database = DatabaseHelper.openDataBase();
	Cursor c = null;
	String query = "SELECT count(*) FROM LUCDemands where Confirmed='yes'";
	Log.d("mfimo", query);
	try {
	    c = _database.rawQuery(query, null);
	    if (c.moveToFirst()) {
		do {
		    try {
			totalODAmount = c.getString(0);
		    } catch (Exception e) {
			Log.e("exception", "while getting from server");
		    }

		} while (c.moveToNext());
		c.close();
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
	return totalODAmount;
    }

    public void updateConfirm(String LUCResult, String LUCReason, String LUCRemark, String MALID) {
	SQLiteDatabase objSqliteDB = null;
	objSqliteDB = DatabaseHelper.openDataBase();
	String query = null;

	query = "UPDATE LUCDemands SET LUCResult = '" + LUCResult + "' , LUCReason ='" + LUCReason + "', LUCRemark='"
		+ LUCRemark + "', Confirmed='yes' where MMI_Code = '" + MALID + "'";
	Log.e("query", query);
	try {
	    objSqliteDB.beginTransaction();
	    SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
	    sqLiteStatement.executeInsert();
	    objSqliteDB.setTransactionSuccessful();
	    objSqliteDB.endTransaction();

	} catch (Exception e) {
	    e.printStackTrace();
	}
	if (objSqliteDB != null) {
	    objSqliteDB.close();
	}
    }

    @Override
    public boolean Update(BaseDO object) {
	// TODO Auto-generated method stub
	return false;
    }

    @Override
    public boolean Delete(BaseDO object) {
	// TODO Auto-generated method stub
	return false;
    }

    @Override
    public ArrayList SelectAll() {
	// TODO Auto-generated method stub
	return null;
    }

    public void DeleteRecord(String MNo) {
	SQLiteDatabase objSqliteDB = null;
	objSqliteDB = DatabaseHelper.openDataBase();
	String query = null;
	query = "DELETE FROM LUCDemands where MMI_Code='" + MNo + "'";
	Log.e("query", query);
	try {
	    objSqliteDB.beginTransaction();
	    SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
	    sqLiteStatement.executeInsert();
	    objSqliteDB.setTransactionSuccessful();
	    objSqliteDB.endTransaction();

	} catch (Exception e) {
	    e.printStackTrace();
	}
	if (objSqliteDB != null) {
	    objSqliteDB.close();
	}

    }

    public void Truncatetabel() {
	SQLiteDatabase objSqliteDB = null;
	objSqliteDB = DatabaseHelper.openDataBase();
	String query = null;

	query = "DELETE FROM LUCDemands";
	Log.e("query", query);
	try {
	    objSqliteDB.beginTransaction();
	    SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
	    sqLiteStatement.executeInsert();
	    objSqliteDB.setTransactionSuccessful();
	    objSqliteDB.endTransaction();

	} catch (Exception e) {
	    e.printStackTrace();
	}
	if (objSqliteDB != null) {
	    objSqliteDB.close();
	}

    }

}
