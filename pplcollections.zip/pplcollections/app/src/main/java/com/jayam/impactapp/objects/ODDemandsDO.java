package com.jayam.impactapp.objects;

public class ODDemandsDO extends BaseDO
{

	public String LatitudeCenter;
	public String LongitudeCenter;
	public String LatitudeGroup;
	public String LongitudeGroup;
	public String LatitudeMember;
	public String LongitudeMember;
	public String ProductName="";
	public String DateTime="";


	public String BranchPaymode="";
	public String TransactionID;
	public String TXNID;
	public String PaymentMode;
	public String Status;
	public String MCI_Name;
	public String MCI_Code;
	public String MGI_Name;
	public String MGI_Code;
	public String MMI_Name;
	public String MMI_Code;
	public String MLAI_ID;
	public String ODAmt;
	public String DemandDate;
	public String OSAmt = "0";
	public String SittingOrder;
	public String collectedAmt;
	public String recieptNumber;
	public String printFlag="N";
	public String DupNO="0";
	public String CollType;
	public String APFlag="N";


	public String AAdharNo;
	public String MobileNo;

}
