package com.jayam.impactapp.adapters;

import java.util.List;

import com.jayam.impactapp.NPSCenterDetails;
import com.jayam.impactapp.NPSGroups;
import com.jayam.impactapp.R;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.NPSDemandDO;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class NPSCenterAdapter extends GenericAdapter {
    private String type;

    public NPSCenterAdapter(Context context, List<? extends BaseDO> listItems, String type) {
	super(context, listItems);
	this.type = type;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
	NPSDemandDO npsDemandsDO = (NPSDemandDO) getList().get(position);
	convertView = getLayoutInflater().inflate(R.layout.center_cell, null);
	TextView tvCenterName = (TextView) convertView.findViewById(R.id.tvCenterName);
	ImageView imgConfirmed = (ImageView) convertView.findViewById(R.id.imgConfirmed);
	NPSDemandBL bl = new NPSDemandBL();
	String fullpaymnet = bl.CheckForFullpayMent(npsDemandsDO.CNo, "Center");

	if (fullpaymnet != null && fullpaymnet.equalsIgnoreCase("0")) {
	    imgConfirmed.setVisibility(View.VISIBLE);
	} else {
	    imgConfirmed.setVisibility(View.GONE);
	}

	tvCenterName.setText("" + npsDemandsDO.CName);

	Log.e("position", "" + position);
	convertView.setTag(npsDemandsDO);
	convertView.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {

		if (type.equalsIgnoreCase("center")) {
		    NPSDemandDO npsDemandsDO = (NPSDemandDO) v.getTag();
		    Intent intent = new Intent(mContext, NPSCenterDetails.class);
		    intent.putExtra("CenterName", npsDemandsDO.CName);
		    intent.putExtra("CenterCode", npsDemandsDO.CNo);
		    ((Activity) (mContext)).startActivityForResult(intent, 0);
		} else {
		    NPSDemandDO npsDemandsDO = (NPSDemandDO) v.getTag();
		    Intent intent = new Intent(mContext, NPSGroups.class);
		    intent.putExtra("CenterName", npsDemandsDO.CName);
		    intent.putExtra("CenterCode", npsDemandsDO.CNo);
		    ((Activity) (mContext)).startActivityForResult(intent, 0);
		}

	    }
	});
	return convertView;
    }

}
