package com.jayam.impactapp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.PrintListner;
import com.jayam.impactapp.common.PrintValues;
import com.jayam.impactapp.database.IntialParametrsBL;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.IntialParametrsDO;
import com.jayam.impactapp.objects.NPSDemandDO;
import com.jayam.impactapp.objects.PrintDetailsDO;
import com.jayam.impactapp.utils.PrintUtils;
import com.jayam.impactapp.utils.SharedPrefUtils;


import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NPSSummaryReports extends Base implements PrintListner
{
	private LinearLayout llAck;
	private TextView tvNPSAgentName,tvNPSTotalRnwlsAccounts,tvNPSTotalCollAccounts,tvNPSTotalRenewalAmt,tvNPSRTotCollAmt,tvNPSBalanceAmt;
	private Button  btnPrint,btnMainMenu;

	private NPSDemandBL trnsactionsBL;
	private ArrayList<NPSDemandDO> alArrayList;
	private float RenewalAmt=0,CollAmt=0;
	private String dateNow;
	ArrayList<IntialParametrsDO> alIntialParametrsDOs;
	int count=0;
	String uName;
	float BallAmt;
	private IntialParametrsBL intialParametrsBL;
	
	@Override
	public void initialize()
	{
		
		uName = SharedPrefUtils.getKeyValue(NPSSummaryReports.this, AppConstants.pref_name, AppConstants.username);
		intializeControlles();
		trnsactionsBL = new NPSDemandBL();
		alArrayList = trnsactionsBL.SelectReportsData("","Summary");
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter=  new SimpleDateFormat("dd-MM-yyyy");
		 dateNow = formatter.format(currentDate.getTime());
		tvNPSAgentName.setText(""+uName);
		tvNPSTotalRnwlsAccounts.setText(""+alArrayList.size());
		intialParametrsBL = new  IntialParametrsBL();
		alIntialParametrsDOs = intialParametrsBL.SelectAll();
		for(NPSDemandDO Obj : alArrayList)
		{
			RenewalAmt=RenewalAmt+Float.valueOf(Obj.RenewalAmt);
			if((Float.valueOf(Obj.CollectedAmt))>0)
			{
				CollAmt=CollAmt+Float.valueOf(Obj.CollectedAmt);
				count=count+1;
			}
		}
		tvNPSTotalCollAccounts.setText(""+count);
		tvNPSTotalRenewalAmt.setText(""+RenewalAmt);
		tvNPSRTotCollAmt.setText(""+CollAmt);
		BallAmt =RenewalAmt-CollAmt;
		tvNPSBalanceAmt.setText(""+BallAmt);
		
		btnPrint.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				PrintUtils printUtils = new PrintUtils(NPSSummaryReports.this, NPSSummaryReports.this);
				printUtils.print();
			}
		});
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent(NPSSummaryReports.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
			//	finish();
			}
		});
		btnMainMenu.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llAck						=	(LinearLayout)inflater.inflate(R.layout.npssummaryreport, null);
		tvNPSAgentName				=	(TextView)llAck.findViewById(R.id.tvNPSAgentName);
		tvNPSTotalRnwlsAccounts		=	(TextView)llAck.findViewById(R.id.tvNPSTotalRnwlsAccounts);
		tvNPSTotalCollAccounts		=	(TextView)llAck.findViewById(R.id.tvNPSTotalCollAccounts);
		tvNPSTotalRenewalAmt		=	(TextView)llAck.findViewById(R.id.tvNPSTotalRenewalAmt);
		tvNPSRTotCollAmt			=	(TextView)llAck.findViewById(R.id.tvNPSRTotCollAmt);
		tvNPSBalanceAmt				=	(TextView)llAck.findViewById(R.id.tvNPSBalanceAmt);
		btnPrint					=	(Button)llAck.findViewById(R.id.btnNPSRPrint);
		btnMainMenu					=	(Button)llAck.findViewById(R.id.btnMainMenu);


		svBase.setVisibility(View.GONE);
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llAck, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		showHomeIcons();
        ivLogout.setVisibility(View.GONE);
		tvHeader.setText("NPS Summary Report");
	}

	@Override
	public PrintDetailsDO getprintObject() 
	{
		PrintValues printValues = new PrintValues();
		IntialParametrsDO intialParametrsDO = alIntialParametrsDOs.get(0);
		String header=intialParametrsDO.ReceiptHeader;
//		Log.d("mfimo", header);
        String[] head = header.split("@");
        String head1=head[0];
        String head2=head[1];
        String head3=head[2];
		printValues.add(head1,"true");

        if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
        { }
        else
        {
        	printValues.add(head2,"true");
        }
         if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
        { }
        else
        {
        	printValues.add(head3,"true");
        }
		printValues.add(" ","false");
		printValues.add("Nps TXN Acknowledgement","true");
		printValues.add("---------------------------","true");
		printValues.add(" ","false");
		printValues.add("Date: "+dateNow,"false");
		printValues.add("Agent Name: "+uName,"false");
		printValues.add("Total Rnwls A/C's: "+alArrayList.size(),"false");
		printValues.add("Collection A/C's : "+count,"false");
		printValues.add("Total Rnwls Amount: "+RenewalAmt,"false");
		printValues.add("Collected Amount : "+CollAmt,"false");
		printValues.add("Balance. Rnwls Amt Due/Arrs: "+BallAmt,"false");
		printValues.add(" ","false");
		printValues.add(intialParametrsDO.ReceiptFooter,"true");
		printValues.add(" ","false");
		printValues.add(" ","false");
		return printValues.getDetailObj();
	}

}
