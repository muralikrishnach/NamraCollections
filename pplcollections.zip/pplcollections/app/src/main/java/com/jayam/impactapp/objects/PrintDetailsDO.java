package com.jayam.impactapp.objects;

import java.util.ArrayList;

public class PrintDetailsDO
{
//	public String printer_address = "00:12:6F:03:A7:06";
//	public String printer_address = "00:1F:B7:04:49:25";
	public String printer_address=" 00:04:3E:31:85:87";
//	public String printer_address="44:80:EB:80:0C:9B";

	public ArrayList<String> allabels = new ArrayList<String>();
	public ArrayList<String> alValues = new ArrayList<String>();
}
