package com.jayam.impactapp.database;

import java.util.ArrayList;

import com.jayam.impactapp.objects.AdvaceDemandDO;
import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.NPSDemandDO;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class NPSDemandBL extends BaseBusinessLayer<NPSDemandDO> {
	private ArrayList<NPSDemandDO> alloddemands;
	public void InsertArrayList(ArrayList<NPSDemandDO> alregulardemnads)
	{
		this.alloddemands = alregulardemnads;
		
		for(int i=0 ; i< alloddemands.size(); i++)
		{
			NPSDemandDO ODdemandsDO = alloddemands.get(i);
			Insert(ODdemandsDO);
		}
	}
	@Override
	public boolean Insert(BaseDO object) {// TODO Auto-generated method stub

		NPSDemandDO advdmdns = (NPSDemandDO) object;
		
		try
		{
		  DatabaseHelper.openDataBase();
		}
		catch (Exception e) 
		{}
		
		ContentValues values = new ContentValues();
		
		values.put("CName", advdmdns.CName);
		values.put("CNo", advdmdns.CNo);
		values.put("GName", advdmdns.GName);
		values.put("GNo", advdmdns.GNo);	
		values.put("MName", advdmdns.MName);
		values.put("MMI_Code", advdmdns.MMI_Code);
		values.put("MLAI_ID", advdmdns.MLAI_ID);
		values.put("Coll", advdmdns.Coll);
		values.put("RenewalAmt", advdmdns.RenewalAmt);
		values.put("NextPayDate", advdmdns.NextPayDate);
		values.put("RNo", advdmdns.RNo);
		values.put("DemandDT", advdmdns.DemandDT);
		values.put("SO", advdmdns.SO);
		values.put("InstallNo", advdmdns.InstallNo);
		values.put("NxtRenDate", advdmdns.NxtRenDate);
				
		try
		{
			SQLiteDatabase _database = DatabaseHelper.openDataBase();
			_database.insert("NPSDemands", null, values);
			Log.d("mfimo", "insert");
		}
		catch (Exception e) 
		{}
		return false;
	}
	
	public String  getTOTALNpsAccounts() 
	{
		String totalODAmount = null;
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("select  Count(*)  from NPSTransactions", null);
		   
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	try
		    	{
		    		totalODAmount		 =	c.getString(0);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    	//CREATE TABLE "RegularDemands" ("CNo" VARCHAR PRIMARY KEY  NOT NULL , "CName" VARCHAR, "GNo" VARCHAR, 
				//"EII_EMP_ID" VARCHAR, "GroupName" VARCHAR, "MemberCode" VARCHAR, "MemberName" VARCHAR, "DemandDate" VARCHAR, 
				//"MLAI_ID" VARCHAR, "OSAmt" VARCHAR, "DemandTotal" VARCHAR, "ODAmount" VARCHAR, "Attendance" VARCHAR)
				
		     
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return totalODAmount;
		  
//			select  SUM(DemandTotal+ODAmount)  from RegularDemands 
	}
	
	public String  getTOTALDemandAmountForNps() 
	{
		String totalNpsAmount = null;
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("select  sum(CollAmt)  from NPSTransactions", null);
		   
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	try
		    	{
		    		totalNpsAmount		 =	c.getString(0);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    	//CREATE TABLE "RegularDemands" ("CNo" VARCHAR PRIMARY KEY  NOT NULL , "CName" VARCHAR, "GNo" VARCHAR, 
				//"EII_EMP_ID" VARCHAR, "GroupName" VARCHAR, "MemberCode" VARCHAR, "MemberName" VARCHAR, "DemandDate" VARCHAR, 
				//"MLAI_ID" VARCHAR, "OSAmt" VARCHAR, "DemandTotal" VARCHAR, "ODAmount" VARCHAR, "Attendance" VARCHAR)
				
		     
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return totalNpsAmount;
		  
//			select  SUM(DemandTotal+ODAmount)  from RegularDemands 
	}
	
	public ArrayList<NPSDemandDO> SelectAllCenters() 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
				  c= _database.rawQuery("select DISTINCT CName,CNo  from NPSDemands", null);
			  Log.e("query", "select DISTINCT CName,CNo   from NPSDemands");
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj = 	new NPSDemandDO();
		    	obj.CName	   	=	c.getString(0);
		    	obj.CNo	   		=	c.getString(1);
		    	
		     //Log.e("added", "item");
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  Log.e("error", "getting from database");
		   e.printStackTrace();
		  }
		  
		  _database.close();
		  return vecRegularDemands;
	}
	
	public String updatePrintFlag(String TxnCode, String status) 
	{
		String count = null ;
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("UPDATE NPSTransactions SET PrintFlag = '"+status+"' where TransactionCode = '"+TxnCode+"'", null);
		   
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	try
		    	{
		    		count = c.getString(0);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}

		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return count;

	}
	
	public ArrayList<NPSDemandDO> SelectGroups(String CenterCode) 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
				  c= _database.rawQuery("select DISTINCT GName,GNo  from NPSDemands where CNo='"+CenterCode+"'", null);
			  Log.e("query", "select DISTINCT GName,GNo  from NPSDemands where CNo='"+CenterCode+"'");
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj = 	new NPSDemandDO();
		    	obj.GName	   	=	c.getString(0);
		    	obj.GNo	   		=	c.getString(1);
		    	
		     //Log.e("added", "item");
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  Log.e("error", "getting from database");
		   e.printStackTrace();
		  }
		  
		  _database.close();
		  return vecRegularDemands;
	}
	public ArrayList<NPSDemandDO> SelectMembers(String GCode) 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
				  c= _database.rawQuery("select DISTINCT MName,MMI_Code,MLAI_ID  from NPSDemands where GNo='"+GCode+"'", null);
			  Log.e("query", "select DISTINCT MName,MMI_Code,MLAI_ID  from NPSDemands where GNo='"+GCode+"'");
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj = 	new NPSDemandDO();
		    	obj.MName	   	=	c.getString(0);
		    	obj.MMI_Code 	=	c.getString(1);
		    	obj.MLAI_ID 	=	c.getString(2);
		    	
		     //Log.e("added", "item");
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  Log.e("error", "getting from database");
		   e.printStackTrace();
		  }
		  
		  _database.close();
		  return vecRegularDemands;
	}
	public void updateCollectionAmt()
	{
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;
			
			query = "Update NPSDemands set CollectedAmt='0' where CollectedAmt is null";
			Log.e("query", query);
			try
			{
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				objSqliteDB.setTransactionSuccessful();
				objSqliteDB.endTransaction();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		if(objSqliteDB != null)
		{
			objSqliteDB.close();			
		}
	}
	public void updateBalanceAmt()
	{
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;
			
			query = "Update NPSDemands set BalanceAmt=RenewalAmt-CollectedAmt";
			Log.e("query", query);
			try
			{
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				objSqliteDB.setTransactionSuccessful();
				objSqliteDB.endTransaction();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		if(objSqliteDB != null)
		{
			objSqliteDB.close();			
		}
	}
	public String CheckForFullpayMent(String CNo,String Type) 
	{
			String ODAmt = null;
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		 if(Type.equalsIgnoreCase("Center"))
		   c= _database.rawQuery("Select SUM(RenewalAmt)-SUM(CollectedAmt) from NPSDemands where CNo='"+CNo+"'", null);
		 else if((Type.equalsIgnoreCase("Group")))
			 c= _database.rawQuery("Select SUM(RenewalAmt)-SUM(CollectedAmt) from NPSDemands where GNo='"+CNo+"'", null);
		   		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	try
		    	{
			    	 ODAmt = c.getString(0);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  e.printStackTrace();
		  }
		  return ODAmt;
	}
	public ArrayList<NPSDemandDO> SelectAll(String param, String type) 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
			  if(type.equalsIgnoreCase("Center"))
				  c= _database.rawQuery("select * from NPSDemands where CNo ='"+param+"'", null);
			 else if((type.equalsIgnoreCase("Group")))
				 c= _database.rawQuery("select * from NPSDemands where GNo ='"+param+"'", null);
			 else if((type.equalsIgnoreCase("Memeber")))
				 c= _database.rawQuery("select * from NPSDemands where MLAI_ID ='"+param+"' order by SO", null);
			  Log.e("query", "select * from NPSDemands where MMI_Code ='"+param+"'");
//			 if(type.equalsIgnoreCase("Center"))
//				  c= _database.rawQuery("select * from NPSTransactions where CNo ='"+param+"'", null);
//			 else if((type.equalsIgnoreCase("Group")))
//				 c= _database.rawQuery("select * from NPSTransactions where GNo ='"+param+"'", null);
//			 else if((type.equalsIgnoreCase("Memeber")))
//				 c= _database.rawQuery("select * from NPSTransactions where LoanNo ='"+param+"'", null);
//			  Log.e("query", "select * from NPSTransactions where LoanNo ='"+param+"'");
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj 	= 	new NPSDemandDO();
		    	obj.CName			=	c.getString(0);
		    	obj.CNo				=	c.getString(1);
		    	obj.GName			=	c.getString(2);
		    	obj.GNo				=	c.getString(3);
		    	obj.MName			=	c.getString(4);
		    	obj.MMI_Code		=	c.getString(5);
		    	obj.MLAI_ID		 	=	c.getString(6);
		    	obj.Coll			=	c.getString(7);
		    	obj.RenewalAmt		=	c.getString(8);
		    	obj.NextPayDate		=	c.getString(9);
		    	obj.RNo		 		=	c.getString(10);
		    	obj.DemandDT		=	c.getString(11);
		    	obj.SO				=	c.getString(12);
		    	obj.InstallNo		=	c.getString(13);
		    	obj.NxtRenDate		=	c.getString(14);
		    	obj.BalanceAmt		=	c.getString(15);
		    	obj.CollectedAmt	=	c.getString(16);
		    	obj.PrintFlag		=	c.getString(20);
//		    	  	obj.MName		=	c.getString(0);
//		    		obj.MMI_Code		=	c.getString(1);
//		    		obj.DemandDT		=	c.getString(2);
//		    		obj.MLAI_ID		=	c.getString(3);
//			    	obj.CollectedAmt		=	c.getString(4);
//			    	obj.ReceiptNO		=	c.getString(5);
//			    	obj.PrintFlag		=	c.getString(6);
//			    	obj.TXNCode		 	=	c.getString(7);
//			    	obj.DupNo		=	c.getString(8);
//			    	obj.ActualPrintFlag	=	c.getString(9);
//			    	obj.CName			= c.getString(10);
//			    	obj.CNo			= c.getString(11);
//			    	obj.GName			= c.getString(12);
//			    	obj.GNo			= c.getString(13);
		    	
		     Log.e("added", "item");
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  Log.e("error", "getting from database");
		   e.printStackTrace();
		  }
		  
		  _database.close();
		  return vecRegularDemands;
	}
	
	public ArrayList<NPSDemandDO> SelectAllTransactions(String TxnCode){
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("select * from NPSTransactions where TransactionCode='"+TxnCode+"'", null);
		   Log.e("Query:--","select * from NPSTransactions where TransactionCode='"+TxnCode+"'");
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   if(c.moveToFirst())
		   {
			   do{
				   NPSDemandDO obj=new NPSDemandDO();
				   try{
					    obj.MName		=	c.getString(0);
			    		obj.MMI_Code		=	c.getString(1);
			    		obj.DemandDT		=	c.getString(2);
			    		obj.MLAI_ID		=	c.getString(3);
				    	obj.CollectedAmt		=	c.getString(4);
				    	obj.ReceiptNO		=	c.getString(5);
				    	obj.PrintFlag		=	c.getString(6);
				    	obj.TXNCode		 	=	c.getString(7);
				    	obj.DupNo		=	c.getString(8);
				    	obj.ActualPrintFlag	=	c.getString(9);
				    	obj.CName			= c.getString(10);
				    	obj.CNo			= c.getString(11);
				    	obj.GName			= c.getString(12);
				    	obj.GNo			= c.getString(13);
				   }catch(Exception e){
					   e.printStackTrace();
				   }
				   vecRegularDemands.add(obj);
			   }while(c.moveToNext());
			   c.close();
		   }
		  }catch(Exception e){
			  e.printStackTrace();
		  }
		return vecRegularDemands;
	}
	
	public ArrayList<NPSDemandDO> SelectAllGroupTransactions(String TxnCode,String GroupCode) {
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("select * from NPSTransactions where TransactionCode='"+TxnCode+"' and GNo='"+GroupCode+"'", null);
		   Log.e("Query:--","select * from NPSTransactions where TransactionCode='"+TxnCode+"' and GNo='"+GroupCode+"'");
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   if(c.moveToFirst())
		   {
			   do{
				   NPSDemandDO obj=new NPSDemandDO();
				   try{
					   obj.MName		=	c.getString(0);
			    		obj.MMI_Code		=	c.getString(1);
			    		obj.DemandDT		=	c.getString(2);
			    		obj.MLAI_ID		=	c.getString(3);
				    	obj.CollectedAmt		=	c.getString(4);
				    	obj.ReceiptNO		=	c.getString(5);
				    	obj.PrintFlag		=	c.getString(6);
				    	obj.TXNCode		 	=	c.getString(7);
				    	obj.DupNo		=	c.getString(8);
				    	obj.ActualPrintFlag	=	c.getString(9);
				    	obj.CName			= c.getString(10);
				    	obj.CNo			= c.getString(11);
				    	obj.GName			= c.getString(12);
				    	obj.GNo			= c.getString(13);
				   }catch(Exception e){
					   e.printStackTrace();
				   }
				   vecRegularDemands.add(obj);
			   }while(c.moveToNext());
			   c.close();
		   }
		  }catch(Exception e){
			  e.printStackTrace();
		  }
		return vecRegularDemands;
	}
	
	public ArrayList<NPSDemandDO> SelectDistinctTransactioncodeFromCenter(String centerCode, String type) {
		// TODO Auto-generated method stub
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
			if(type.equals("Center"))  
				c= _database.rawQuery("select  Distinct TransactionCode from NPSTransactions where CNo='"+centerCode+"'", null);
			else if(type.equals("Group"))
				c= _database.rawQuery("select  Distinct TransactionCode from NPSTransactions where GNo='"+centerCode+"'", null);
			else if(type.equals("Member"))	
				c= _database.rawQuery("select  Distinct TransactionCode from NPSTransactions where LoanNo='"+centerCode+"'", null);
		   Log.e("error", "select  Distinct TransactionCode from NPSTransactions where LoanNo='"+centerCode+"'");
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj = 	new NPSDemandDO();
		    	try
		    	{
		    		obj.TXNCode		 =	c.getString(0);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return vecRegularDemands;
	}
	
	public void updateSavedAmt(String MLAI_ID, String amt,String Bal)
	{
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;
			
			query = "UPDATE NPSDemands SET BalanceAmt='"+amt+"',CollectedAmt='"+Bal+"' where MLAI_ID ='"+MLAI_ID+"'";
			Log.e("query", query);
			try
			{
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				objSqliteDB.setTransactionSuccessful();
				objSqliteDB.endTransaction();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		if(objSqliteDB != null)
		{
			objSqliteDB.close();			
		}
	}
	public String  getTOTALCollectedAmount(String para,String type) 
	{
		String totalCollAmount = null;
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
			  if(type.equals("Center"))
				  	c= _database.rawQuery("Select SUM(BalanceAmt) from NPSDemands where CNo='"+para+"'", null);
			  else if(type.equals("Group"))
				  c= _database.rawQuery("Select SUM(BalanceAmt) from NPSDemands where GNo='"+para+"'", null);
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	try
		    	{
		    		totalCollAmount		 =	c.getString(0);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return totalCollAmount;
	}
	public ArrayList<NPSDemandDO> SelectAllData(String param, String type) 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
			 if(type.equalsIgnoreCase("CNo"))
				  c= _database.rawQuery("select * from NPSDemands where CNo ='"+param+"' and CollectedAmt>0", null);
			 else if((type.equalsIgnoreCase("Groups")))
				 c= _database.rawQuery("select * from  NPSDemands where GNo ='"+param+"' and CollectedAmt>0", null);
				 
			  Log.e("query", "select * from NPSDemands where CNo ='"+param+"' and CollectedAmt>0");
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj 	 = 	new NPSDemandDO();
		    	obj.CName			=	c.getString(0);
		    	obj.CNo				=	c.getString(1);
		    	obj.GName			=	c.getString(2);
		    	obj.GNo				=	c.getString(3);
		    	obj.MName			=	c.getString(4);
		    	obj.MMI_Code		=	c.getString(5);
		    	obj.MLAI_ID		 	=	c.getString(6);
		    	obj.Coll			=	c.getString(7);
		    	obj.RenewalAmt		=	c.getString(8);
		    	obj.NextPayDate		=	c.getString(9);
		    	obj.RNo		 		=	c.getString(10);
		    	obj.DemandDT		=	c.getString(11);
		    	obj.SO				=	c.getString(12);
		    	obj.InstallNo		=	c.getString(13);
		    	obj.NxtRenDate		=	c.getString(14);
		    	obj.BalanceAmt		=	c.getString(15);
		    	obj.CollectedAmt	=	c.getString(16);
		    	
		    
		     Log.e("added", "item");
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  Log.e("error", "getting from database");
		   e.printStackTrace();
		  }
		  
		  _database.close();
		  return vecRegularDemands;
	}
	public void updateReciptNumbers(String MALID, String recpNumber)
	{
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;
			
			query = "UPDATE NPSDemands SET ReceiptNO='"+recpNumber+"' where MLAI_ID = '"+MALID+"'";
			Log.e("query", query);
			try
			{
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				objSqliteDB.setTransactionSuccessful();
				objSqliteDB.endTransaction();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		if(objSqliteDB != null)
		{
			objSqliteDB.close();			
		}
	}
	public boolean Insert(BaseDO object, String RecieptNo, String TransactionCode)
	{
		NPSDemandDO parametrsDO = (NPSDemandDO) object;
		
		try
		{
			DatabaseHelper.openDataBase();
		}
		catch (Exception e) 
		{}
		
		ContentValues values = new ContentValues();
			values.put("MName", parametrsDO.MName);
			values.put("MCode", parametrsDO.MMI_Code);
			values.put("TxnDate", parametrsDO.DemandDT);
			values.put("LoanNo", parametrsDO.MLAI_ID);
			values.put("CollAmt", parametrsDO.BalanceAmt);
			values.put("ReceiptNo", RecieptNo);
			values.put("PrintFlag", parametrsDO.PrintFlag);
			values.put("TransactionCode", TransactionCode);
			values.put("DupNo", "0");
			values.put("PrinterPrintFlag","0");
			values.put("CName", parametrsDO.CName);
			values.put("CNo", parametrsDO.CNo);
			values.put("GName", parametrsDO.GName);
			values.put("GNo", parametrsDO.GNo);
		
		try
		{
			SQLiteDatabase _database = DatabaseHelper.openDataBase();
			_database.insert("NPSTransactions", null, values);
		}
		catch (Exception e) 
		{
			Log.e("Eror", "While Inserting Into AdvanceTransactions table");
		}
		return true;
	}
	public ArrayList<NPSDemandDO> SelectReports_Centers() 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
			  
				  c= _database.rawQuery("Select CName,CNo,sum(CollectedAmt) from NPSDemands where CollectedAmt>0 group by CNo", null);
			  
			  
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj  = 	new NPSDemandDO();
		    	obj.CName	  	 =	c.getString(0);
		    	obj.CNo	   		 =	c.getString(1);
		    	obj.CollectedAmt =	c.getString(2);
		    	
		    	
		     //Log.e("added", "item");
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  Log.e("error", "getting from database");
		   e.printStackTrace();
		  }
		  
		  _database.close();
		  return vecRegularDemands;
	}
	public ArrayList<NPSDemandDO> SelectReports_Groups(String ID) 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
				  c= _database.rawQuery("Select GName,GNo,sum(CollectedAmt) from NPSDemands where CollectedAmt>0 and CNo='"+ID+"' group by GNo", null);
			  
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj  = 	new NPSDemandDO();
		    	obj.GName	  	 =	c.getString(0);
		    	obj.GNo	   		 =	c.getString(1);
		    	obj.CollectedAmt =	c.getString(2);
		    	
		    	
		     //Log.e("added", "item");
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  Log.e("error", "getting from database");
		   e.printStackTrace();
		  }
		  
		  _database.close();
		  return vecRegularDemands;
	}
	public ArrayList<NPSDemandDO> SelectReports_Members(String ID) 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
				  c= _database.rawQuery("Select MName,MMI_Code,MLAI_ID,CollectedAmt from NPSDemands where CollectedAmt>0 and GNo='"+ID+"'", null);
			  
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj  = 	new NPSDemandDO();
		    	obj.MName	  	 =	c.getString(0);
		    	obj.MMI_Code	 =	c.getString(1);
		    	obj.MLAI_ID	  	 =	c.getString(2);
		    	obj.CollectedAmt =	c.getString(3);
		    	
		    	
		     //Log.e("added", "item");
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  Log.e("error", "getting from database");
		   e.printStackTrace();
		  }
		  
		  _database.close();
		  return vecRegularDemands;
	}
	public void updateCollectedAmt(String MLAI_ID, String amt,String amt1)
	{
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;
			
			query = "UPDATE NPSDemands SET BalanceAmt='"+amt+"',CollectedAmt='"+amt1+"' where MLAI_ID ='"+MLAI_ID+"'";
			Log.e("query", query);
			try
			{
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				objSqliteDB.setTransactionSuccessful();
				objSqliteDB.endTransaction();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		if(objSqliteDB != null)
		{
			objSqliteDB.close();			
		}
	}
	public ArrayList<NPSDemandDO> SelectAllCollectedData(String param, String type) 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
			  if(type.equalsIgnoreCase("CenterCode"))
				  c= _database.rawQuery("select * from NPSDemands where CNo ='"+param+"' and BalanceAmt>0", null);
			 else if((type.equalsIgnoreCase("Groups")))
				 c= _database.rawQuery("select * from NPSDemands where GNo ='"+param+"' and BalanceAmt>0", null);
			 else if((type.equalsIgnoreCase("memeber")))
				 c= _database.rawQuery("select * from NPSDemands where MLAI_ID ='"+param+"' and BalanceAmt>0", null);
			  Log.e("query", "select * from NPSDemands where CNo ='"+param+"'");
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj 	= 	new NPSDemandDO();
		    	obj.CName			=	c.getString(0);
		    	obj.CNo				=	c.getString(1);
		    	obj.GName			=	c.getString(2);
		    	obj.GNo				=	c.getString(3);
		    	obj.MName			=	c.getString(4);
		    	obj.MMI_Code		=	c.getString(5);
		    	obj.MLAI_ID		 	=	c.getString(6);
		    	obj.Coll			=	c.getString(7);
		    	obj.RenewalAmt		=	c.getString(8);
		    	obj.NextPayDate		=	c.getString(9);
		    	obj.RNo		 		=	c.getString(10);
		    	obj.DemandDT		=	c.getString(11);
		    	obj.SO				=	c.getString(12);
		    	obj.InstallNo		=	c.getString(13);
		    	obj.NxtRenDate		=	c.getString(14);
		    	obj.BalanceAmt		=	c.getString(15);
		    	obj.CollectedAmt	=	c.getString(16);
		    	obj.ReceiptNO		=	c.getString(17);
		    	obj.TXNCode			=	c.getString(18);
		    	obj.PrintFlag		=	c.getString(20);
		    	
		     Log.e("added", "item");
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
			  Log.e("error", "getting from database");
		   e.printStackTrace();
		  }
		  
		  _database.close();
		  return vecRegularDemands;
	}
	public String SelectCountcenters() 
	{
		String count = null ;
//		SQLiteDatabase _database = DatabaseHelper.closedatabase();
		SQLiteDatabase   _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("SELECT Count(*)  Count from NPSDemands  where CollectedAmt>0", null);
		   if(c.moveToFirst())
		   {
			    do
			    {
			    	try
			    	{
			    		count 		 =	c.getString(0);
			    	}
			    	catch(Exception e)
			    	{
			    		Log.e("exception", "while getting from server");
			    	}
			    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return count;
	}
	public ArrayList<NPSDemandDO> SelectReportsData(String ID,String Type) 
	{
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
			  if(Type.equalsIgnoreCase("Center"))
				  c= _database.rawQuery("select * from NPSDemands where CNo ='"+ID+"' and CollectedAmt>0", null);
			 else if((Type.equalsIgnoreCase("Group")))
				 c= _database.rawQuery("select * from NPSDemands where GNo ='"+ID+"' and CollectedAmt>0", null);
			 else if((Type.equalsIgnoreCase("Memeber")))
				 c= _database.rawQuery("select * from NPSDemands where MLAI_ID ='"+ID+"' and CollectedAmt>0", null);
			 else if((Type.equalsIgnoreCase("Summary")))
				 c= _database.rawQuery("select * from NPSDemands", null);
		   Log.e("Query:--","select * from NPSDemands where MLAI_ID ='"+ID+"' and CollectedAmt>0");
		   
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj 	= 	new NPSDemandDO();
		    	
		    	try
		    	{
		    	
		    	obj.CName			=	c.getString(0);
		    	obj.CNo				=	c.getString(1);
		    	obj.GName			=	c.getString(2);
		    	obj.GNo				=	c.getString(3);
		    	obj.MName			=	c.getString(4);
		    	obj.MMI_Code		=	c.getString(5);
		    	obj.MLAI_ID		 	=	c.getString(6);
		    	obj.Coll			=	c.getString(7);
		    	obj.RenewalAmt		=	c.getString(8);
		    	obj.NextPayDate		=	c.getString(9);
		    	obj.RNo		 		=	c.getString(10);
		    	obj.DemandDT		=	c.getString(11);
		    	obj.SO				=	c.getString(12);
		    	obj.InstallNo		=	c.getString(13);
		    	obj.NxtRenDate		=	c.getString(14);
		    	obj.BalanceAmt		=	c.getString(15);
		    	obj.CollectedAmt	=	c.getString(16);
		    	obj.ReceiptNO		=	c.getString(17);
		    	obj.TXNCode			=	c.getString(18);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return vecRegularDemands;
	}
	public String CollectionRecords() 
	{
		String count = null ;
//		SQLiteDatabase _database = DatabaseHelper.closedatabase();
		SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("select count(*) from NPSTransactions", null);
		   if(c.moveToFirst())
		   {
			    do
			    {
			    	try
			    	{
			    		count 		 =	c.getString(0);
			    	}
			    	catch(Exception e)
			    	{
			    		Log.e("exception", "while getting from server");
			    	}
			    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return count;
	}
	public String  getrowCount() 
	{
		String totalODAmount = null;
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("select count (*)  from NPSTransactions ", null);
		   
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	try
		    	{
		    		totalODAmount		 =	c.getString(0);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return totalODAmount;

	}
	public void Truncatetabel()
	{
		 	SQLiteDatabase objSqliteDB = null;
			objSqliteDB = DatabaseHelper.openDataBase();
			String query = null;
				
				query = "DELETE FROM NPSDemands ";
				Log.e("query", query);
				try
				{
					objSqliteDB.beginTransaction();	
					SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
					sqLiteStatement.executeInsert();
					objSqliteDB.setTransactionSuccessful();
					objSqliteDB.endTransaction();
					
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			if(objSqliteDB != null)
			{
				objSqliteDB.close();			
			}
		 
		 
	}
	public void Truncatetabe()
	{
		 	SQLiteDatabase objSqliteDB = null;
			objSqliteDB = DatabaseHelper.openDataBase();
			String query = null;
				
				query = "DELETE FROM NPSTransactions ";
				Log.e("query", query);
				try
				{
					objSqliteDB.beginTransaction();	
					SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
					sqLiteStatement.executeInsert();
					objSqliteDB.setTransactionSuccessful();
					objSqliteDB.endTransaction();
					
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			if(objSqliteDB != null)
			{
				objSqliteDB.close();			
			}
		 
		 
	}
	@Override
	public boolean Update(BaseDO object) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean Delete(BaseDO object) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<NPSDemandDO> SelectAll() {
		ArrayList<NPSDemandDO> vecRegularDemands = new ArrayList<NPSDemandDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {

				 c= _database.rawQuery("select * from NPSTransactions", null);
		   Log.e("Query:--","select * from NPSTransactions");
		   
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	NPSDemandDO obj = 	new NPSDemandDO();
		    	try
		    	{
		    		  	obj.MName		=	c.getString(0);
			    		obj.MMI_Code		=	c.getString(1);
			    		obj.DemandDT		=	c.getString(2);
			    		obj.MLAI_ID		=	c.getString(3);
				    	obj.CollectedAmt		=	c.getString(4);
				    	obj.ReceiptNO		=	c.getString(5);
				    	obj.PrintFlag		=	c.getString(6);
				    	obj.TXNCode		 	=	c.getString(7);
				    	obj.DupNo		=	c.getString(8);
				    	obj.ActualPrintFlag	=	c.getString(9);
				    	obj.CName			= c.getString(10);
				    	obj.CNo			= c.getString(11);
				    	obj.GName			= c.getString(12);
				    	obj.GNo			= c.getString(13);
		    	
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return vecRegularDemands;
}
	public String getDupNoforMember(String mLAI_ID, String txnCode) {
		// TODO Auto-generated method stub
		String count = null ;
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("SELECT DupNo  from NpsTransactions where LoanNo = '"+mLAI_ID+"' and TransactionCode='"+txnCode+"'", null);
		   Log.e("Query----","SELECT DupNo  from NpsTransactions where LoanNo = '"+mLAI_ID+"' and TransactionCode='"+txnCode+"'");
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	try
		    	{
		    		count = c.getString(0);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return count;
	}
	public void updateDupNO(String valueOf, String mLAI_ID, String txnCode) {
		// TODO Auto-generated method stub
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;
			
			query = "UPDATE AdvanceTransactions SET DupNo='"+valueOf+"' where LoanNo = '"+mLAI_ID+"' and TransactionCode='"+txnCode+"'";
			Log.e("query", query);
			try
			{
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				objSqliteDB.setTransactionSuccessful();
				objSqliteDB.endTransaction();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		if(objSqliteDB != null)
		{
			objSqliteDB.close();			
		}
	}
	public String SelectMinDupNo(String txnCode, String centerCode,	String type) {
		String count = null ;
		SQLiteDatabase   _database = DatabaseHelper.openDataBase();
		Cursor c = null;
		try 
		{
			if(type.equals("Center"))
					c= _database.rawQuery("select MIN(DupNo) from NpsTransactions where TransactionCode='"+txnCode+"' and CNo='"+centerCode+"'", null);
			else if(type.equals("Group"))
					c= _database.rawQuery("select MIN(DupNo) from NpsTransactions where TransactionCode='"+txnCode+"' and GNo='"+centerCode+"'", null);
				Log.e("mfimo", "select MIN(DupNo) from NpsTransactions where TransactionCode='"+txnCode+"' and GNo='"+centerCode+"'");
			if(c.moveToFirst())
			{
			do
			{
				try
				{
					count 		 =	c.getString(0);
				}
				catch(Exception e)
				{
					Log.e("exception", "while getting from server");
				}
			}
				while(c.moveToNext());
				c.close();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
			return count;
	}
	public void updateDupNoingroup(String centerCode, String txnCode,String type) {
		// TODO Auto-generated method stub
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;
		if(type.equals("Center"))
		query = "UPDATE NPSTransactions SET DupNo=DupNo+1 where CNo = '"+centerCode+"' and TransactionCode='"+txnCode+"'";
		else if(type.equals("Group"))
			query = "UPDATE NPSTransactions SET DupNo=DupNo+1 where GNo = '"+centerCode+"' and TransactionCode='"+txnCode+"'";
		Log.e("query", query);
		try
		{
			objSqliteDB.beginTransaction();	
			SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
			sqLiteStatement.executeInsert();
			objSqliteDB.setTransactionSuccessful();
			objSqliteDB.endTransaction();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		if(objSqliteDB != null)
		{
			objSqliteDB.close();			
		}
	}
	public String MinDupNo(String centerCode, String type) {
		// TODO Auto-generated method stub
		String count = null ;
		SQLiteDatabase   _database = DatabaseHelper.openDataBase();
		Cursor c = null;
		try 
		{
			if(type.equals("Center"))
					c= _database.rawQuery("select MIN(DupNo) from NPSTransactions where CNo='"+centerCode+"'", null);
			else if(type.equals("Group"))
					c= _database.rawQuery("select MIN(DupNo) from NPSTransactions where GNo='"+centerCode+"'", null);
			
			if(c.moveToFirst())
			{
			do
			{
				try
				{
					count 		 =	c.getString(0);
				}
				catch(Exception e)
				{
					Log.e("exception", "while getting from server");
				}
			}
				while(c.moveToNext());
				c.close();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
			return count;
	}
	public String getTxncode(String mLAID) {
		// TODO Auto-generated method stub
		String totalCollAmount = null;
		SQLiteDatabase _database = DatabaseHelper.openDataBase();
		Cursor c = null;
		try 
		{
			c= _database.rawQuery("select TransactionCode MPSTransactions where LoanNo = '"+mLAID+"'", null);
			if(c.moveToFirst())
			{
				do
				{
					try
					{
						totalCollAmount		 =	c.getString(0);
					}
					catch(Exception e)
					{
						Log.e("exception", "while getting from server");
					}
				}
				while(c.moveToNext());
				c.close();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return totalCollAmount;
	}

}
