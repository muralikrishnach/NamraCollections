package com.jayam.impactapp.objects;

public class DemandDateDO extends BaseDO
{
	public String date;
}
