package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.CustomDailoglistner;
import com.jayam.impactapp.common.PrintListner;
import com.jayam.impactapp.common.PrintValues;
import com.jayam.impactapp.database.IntialParametrsBL;
import com.jayam.impactapp.database.LastRecieptBL;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.database.RegularDemandsBL;
import com.jayam.impactapp.database.TrnsactionsBL;
import com.jayam.impactapp.objects.IntialParametrsDO;
import com.jayam.impactapp.objects.NPSDemandDO;
import com.jayam.impactapp.objects.PrintDetailsDO;
import com.jayam.impactapp.objects.RegularDemandsDO;
import com.jayam.impactapp.utils.PrintUtils;
import com.jayam.impactapp.utils.SharedPrefUtils;
import com.jayam.impactapp.utils.StringUtils;


import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NPSTxnAck extends Base implements PrintListner
{
	private LinearLayout llAck;
	private TextView tvNPSreceiptno,tvNPSCenterName,tvNPSGroupName, tvNPSCollAmt,tvNPSRenewalAmt;
	private ArrayList<NPSDemandDO> alArrayList;
	private String GroupCode;
	private String LastTranScode;
	private Button btnadvMenu, btnPrint;
	private NPSDemandBL npsDemandBl;
	private ArrayList<IntialParametrsDO> alIntialParametrsDOs;
	private IntialParametrsBL intialParametrsBL;
	String Print;
	PrintDetailsDO detailsDO;
	private boolean isPrintTaken = false;
//    public static final int MESSAGE_STATE_CHANGE = 1;
//    public static final int MESSAGE_READ = 2;
//    public static final int MESSAGE_WRITE = 3;
//    public static final int MESSAGE_DEVICE_NAME = 4;
//    public static final int MESSAGE_TOAST = 5;
//    public static final String TOAST = "toast";

	float collectedAmt = 0;
	float RenewalAmt = 0;

	LastRecieptBL recptBL;
	@Override
	public void initialize() 
	{
		recptBL = new LastRecieptBL();
		GroupCode = getIntent().getExtras().getString("GroupCode");
		LastTranScode = getIntent().getExtras().getString("LastTranScode");
		intializeControlles();
		detailsDO=new PrintDetailsDO();
		npsDemandBl = new NPSDemandBL();
		alArrayList = npsDemandBl.SelectAll(GroupCode,"Group");
		
		intialParametrsBL = new  IntialParametrsBL();
		alIntialParametrsDOs = intialParametrsBL.SelectAll();
		
		tvNPSCenterName.setText(""+alArrayList.get(0).CName);
		tvNPSGroupName.setText(""+alArrayList.get(0).GName);
		tvNPSreceiptno.setText(""+LastTranScode);
		
		for(int i=0 ; i< alArrayList.size(); i++)
		{
			try
			{
				collectedAmt	= collectedAmt + Float.valueOf(alArrayList.get(i).CollectedAmt).floatValue() ;
				RenewalAmt		= RenewalAmt + Float.valueOf(alArrayList.get(i).RenewalAmt).floatValue() ;
			}
			catch (Exception e) 
			{
				Log.e("Exception", ""+e.toString());
			}
		}
		tvNPSCollAmt.setText(""+collectedAmt);
		tvNPSRenewalAmt.setText(""+RenewalAmt);
		
		btnadvMenu.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				//if(Print.equals("1"))
			//	{
					if(!isPrintTaken)
					{
						showAlertDailog("Receipt is not printed. Are you sure want to exit the Menu ?", "OK", "Cancel", new CustomDailoglistner() 
						{
							@Override
							public void onPossitiveButtonClick(DialogInterface dialog)
							{
								dialog.dismiss();
								ShowLoader();
								new Thread(new  Runnable() 
								{
									public void run() 
									{
										// update print status Y/N
										recptBL.delete();
										recptBL.insert(LastTranScode,"N","N");
										npsDemandBl.updatePrintFlag(LastTranScode,"N") ;
										runOnUiThread(new  Runnable() {
											public void run() 
											{
												HideLoader();
												setResult(AppConstants.RESULTCODE_HOME);
												finish();
											}
										});
									}
								}).start();
							}
							@Override
							public void onNegativeButtonClick(DialogInterface dialog)
							{
								dialog.dismiss();
							}
						});
					}
					else
					{
						showAlertDailog("Receipt Printed Y / N ", "Yes", "No", new CustomDailoglistner() 
						{
							@Override
							public void onPossitiveButtonClick(DialogInterface dialog)
							{
								recptBL.updateLastReceiptPrintFlag(LastTranScode, "Y") ;
								dialog.dismiss();
								setResult(AppConstants.RESULTCODE_HOME);
								finish();
							}
							
							@Override
							public void onNegativeButtonClick(DialogInterface dialog)
							{
								dialog.dismiss();
								
								showAlertDailog("WARNING ! Do you want to overwrite printed confirmation, pls. confirm Y / N.", "Yes", "No", new CustomDailoglistner() 
								{
									@Override
									public void onPossitiveButtonClick(DialogInterface dialog)
									{
										recptBL.updateLastReceiptPrintFlag(LastTranScode, "N") ;
										dialog.dismiss();
										setResult(AppConstants.RESULTCODE_HOME);
										finish();
									}
									
									@Override
									public void onNegativeButtonClick(DialogInterface dialog)
									{
										recptBL.updateLastReceiptPrintFlag(LastTranScode, "Y") ;
										dialog.dismiss();
										setResult(AppConstants.RESULTCODE_HOME);
										finish();
									}
								});
							}
						});
					}
				}
				/*else
				{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
			}*/
				
		});
		
		btnPrint.setOnClickListener(new OnClickListener() 
		{	
			@Override
			public void onClick(View v) 
			{
					if(!isPrintTaken)
					{
						BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();
						if (bluetooth.isEnabled()) 
						{
							ShowLoader();
							new Thread(new  Runnable() 
							{
								public void run() 
								{
									recptBL.delete();
									recptBL.insert(LastTranScode,"N","N");
									npsDemandBl.updatePrintFlag(LastTranScode, "Y");
									runOnUiThread(new Runnable() 
									{
										public void run() 
										{
											HideLoader();
											PrintUtils printUtils = new PrintUtils(NPSTxnAck.this, NPSTxnAck.this);
											printUtils.print();
										}
									});
								}
							}).start();
						}
						else
						{
							showAlertDailog("Please Switch On Mobile Bluetooth");
							return;
						}
					}
					else
					{
						showAlertDailog("Receipt Printed Y / N ", "Yes", "No", new CustomDailoglistner() 
						{
							@Override
							public void onPossitiveButtonClick(DialogInterface dialog)
							{
								recptBL.updateLastReceiptPrintFlag(LastTranScode, "Y") ;
								dialog.dismiss();
								setResult(AppConstants.RESULTCODE_HOME);
								finish();
							}
							@Override
							public void onNegativeButtonClick(DialogInterface dialog)
							{
								dialog.dismiss();
								showAlertDailog("WARNING ! Do you want to overwrite printed confirmation, pls. confirm Y / N.", "Yes", "No", new CustomDailoglistner() 
								{
									@Override
									public void onPossitiveButtonClick(DialogInterface dialog)
									{
										recptBL.updateLastReceiptPrintFlag(LastTranScode, "N") ;
										dialog.dismiss();
										setResult(AppConstants.RESULTCODE_HOME);
										finish();
									}
									@Override
									public void onNegativeButtonClick(DialogInterface dialog)
									{
										recptBL.updateLastReceiptPrintFlag(LastTranScode, "Y") ;
										dialog.dismiss();
										setResult(AppConstants.RESULTCODE_HOME);
										finish();
									}
								});
							}
						});
					}	
				}
		});
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_LOGOUT);
				finish();
			}
		});
		
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llAck				=	(LinearLayout)inflater.inflate(R.layout.npstxnack, null);
		
		tvNPSreceiptno		=	(TextView)llAck.findViewById(R.id.tvNPSreceiptno);
		tvNPSCenterName		=	(TextView)llAck.findViewById(R.id.tvNPSCenterName);
		tvNPSGroupName		=	(TextView)llAck.findViewById(R.id.tvNPSGroupName);
		tvNPSRenewalAmt		=	(TextView)llAck.findViewById(R.id.tvNPSRenewalAmt);
		tvNPSCollAmt		=	(TextView)llAck.findViewById(R.id.tvNPSCollAmt);
		
		btnadvMenu			=	(Button)llAck.findViewById(R.id.btnadvMenu);
		btnPrint			=	(Button)llAck.findViewById(R.id.btnadvPrint);
		
		svBase.setVisibility(View.GONE);
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llAck, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		hidehomeIcons();
		tvHeader.setText("Transaction Acknowledgement");
	}
	
   	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == AppConstants.RESULTCODE_LOGOUT)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_HOME)
		{
			setResult(resultCode);
			finish();
		}
	}

	@Override
	public PrintDetailsDO getprintObject() {
		//int i=0;
		PrintValues printValues = new PrintValues();
		IntialParametrsDO intialParametrsDO = alIntialParametrsDOs.get(0);
		if(intialParametrsDO.IndividualReceipts.equalsIgnoreCase("1")){
			NPSDemandBL trnsactionsBL= new NPSDemandBL();
			ArrayList<NPSDemandDO> alArrayList = trnsactionsBL.SelectAllTransactions(LastTranScode);
			for(int i=0;i<alArrayList.size();i++){
				NPSDemandDO obj=alArrayList.get(i);
				NPSDemandDO npsDemandsDo=npsDemandBl.SelectAll(obj.MLAI_ID, "Memeber").get(0);
				String header=intialParametrsDO.ReceiptHeader;
//				Log.d("mfimo", header);
	            String[] head = header.split("@");
	            String head1=head[0];
	            String head2=head[1];
	            String head3=head[2];
	            String reciptNum=StringUtils.getRecieptNumberForNPS(obj);
//	            Log.d("mfimo", reciptNum);
				printValues.add(head1,"true");
				 if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head2,"true");
		            }
		             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head3,"true");
		            }
					printValues.add(" ","false");
					if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1"))
					{
					printValues.add("Customer Copy","true");	
					}
					printValues.add("NPS TXN Acknowledgement","true");
					printValues.add("---------------------------","true");
					printValues.add(" ","false");
					printValues.add("R.No:"+reciptNum,"false");
					printValues.add("Date:"+obj.DemandDT,"false");
					printValues.add(" ","false");
					String URL=SharedPrefUtils.getKeyValue(this, AppConstants.pref_name, AppConstants.UrlAddress);
					if(URL.equals("Yes"))
					{
						printValues.add("Center Name:"+obj.CName,"false");
						printValues.add("SHG Name:"+obj.GName,"false");
						printValues.add("Member Name:"+obj.MName+"("+npsDemandsDo.MMI_Code+")","false");
						if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
    					{
    						printValues.add("Rnwl Installment No:"+npsDemandsDo.InstallNo,"false");
    					}
    					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
//						float DmdTot=Float.valueOf(npsDemandsDo.DemandTotal)+Float.valueOf(regularDemandsDO.ODAmount);
//						printValues.add("Planned Savings:"+DmdTot,"false");
//						printValues.add("Savings Collected:"+obj.collectedAmount,"false");
					}
					else
					{
						printValues.add("Center:"+obj.CName,"false");
						printValues.add("Group:"+obj.GName,"false");
						printValues.add("Member:"+obj.MName+"("+npsDemandsDo.MMI_Code+")","false");
						printValues.add("Loan A/C No:"+obj.MLAI_ID,"false");
						if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
    					{
    						printValues.add("Rnwl Installment No:"+npsDemandsDo.InstallNo,"false");
    					}
    					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
//						float DmdTot=Float.valueOf(regularDemandsDO.DemandTotal)+Float.valueOf(regularDemandsDO.ODAmount);
//						printValues.add("Demand:"+DmdTot,"false");
//						printValues.add("collection Amt:"+obj.collectedAmount,"false");
//						float OSAmt=Float.valueOf(obj.OSAmt)-Float.valueOf(CollAmt);
//						printValues.add("Curr OS(P+I):"+OSAmt,"false");
					}
					printValues.add(" ","false");
					printValues.add(intialParametrsDO.ReceiptFooter,"true");
					printValues.add(" ","false");
					printValues.add(" ","false");
					printValues.add(" ","false");
			}
			
			if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1"))
			{
				// print agent copy
				for(int i=0 ; i <alArrayList.size(); i++ )
				{
					NPSDemandDO obj=alArrayList.get(i);
					NPSDemandBL npsDemandsBl= new NPSDemandBL();
					NPSDemandDO npsDemandsDo=npsDemandsBl.SelectAll(obj.MLAI_ID, "Memeber").get(0);
//					String CollAmt=npsDemandsBl.getCollectedAmtForMember(obj.MLAI_ID);
					String header=intialParametrsDO.ReceiptHeader;
		            String[] head = header.split("@");
		            String head1=head[0];
		            String head2=head[1];
		            String head3=head[2];
					printValues.add(head1,"true");
					String reciptNum=StringUtils.getRecieptNumberForNPS(obj);
//		            Log.d("mfimo", reciptNum);
		            if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head2,"true");
		            }
		             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head3,"true");
		            }
					printValues.add(" ","false");
					printValues.add("Agent Copy","true");	
					printValues.add("NPS TXN Acknowledgement","true");
					printValues.add("---------------------------","true");
					printValues.add(" ","false");
					printValues.add("R.No:"+reciptNum,"false");
					printValues.add("Date:"+obj.DemandDT,"false");
					printValues.add(" ","false");
					String URL=SharedPrefUtils.getKeyValue(this, AppConstants.pref_name, AppConstants.UrlAddress);
    				if(URL.equals("Yes"))
    				{
    					printValues.add("Center Name:"+obj.CName,"false");
    					printValues.add("SHG Name:"+obj.GName,"false");
    					printValues.add("Member Name:"+obj.MName+"("+npsDemandsDo.MMI_Code+")","false");
    					if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
    					{
    						printValues.add("Rnwl Installment No:"+npsDemandsDo.InstallNo,"false");
    					}
    					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
//    					float DmdTot=Float.valueOf(regularDemandsDO.DemandTotal)+Float.valueOf(regularDemandsDO.ODAmount);
//    					printValues.add("Planned Savings:"+DmdTot,"false");
//    					printValues.add("Savings Collected:"+obj.collectedAmount,"false");
    					printValues.add(" ","false");
    					printValues.add("Total Group Rnwl Amount:"+RenewalAmt,"false");
    					printValues.add("Total Group Coll Amount:"+collectedAmt,"false");
    					printValues.add("Next Installment Date:"+alArrayList.get(0).NextPayDate,"false");
    				}
    				else
    				{
    					printValues.add("Center:"+obj.CName,"false");
    					printValues.add("Group:"+obj.GName,"false");
    					printValues.add("Member:"+obj.MName+"("+npsDemandsDo.MMI_Code+")","false");
    					if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
    					{
    						printValues.add("Rnwl Installment No:"+npsDemandsDo.InstallNo,"false");
    					}
    					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
    					printValues.add(" ","false");
    					printValues.add("Total Group Rnwl Amount:"+RenewalAmt,"false");
    					printValues.add("Total Group Coll Amount:"+collectedAmt,"false");
    					printValues.add("Next Installment Date:"+alArrayList.get(0).NextPayDate,"false");
//    					printValues.add("Next Installment Date:"+npsDemandsDo.NextRepayDate,"false");
//    					float DmdTot=Float.valueOf(npsDemandsDo.DemandTotal)+Float.valueOf(regularDemandsDO.ODAmount);
//    					printValues.add("Demand:"+DmdTot,"false");
//    					printValues.add("collection Amt:"+obj.collectedAmount,"false");
//    					float OSAmt=Float.valueOf(obj.OSAmt)-Float.valueOf(CollAmt);
//    					printValues.add("Curr OS(P+I):"+OSAmt,"false");
    				}
					
					printValues.add(" ","false");
					printValues.add(intialParametrsDO.ReceiptFooter,"true");
					printValues.add(" ","false");
					printValues.add(" ","false");
					printValues.add(" ","false");
				}
			}
		}else{
			
			String URL=SharedPrefUtils.getKeyValue(this, AppConstants.pref_name, AppConstants.UrlAddress);
			NPSDemandBL trnsactionsBL= new NPSDemandBL();
			ArrayList<NPSDemandDO> alArrayList1=trnsactionsBL.SelectAll(GroupCode, "Group");
			ArrayList<NPSDemandDO> alArrayList = trnsactionsBL.SelectAllTransactions(LastTranScode);
			String header=intialParametrsDO.ReceiptHeader;
            String[] head = header.split("@");
            String head1=head[0];
            String head2=head[1];
            String head3=head[2];
			printValues.add(head1,"true");
			String reciptNum=StringUtils.getRecieptNumberForNPS(alArrayList.get(0));
			if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
            { }
            else
            {
            	printValues.add(head2,"true");
            }
             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
            { }
            else
            {
            	printValues.add(head3,"true");
            }
			
			printValues.add(" ","false");
			if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1"))
			{
			printValues.add("Customer Copy","true");	
			}
			printValues.add("NPS TXN Acknowledgement","true");
			printValues.add("---------------------------","true");
			printValues.add(" ","false");
			printValues.add("Date:"+alArrayList.get(0).DemandDT,"false");
			if(URL.equals("Yes"))
			{
				printValues.add("R.No:"+reciptNum,"false");
				printValues.add("Center Name:"+alArrayList1.get(0).CName,"false");
				printValues.add("SHG Name:"+alArrayList1.get(0).GName,"false");
				
				for(int i=0 ; i <alArrayList.size(); i++ )
				{
					NPSDemandDO obj = alArrayList.get(i);
					NPSDemandBL npsDemandsBL = new NPSDemandBL();
					NPSDemandDO npsDemandsDO = npsDemandsBL.SelectAll(obj.MLAI_ID, "Memeber").get(0);
					printValues.add(" ","false");
					printValues.add("Member Name:"+obj.MName+"("+npsDemandsDO.MMI_Code+")","false");
					if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
					{
						printValues.add("Rnwl Installment No:"+npsDemandsDO.InstallNo,"false");
					}
					printValues.add("Next Rnwl Date:"+npsDemandsDO.NxtRenDate,"false");
					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
					printValues.add("Bal. Rnwl/Arrs Amt:"+npsDemandsDO.BalanceAmt,"false");
				}
				printValues.add(" ","false");
				printValues.add("Total Group Rnwl Amount:"+RenewalAmt,"false");
				printValues.add("Total Group Coll Amount:"+collectedAmt,"false");
				printValues.add("Next Installment Date:"+alArrayList1.get(0).NextPayDate,"false");
			}
			else
			{
				printValues.add("Group R.No:"+reciptNum,"false");
				printValues.add("Center:"+alArrayList1.get(0).CName,"false");
				printValues.add("Group:"+alArrayList1.get(0).GName,"false");
				
				for(int i=0 ; i <alArrayList.size(); i++ )
				{
					NPSDemandDO obj = alArrayList.get(i);
					NPSDemandBL npsDemandsBL = new NPSDemandBL();
					NPSDemandDO npsDemandsDO = npsDemandsBL.SelectAll(obj.MLAI_ID, "Memeber").get(0);
					printValues.add(" ","false");
					printValues.add("Name:"+obj.MName+"("+npsDemandsDO.MMI_Code+")","false");
					if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
					{
						printValues.add("Rnwl Installment No :"+npsDemandsDO.InstallNo,"false");
					}
					printValues.add("Next Rnwl Date:"+npsDemandsDO.NxtRenDate,"false");
					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
					printValues.add("Bal. Rnwl/Arrs Amt:"+npsDemandsDO.BalanceAmt,"false");
//					float OSAmt=Float.valueOf(obj.OSAmt)-Float.valueOf(CollAmt);
//					printValues.add("Curr OS(P+I):"+OSAmt,"false");
				}
				printValues.add(" ","false");
				printValues.add("Total Group Rnwl Amount Due/Arrs:"+RenewalAmt,"false");
				printValues.add("Total Group Coll Amount:"+collectedAmt,"false");
				printValues.add("Next Installment Date:"+alArrayList1.get(0).NextPayDate,"false");
			}
			
			printValues.add(" ","false");
			printValues.add(intialParametrsDO.ReceiptFooter,"true");
			printValues.add(" ","false");
			printValues.add(" ","false");
			printValues.add(" ","false");
			if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1")){
				String reciptNum1=StringUtils.getRecieptNumberForNPS(alArrayList.get(0));
				if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
	            { }
	            else
	            {
	            	printValues.add(head2,"true");
	            }
	             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
	            { }
	            else
	            {
	            	printValues.add(head3,"true");
	            }
				
				printValues.add(" ","false");
				if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1"))
				{
				printValues.add("Customer Copy","true");	
				}
				printValues.add("NPS TXN Acknowledgement","true");
				printValues.add("---------------------------","true");
				printValues.add(" ","false");
				printValues.add("Date:"+alArrayList.get(0).DemandDT,"false");
				if(URL.equals("Yes"))
				{
					printValues.add("R.No:"+reciptNum1,"false");
					printValues.add("Center Name:"+alArrayList1.get(0).CName,"false");
					printValues.add("SHG Name:"+alArrayList1.get(0).GName,"false");
					
					for(int i=0 ; i <alArrayList.size(); i++ )
					{
						NPSDemandDO obj = alArrayList.get(i);
						NPSDemandBL npsDemandsBL = new NPSDemandBL();
						NPSDemandDO npsDemandsDO = npsDemandsBL.SelectAll(obj.MLAI_ID, "Memeber").get(0);
						printValues.add(" ","false");
						printValues.add("Member Name:"+obj.MName+"("+npsDemandsDO.MMI_Code+")","false");
						if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
						{
							printValues.add("Rnwl Installment No:"+npsDemandsDO.InstallNo,"false");
						}
						printValues.add("Next Rnwl Date:"+npsDemandsDO.NxtRenDate,"false");
						printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
						printValues.add("Bal. Rnwl/Arrs Amt:"+npsDemandsDO.BalanceAmt,"false");
					}
					printValues.add(" ","false");
					printValues.add("Total Group Rnwl Amount:"+RenewalAmt,"false");
					printValues.add("Total Group Coll Amount:"+collectedAmt,"false");
					printValues.add("Next Installment Date:"+alArrayList1.get(0).NextPayDate,"false");
				}
				else
				{
					printValues.add("Group R.No:"+reciptNum1,"false");
					printValues.add("Center:"+alArrayList1.get(0).CName,"false");
					printValues.add("Group:"+alArrayList1.get(0).GName,"false");
					
					for(int i=0 ; i <alArrayList.size(); i++ )
					{
						NPSDemandDO obj = alArrayList.get(i);
						NPSDemandBL npsDemandsBL = new NPSDemandBL();
						NPSDemandDO npsDemandsDO = npsDemandsBL.SelectAll(obj.MLAI_ID, "Memeber").get(0);
						printValues.add(" ","false");
						printValues.add("Name:"+obj.MName+"("+npsDemandsDO.MMI_Code+")","false");
						if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
						{
							printValues.add("Rnwl Installment No :"+npsDemandsDO.InstallNo,"false");
						}
						printValues.add("Next Rnwl Date:"+npsDemandsDO.NxtRenDate,"false");
						printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
						printValues.add("Bal. Rnwl/Arrs Amt:"+npsDemandsDO.BalanceAmt,"false");
//						float OSAmt=Float.valueOf(obj.OSAmt)-Float.valueOf(CollAmt);
//						printValues.add("Curr OS(P+I):"+OSAmt,"false");
					}
					printValues.add(" ","false");
					printValues.add("Total Group Rnwl Amount:"+RenewalAmt,"false");
					printValues.add("Total Group Coll Amount:"+collectedAmt,"false");
					printValues.add("Next Installment Date:"+alArrayList1.get(0).NextPayDate,"false");
				}
				
				printValues.add(" ","false");
				printValues.add(intialParametrsDO.ReceiptFooter,"true");
				printValues.add(" ","false");
				printValues.add(" ","false");
				printValues.add(" ","false");
			}
		}
		isPrintTaken = true;
		return printValues.getDetailObj();
	}
}
