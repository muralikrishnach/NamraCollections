package com.jayam.impactapp.adapters;

import java.util.List;

import com.jayam.impactapp.GroupDetails_Centerwise;
import com.jayam.impactapp.R;
import com.jayam.impactapp.database.RegularDemandsBL;
import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.RegularDemandsDO;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class GroupsAdapter_Centerwise extends GenericAdapter {
    public GroupsAdapter_Centerwise(Context context, List<? extends BaseDO> listItems) {
	super(context, listItems);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
	RegularDemandsDO regularDemandsDO = (RegularDemandsDO) getList().get(position);
	convertView = getLayoutInflater().inflate(R.layout.center_cell, null);
	TextView tvCenterName = (TextView) convertView.findViewById(R.id.tvCenterName);
	ImageView imgConfirmed = (ImageView) convertView.findViewById(R.id.imgConfirmed);

	RegularDemandsBL bl = new RegularDemandsBL();
	String fullpaymnet = bl.CheckForFullpayMent(regularDemandsDO.GNo);
	if (fullpaymnet != null && fullpaymnet.equalsIgnoreCase("0")) {
	    imgConfirmed.setVisibility(View.VISIBLE);
	} else {
	    imgConfirmed.setVisibility(View.GONE);
	}

	tvCenterName.setText("" + regularDemandsDO.GroupName + "-" + regularDemandsDO.GNo);

	Log.e("position", "" + position);
	convertView.setTag(regularDemandsDO);
	convertView.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		RegularDemandsDO regularDemandsDO = (RegularDemandsDO) v.getTag();
		Intent intent = new Intent(mContext, GroupDetails_Centerwise.class);
		intent.putExtra("groupnumber", regularDemandsDO.GNo);
		((Activity) (mContext)).startActivityForResult(intent, 0);

	    }
	});
	return convertView;
    }

}
