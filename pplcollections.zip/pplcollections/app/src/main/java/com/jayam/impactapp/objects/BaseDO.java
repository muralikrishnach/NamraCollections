package com.jayam.impactapp.objects;

import java.io.Serializable;

public class BaseDO implements Serializable{

    public String id;
    public String name;

    public String UploadMembers;
    public String TotalUpload;

}
