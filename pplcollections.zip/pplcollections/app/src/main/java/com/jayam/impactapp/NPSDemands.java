package com.jayam.impactapp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import com.jayam.impactapp.businesslayer.GetDataBL;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.CustomDailoglistner;
import com.jayam.impactapp.common.DataListner;
import com.jayam.impactapp.database.IntialParametrsBL;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.IntialParametrsDO;
import com.jayam.impactapp.objects.NPSDemandDO;
import com.jayam.impactapp.utils.NetworkUtility;


import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NPSDemands extends Base implements DataListner{
	private LinearLayout llAdvacedemand;
	private GetDataBL getDataBL, checkDemands;

	private TextView tvNPSAmt,tvNPSAccounts;
	private IntialParametrsBL initialBL;
	private ArrayList<IntialParametrsDO> alArrayList;
	ArrayList<NPSDemandDO> oddemands;
	private String terminalId;
	private String dateNow;
	String printerAddress=null;
	
	@Override
	public void initialize() 
	{
		// TODO Auto-generated method stub
		
		intializeControlles();
		
		getDataBL = new GetDataBL(NPSDemands.this, NPSDemands.this);
		initialBL = new IntialParametrsBL();
		alArrayList = initialBL.SelectAll();
		terminalId = alArrayList.get(0).TerminalID;
		printerAddress = alArrayList.get(0).BTPrinterAddress;
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter=  new SimpleDateFormat("dd-MM-yyyy");
		 dateNow = formatter.format(currentDate.getTime());
		 
		if(NetworkUtility.isNetworkConnectionAvailable(NPSDemands.this))
		{
			ShowLoader();	
			getDataBL.getNPSDemands(terminalId);
		}
		else
		{
			showAlertDailog(getResources().getString(R.string.nonetwork));
		}
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent(NPSDemands.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
				//finish();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llAdvacedemand					=	(LinearLayout)inflater.inflate(R.layout.npsdemands, null);
		tvNPSAmt						=	(TextView)llAdvacedemand.findViewById(R.id.tvNPSAmt);
		tvNPSAccounts					=	(TextView)llAdvacedemand.findViewById(R.id.tvNPSAccounts);
		
		llBaseMiddle.addView(llAdvacedemand, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		
		tvHeader.setText("NPS Downloaded Successfully");
	}

	@SuppressWarnings("unchecked")
	@Override
	public void onDataretrieved(Object objs) 
	{
		// TODO Auto-generated method stub
		oddemands =  (ArrayList<NPSDemandDO>) objs;
		int totalDemands = oddemands.size();
		Log.e("onDataretrieved", "Success"+totalDemands);
		if(totalDemands==1){
			HideLoader();
			showAlertDailog1("NPS Demand already Downloaded");
		}else{
			float totalAmountTobeColleted = 0;
			for(int i=0 ; i< totalDemands; i++)
			{
				NPSDemandDO demandsDO = oddemands.get(i);
				totalAmountTobeColleted = totalAmountTobeColleted +(Float.valueOf(demandsDO.RenewalAmt.trim()).floatValue());
			}
			Log.e("onDataretrieved", "Success"+totalAmountTobeColleted);
			tvNPSAccounts.setText(""+totalDemands);
			tvNPSAmt.setText(""+totalAmountTobeColleted);
			
			checkDemands = new GetDataBL(NPSDemands.this, new DataListner()
			{
				@Override
				public void onDataretrieved(Object objs) 
				{
					Log.e("onDataretrieved", "verify="+objs);
					showAlertDailog("NPS Demand Downloaded Successfully", "OK", null, new CustomDailoglistner() {
						
						@Override
						public void onPossitiveButtonClick(DialogInterface dialog) 
						{
							dialog.dismiss();
							finish();
						}
						
						@Override
						public void onNegativeButtonClick(DialogInterface dialog) 
						{
							// TODO Auto-generated method stub
							
						}
					});
				}
				
				@Override
				public void onDataretrievalFailed(String errorMessage)
				{
					Log.e("onDataretrievalFailed", "verify"+errorMessage);
					showAlertDailog("NPS Demand Sync Failed,Pls try again later", "OK", null, new CustomDailoglistner() {
						
						@Override
						public void onPossitiveButtonClick(DialogInterface dialog) 
						{
							NPSDemandBL nps=new NPSDemandBL();
							nps.Truncatetabel();
							dialog.dismiss();
							finish();
						}
						
						@Override
						public void onNegativeButtonClick(DialogInterface dialog) 
						{
							// TODO Auto-generated method stub
							
						}
					});
				}
			});
			
			checkDemands.verifyNPSDownloads(terminalId, dateNow, ""+oddemands.size(),printerAddress);
			HideLoader();
			Log.e("onDataretrieved", "Success");
		}
	}

	@Override
	public void onDataretrievalFailed(String errorMessage)
	{
		HideLoader();
		Log.e("onDataretrievalFailed", "failed");
		showAlertDailog("No NPS Demand Accounts", "OK", null, new CustomDailoglistner() {
			
			@Override
			public void onPossitiveButtonClick(DialogInterface dialog) 
			{
				dialog.dismiss();
				finish();
			}
			
			@Override
			public void onNegativeButtonClick(DialogInterface dialog) 
			{
				// TODO Auto-generated method stub
				
			}
		});
	}

}
