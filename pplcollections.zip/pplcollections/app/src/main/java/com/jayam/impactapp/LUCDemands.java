package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.businesslayer.GetDataBL;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.CustomDailoglistner;
import com.jayam.impactapp.common.DataListner;
import com.jayam.impactapp.database.IntialParametrsBL;
import com.jayam.impactapp.database.LUCDemandsBL;
import com.jayam.impactapp.objects.IntialParametrsDO;
import com.jayam.impactapp.objects.LucDemandsDO;
import com.jayam.impactapp.utils.NetworkUtility;


import android.content.DialogInterface;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LUCDemands extends Base implements DataListner {

    private LinearLayout llNewdemand;
    private GetDataBL getDataBL, getData_downloadStatus;
    private String demandDate;
    private TextView tvToatalDemands, tvAmountTobeCollected, tv1, tv2;
    private LUCDemandsBL lucDemandsBL;
    private IntialParametrsBL intialParametrsBL;
    private ArrayList<IntialParametrsDO> alIntialParametrsDOs;

    @Override
    public void initialize() {
	// TODO Auto-generated method stub
	demandDate = getIntent().getExtras().getString("Date");
	intializeControlles();
	intialParametrsBL = new IntialParametrsBL();
	lucDemandsBL = new LUCDemandsBL();
	alIntialParametrsDOs = intialParametrsBL.SelectAll();
	getDataBL = new GetDataBL(LUCDemands.this, LUCDemands.this);
	if (NetworkUtility.isNetworkConnectionAvailable(LUCDemands.this)) {
	    String userID = alIntialParametrsDOs.get(0).TerminalID;
	    if (!lucDemandsBL.isAvailable(demandDate)) {
		ShowLoader();
		getDataBL.getNewLUCDemands(userID, demandDate);
	    } else {
		tvToatalDemands.setText(lucDemandsBL.getrowCount());
		showAlertDailog("Already LUC Demands Downloaded", "OK", new CustomDailoglistner() {

		    @Override
		    public void onPossitiveButtonClick(DialogInterface dialog) {
			dialog.dismiss();
			finish();
		    }

		    @Override
		    public void onNegativeButtonClick(DialogInterface dialog) {
			// TODO Auto-generated method stub

		    }
		});
	    }
	} else {
	    showAlertDailog(getResources().getString(R.string.nonetwork));
	}
    }

    public void intializeControlles() {
	llNewdemand = (LinearLayout) inflater.inflate(R.layout.newdemanddates, null);
	tvToatalDemands = (TextView) llNewdemand.findViewById(R.id.tvToatalDemands);
	tvAmountTobeCollected = (TextView) llNewdemand.findViewById(R.id.tvAmountTobeCollected);
	tv1 = (TextView) llNewdemand.findViewById(R.id.tvNewDemand1);
	tv2 = (TextView) llNewdemand.findViewById(R.id.tvNewDemand);
	tv2.setText("Total Number of LUC Demands :");
	llBaseMiddle.addView(llNewdemand, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
	tvHeader.setText("LUC Demands");
	tvAmountTobeCollected.setVisibility(View.GONE);
	tv1.setVisibility(View.GONE);
    }

    @Override
    public void onDataretrieved(Object objs) {
	// TODO Auto-generated method stub
	ArrayList<LucDemandsDO> alregulardemnads = (ArrayList<LucDemandsDO>) objs;
	int totalDemands = alregulardemnads.size();
	Log.e("onDataretrieved", "Success" + totalDemands);
	tvToatalDemands.setText("" + totalDemands);
	HideLoader();
	Log.e("onDataretrieved", "Success");
	showAlertDailog("LUC Demands Downloaded Successfully", "OK", null, new CustomDailoglistner() {

	    @Override
	    public void onPossitiveButtonClick(DialogInterface dialog) {
		dialog.dismiss();
		setResult(AppConstants.RESULTCODE_HOME);
		finish();
	    }

	    @Override
	    public void onNegativeButtonClick(DialogInterface dialog) {
		// TODO Auto-generated method stub

	    }
	});
    }

    @Override
    public void onDataretrievalFailed(String errorMessage) {
	// TODO Auto-generated method stub
	HideLoader();
	Log.e("onDataretrievalFailed", "failed");
	showAlertDailog(errorMessage, "OK", null, new CustomDailoglistner() {

	    @Override
	    public void onPossitiveButtonClick(DialogInterface dialog) {
		dialog.dismiss();
		finish();
	    }

	    @Override
	    public void onNegativeButtonClick(DialogInterface dialog) {
		// TODO Auto-generated method stub

	    }
	});
    }

}
