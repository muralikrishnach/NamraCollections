package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.PrintListner;
import com.jayam.impactapp.common.PrintValues;
import com.jayam.impactapp.database.IntialParametrsBL;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.IntialParametrsDO;
import com.jayam.impactapp.objects.NPSDemandDO;
import com.jayam.impactapp.objects.PrintDetailsDO;
import com.jayam.impactapp.utils.PrintUtils;
import com.jayam.impactapp.utils.StringUtils;


import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NPSGroupDetails_Reports extends Base implements PrintListner
{
	private LinearLayout llAck;
	private TextView tvNPSRCName,tvNPSRGName,tvNPSRTotReAmt,tvNPSRCollAmt,tvNPSRBalRnAmt;
	private Button btnGroupMenu, btnPrint;
	private String GroupName,GroupCode;
	private NPSDemandBL trnsactionsBL;
	private ArrayList<NPSDemandDO> alArrayList;
	private float RenewalAmt=0,CollAmt=0,AmtTobeColl=0;
	int Count=0;
	private IntialParametrsBL intialParametrsBL;
	
	ArrayList<IntialParametrsDO> alIntialParametrsDOs;
	private Integer DUPCOUNT=0;
	private boolean isPrintTaken=false;
	
	@Override
	public void initialize()
	{
		GroupName		=	getIntent().getExtras().getString("GroupName");
		GroupCode		=	getIntent().getExtras().getString("GroupCode");

		intializeControlles();
		trnsactionsBL = new NPSDemandBL();
		alArrayList = trnsactionsBL.SelectReportsData(GroupCode,"Group");
		intialParametrsBL = new  IntialParametrsBL();
		alIntialParametrsDOs = intialParametrsBL.SelectAll();
		IntialParametrsDO intialParametrsDO = alIntialParametrsDOs.get(0);
		String Print=intialParametrsDO.PrintValidate;
		if(Print.equals("0"))
		{
			btnPrint.setVisibility(View.GONE);
		}
		tvNPSRGName.setText(""+GroupName);
		String CName="";
		for(NPSDemandDO Obj : alArrayList)
		{
			RenewalAmt=RenewalAmt+Float.valueOf(Obj.RenewalAmt);
			CollAmt=CollAmt+Float.valueOf(Obj.CollectedAmt);
			AmtTobeColl=AmtTobeColl+Float.valueOf(Obj.RenewalAmt)-Float.valueOf(Obj.CollectedAmt);
			Count=Count+1;
			if(Count==1)
			{
				CName=Obj.CName;
			}
		}
		tvNPSRCName.setText(CName);
		tvNPSRTotReAmt.setText(""+RenewalAmt);
		tvNPSRCollAmt.setText(""+CollAmt);
		tvNPSRBalRnAmt.setText(""+AmtTobeColl);
		
		
		btnGroupMenu.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				Intent intent = new Intent(NPSGroupDetails_Reports.this, NPSMembers_Reports.class);
				intent.putExtra("GroupCode", GroupCode);
				startActivityForResult(intent, 1234);
			}
		});
		
		btnPrint.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				int DupNo=Integer.valueOf(trnsactionsBL.MinDupNo(GroupCode,"Group"));
				if(DupNo<3)
				{
					BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();
					if (bluetooth.isEnabled()) 
					{
						PrintUtils printUtils = new PrintUtils(NPSGroupDetails_Reports.this, NPSGroupDetails_Reports.this);
						printUtils.print();
					}
					else
					{
						showAlertDailog("Please Switch On Mobile Bluetooth");
						return;
					}
				}else
				{
					showAlertDailog("Maximum No Of Prints are completed for this Group");
					return;
				}
			}
		});
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent(NPSGroupDetails_Reports.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
			//	finish();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llAck						=	(LinearLayout)inflater.inflate(R.layout.npscollreports, null);
		tvNPSRCName					=	(TextView)llAck.findViewById(R.id.tvNPSRCName);
		tvNPSRGName					=	(TextView)llAck.findViewById(R.id.tvNPSRGName);
		
		tvNPSRTotReAmt				=	(TextView)llAck.findViewById(R.id.tvNPSRTotReAmt);
		tvNPSRCollAmt				=	(TextView)llAck.findViewById(R.id.tvNPSRCollAmt);
		tvNPSRBalRnAmt				=	(TextView)llAck.findViewById(R.id.tvNPSRBalRnAmt);

		btnGroupMenu				=	(Button)llAck.findViewById(R.id.btnNPSRGroups);
		btnPrint					=	(Button)llAck.findViewById(R.id.btnNPSRPrint);
		LinearLayout llMember		=	(LinearLayout)llAck.findViewById(R.id.llNPSRMember);
		LinearLayout llReneDate		=	(LinearLayout)llAck.findViewById(R.id.llNPSRenewalDate);
		
		btnGroupMenu.setText("Members");
		llMember.setVisibility(View.GONE);
		llReneDate.setVisibility(View.GONE);
		
		
		svBase.setVisibility(View.GONE);
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llAck, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		showHomeIcons();
        ivLogout.setVisibility(View.GONE);
		tvHeader.setText("Group Summary");
	}

	@Override
	public PrintDetailsDO getprintObject() 
	{
		PrintValues printValues = new PrintValues();
		NPSDemandBL transbl=new NPSDemandBL();
		ArrayList<NPSDemandDO> alDistincttxncode = transbl.SelectDistinctTransactioncodeFromCenter(GroupCode,"Group");
		IntialParametrsDO intialParametrsDO = alIntialParametrsDOs.get(0);
		if(intialParametrsDO.IndividualReceipts.equalsIgnoreCase("1"))
		{
			for(int i =0 ; i < alDistincttxncode.size(); i++ )
			{
				NPSDemandBL transbl1=new NPSDemandBL();
				ArrayList<NPSDemandDO> alArrayList = transbl1.SelectAllTransactions(alDistincttxncode.get(i).TXNCode);
				for(int j=0 ; j <alArrayList.size(); j++ )
				{
					NPSDemandDO obj=alArrayList.get(j);
					NPSDemandDO npsDemandsDo=trnsactionsBL.SelectAll(obj.MLAI_ID, "Member").get(0);
					DUPCOUNT=  Integer.valueOf(transbl.getDupNoforMember(obj.MLAI_ID,alDistincttxncode.get(i).TXNCode));
					String recnum=StringUtils.getRecieptNumberForNPS(obj);
					if(DUPCOUNT<3)
					{
						String header=intialParametrsDO.ReceiptHeader;
			            String[] head = header.split("@");
			            String head1=head[0];
			            String head2=head[1];
			            String head3=head[2];
			            printValues.add(head1,"true");
						if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
			            { }
			            else
			            {
			            	printValues.add(head2,"true");
			            }
			             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
			            { }
			            else
			            {
			            	printValues.add(head3,"true");
			            }
						printValues.add(" ","false");
						DUPCOUNT=DUPCOUNT+1;
						printValues.add("Duplicate NPS TXN Acknowledgment "+DUPCOUNT,"true");
						printValues.add("----------------------------","true");
						printValues.add(" ","false");
						printValues.add("R.No:"+recnum,"false");
						printValues.add("Date:"+obj.DemandDT,"false");
						printValues.add(" ","false");
						printValues.add("Center:"+npsDemandsDo.CName,"false");
						printValues.add("Group:"+npsDemandsDo.GName,"false");
						printValues.add("Member:"+obj.MName+"("+npsDemandsDo.MMI_Code+")","false");
						printValues.add("Loan A/C No:"+obj.MLAI_ID,"false");
						printValues.add("Rnwl Installment No:"+obj.InstallNo,"false");
						printValues.add("Next Rnwl Date:"+obj.NxtRenDate,"false");
						printValues.add("Rnwl Due/Arrears Amt:"+obj.RenewalAmt,"false");
						printValues.add("Collectied Amount:"+obj.CollectedAmt,"false");
						printValues.add(" ","false");
						printValues.add(intialParametrsDO.ReceiptFooter,"true");
						trnsactionsBL.updateDupNO(String.valueOf(DUPCOUNT),obj.MLAI_ID,alDistincttxncode.get(i).TXNCode);
					}
				}
			}
		}else{
			for(int i =0 ; i < alDistincttxncode.size(); i++ )
			{
				float totaldemand=0,totalcollection=0;
				ArrayList<NPSDemandDO> alArrayList = transbl.SelectAllGroupTransactions(alDistincttxncode.get(i).TXNCode, GroupCode);		
				int DupNo=Integer.valueOf(trnsactionsBL.SelectMinDupNo(alDistincttxncode.get(i).TXNCode,GroupCode,"Group"));
				if(DupNo<3){
					String header=intialParametrsDO.ReceiptHeader;
		            String[] head = header.split("@");
		            String head1=head[0];
		            String head2=head[1];
		            String head3=head[2];
		            printValues.add(head1,"true");
					if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head2,"true");
		            }
		             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head3,"true");
		            }
					printValues.add(" ","false");
					
					DupNo=DupNo+1;
					printValues.add("Duplicate Nps TXN Acknowledgment "+DupNo,"true");
					printValues.add("------------------------------","true");
					printValues.add(" ","false");
					printValues.add("Date:"+alArrayList.get(0).DemandDT,"false");
					printValues.add("Group R.No:"+alDistincttxncode.get(i).TXNCode,"false");
					printValues.add("Center:"+alArrayList.get(0).CName,"false");
					printValues.add("Group:"+alArrayList.get(0).GName,"false");
					for(int j=0 ; j <alArrayList.size(); j++ )
					{
						NPSDemandDO obj = alArrayList.get(j);
						NPSDemandDO advanceDemandsDO = trnsactionsBL.SelectAll(obj.MLAI_ID, "memeber").get(0);
						printValues.add(" ","false");
						printValues.add("Name:"+obj.MName+"("+advanceDemandsDO.MMI_Code+")","false");
						printValues.add("Loan A/C No:"+advanceDemandsDO.MLAI_ID,"false");
						printValues.add("Next Rnwl Date:"+advanceDemandsDO.NxtRenDate,"false");
						printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
						printValues.add("Bal. Rnwl/Arrs Amt:"+advanceDemandsDO.BalanceAmt,"false");
						totaldemand=totaldemand+Float.valueOf(advanceDemandsDO.RenewalAmt);
						totalcollection=totalcollection+Float.valueOf(obj.CollectedAmt);
					}
					printValues.add(" ","false");
					printValues.add("Total Group Rnwl Amt :"+totaldemand,"false");
					printValues.add("Total Group Coll amount :"+totalcollection,"false");
					printValues.add(" ","false");
					printValues.add(intialParametrsDO.ReceiptFooter,"true");
					printValues.add(" ","false");
					printValues.add(" ","false");
					trnsactionsBL.updateDupNoingroup(GroupCode,alDistincttxncode.get(i).TXNCode,"Group");
				}
			}
		}
		isPrintTaken = true;
		return printValues.getDetailObj();
	}

}
