package com.jayam.impactapp.webacceslayer;

import android.app.Service;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jayam.impactapp.DataSync;
import com.jayam.impactapp.businesslayer.GetDataBL;
import com.jayam.impactapp.common.ApiClient;
import com.jayam.impactapp.common.ApiInterfaceImage;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.DataListner;
import com.jayam.impactapp.common.ServiceURLs;
import com.jayam.impactapp.database.AdvanceDemandBL;
import com.jayam.impactapp.database.IntialParametrsBL;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.database.ODDemandsBL;
import com.jayam.impactapp.database.RegularDemandsBL;
import com.jayam.impactapp.database.RegularDemandsBLTemp;
import com.jayam.impactapp.database.Transaction_OD_BL;
import com.jayam.impactapp.database.TrnsactionsBL;
import com.jayam.impactapp.objects.AdvaceDemandDO;
import com.jayam.impactapp.objects.IntialParametrsDO;
import com.jayam.impactapp.objects.LucDemandsDO;
import com.jayam.impactapp.objects.NPSDemandDO;
import com.jayam.impactapp.objects.ODDemandsDO;
import com.jayam.impactapp.objects.RegularDemandsDO;
import com.jayam.impactapp.utils.BitMapUtils;
import com.jayam.impactapp.utils.NetworkUtility;
import com.jayam.impactapp.utils.SharedPrefUtils;
import com.jayam.impactapp.utils.StringUtils;
import com.jayam.impactapp.utils.UtilClass;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by administrator_pc on 16-05-2018.
 */

public class RegularScheduleService extends Service {
    private Stack<String> image_names = new Stack<String>();;
    public static String TOTAL_ACCOUNTS_REG;
    RegularDemandsBLTemp demandsBLTemp;
    private RegularDemandsBL regularDemandsBL;
    private ArrayList<RegularDemandsDO> alRegularDemands;
    private TrnsactionsBL trnsactionsBL;
    private IntialParametrsBL intialParametrsBL;
    AdvanceDemandBL advanceBL;
    public String printerAddress = null;
    public String ReceiptNo = null;
    public String TxnCode = null;
    public String macid = null;
    ArrayList<IntialParametrsDO> alIntialParametrsDOs;
    IntialParametrsDO intialParametrsDO;
    String GroupId="";
    String userID="";
    int regcount=0;
    private File root;
    String TOTAL_AMT_UPLOADED_REG;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    String uid="";
    String  ImageName="";
    @Override
    public void onCreate() {
        regularDemandsBL = new RegularDemandsBL();
        trnsactionsBL = new TrnsactionsBL();
        intialParametrsBL = new IntialParametrsBL();
        demandsBLTemp = new RegularDemandsBLTemp();
        Timer t = new Timer();
                t.scheduleAtFixedRate(new TimerTask() {
                                  @Override
                                  public void run() {
                                       userID = SharedPrefUtils.getKeyValue(RegularScheduleService.this, AppConstants.pref_name, AppConstants.username);
                                      alRegularDemands = trnsactionsBL.SelectAllFlagwise();
                                      alIntialParametrsDOs = intialParametrsBL.SelectAll();
                                      root = new File(Environment.getExternalStorageDirectory() + File.separator + AppConstants.FolderName + File.separator);
                                      if (root != null && root.list() != null && root.list().length > 0) {
                                          String[] files = root.list();
                                          for (String file : files) {
                                              Log.v("","filename"+file);
                                              image_names.push(file);
                                          }
                                      }

                                      macid = SharedPrefUtils.getKeyValue(RegularScheduleService.this, AppConstants.pref_name, AppConstants.macid);
                                      try {
                                          Thread.sleep(3000);
                                      } catch (InterruptedException e) {
                                          e.printStackTrace();
                                      }
                                      if(alIntialParametrsDOs!=null)
                                      {
                                          try
                                          {
                                              intialParametrsDO=alIntialParametrsDOs.get(0);
                                          }catch (IndexOutOfBoundsException in)
                                          {
                                              in.printStackTrace();
                                          }
                                      }
                                      if(intialParametrsDO!=null)
                                      {
                                          printerAddress = intialParametrsDO.BTPrinterAddress;
                                          ReceiptNo = intialParametrsDO.LastTransactionID;
                                          TxnCode = intialParametrsDO.LastTransactionCode;
                                           uid = intialParametrsDO.TerminalID;
                                      }

                                      if(alRegularDemands!=null&&alRegularDemands.size()>0)
                                      {
                                          regcount=alRegularDemands.size();
                                           GroupId="";
                                          if(alRegularDemands!=null)
                                          {
                                              try
                                              {
                                                  GroupId=alRegularDemands.get(0).GNo;
                                                  TOTAL_ACCOUNTS_REG = regularDemandsBL.getTOTALRegularAccountsGroupId(GroupId);
                                                  TOTAL_AMT_UPLOADED_REG = regularDemandsBL.getTOTALDemandAmountForRegularGroupId(GroupId);

                                                  Log.v("","GroupIdva"+GroupId);
                                              }catch (IndexOutOfBoundsException in)
                                              {
                                                  in.printStackTrace();
                                              }
                                          }
                                      }


                                   Log.v("","regcount"+regcount);
                                      if (regcount > 0) {
                                          String Rcollection="";


                                           Rcollection = StringUtils.getSoapString(RegularScheduleService.this, alRegularDemands);

                                          Log.v("","Rcollection"+Rcollection);
                                          if(Rcollection!=null&&!Rcollection.isEmpty())
                                          {
                                              if (NetworkUtility.isNetworkConnectionAvailable(RegularScheduleService.this)) {
                                                  trnsactionsBL.UpdateRegCollection(GroupId,"P", UtilClass.UploadCurrentDate());
                                                  new UploadAsync().execute( Rcollection);
                                              }

                                          }

                                      }
                                      uploadBitMaps();


                                      }
                }, 3000, 6000);// 5 Minutes


    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }



    class UploadAsync extends AsyncTask<String, Void, ArrayList<String>> {
        ArrayList<String> counts = null;
        String countvar="";
        String data="";
        protected ArrayList<String> doInBackground(String... arg0) {
            // TODO Auto-generated method stub
             data=arg0[0];
            String url= ServiceURLs.mailURl+"RegularCollectionUploads.aspx";
            Log.v("safal","Final URL"+ url);
            ArrayList<NameValuePair> namevaluepair=new ArrayList<NameValuePair>();
            namevaluepair.add(new BasicNameValuePair("RegularCollstring", data));
            namevaluepair.add(new BasicNameValuePair("uid", userID));
            namevaluepair.add(new BasicNameValuePair("MACID", macid));
            namevaluepair.add(new BasicNameValuePair("BTAddress", printerAddress));
            namevaluepair.add(new BasicNameValuePair("MaxReceiptNo", ReceiptNo));
            namevaluepair.add(new BasicNameValuePair("MaxTxnCode", TxnCode));
            namevaluepair.add(new BasicNameValuePair("GroupID", GroupId));

            String s = url;
            s = s.replaceAll(" ", "%20");
            Log.v("safal","Final data"+ s);
            Log.v("safal","Final data"+ data);
            try {
                int timeoutConnection = 5000;
                int timeoutSocket = 15000;
                HttpParams httpParameters = new BasicHttpParams();
                HttpConnectionParams.setConnectionTimeout(httpParameters, timeoutConnection);
                HttpConnectionParams.setSoTimeout(httpParameters, timeoutSocket);

                DefaultHttpClient httpClient = new DefaultHttpClient(httpParameters);
                HttpPost httppost = new HttpPost(s);
                httppost.setEntity(new UrlEncodedFormEntity(namevaluepair));
                HttpResponse hres = httpClient.execute(httppost);
                countvar = EntityUtils.toString(hres.getEntity());
                counts = new ArrayList<String>();
                Log.v("", "upload json counts"+countvar);
                JSONObject js;
                try {

                    Log.v("", "upload json string"+s);
                    js = new JSONObject(countvar);
                    counts.add(js.getString("GroupID"));
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            } catch (ClientProtocolException e) {

            } catch (IOException e) {
            }
            return counts;
        }

        @SuppressWarnings("deprecation")
        @Override
        protected void onPostExecute(ArrayList<String> result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            if (result != null) {
                if(!result.isEmpty())
                {
                    String Message="";
                    try
                    {
                        Message	= result.get(0);
                    }catch (IndexOutOfBoundsException in)
                    {
                        in.printStackTrace();
                    }
                    Log.v("","Message"+Message);

                        if(Message!=null&&!Message.isEmpty())
                        {
                            trnsactionsBL.InsertServerCollectionUploadData("RCollectiion",TOTAL_ACCOUNTS_REG,TOTAL_AMT_UPLOADED_REG,data);
                            regularDemandsBL.TruncatetabelGroupId(Message);
                            trnsactionsBL.TruncatetabelGroupId(Message);
                            demandsBLTemp.TruncatetabelGroupId(Message);


                        }


                }
            }

        }


    }

    public void uploadBitMaps() {
        String xex = "";




        if (image_names.size() > 0) {

            ImageName = image_names.pop();

            Log.v("","memImageName"+ImageName);

            File mediaStorageDir = new File(root.getAbsolutePath()+"/"+ImageName);
            String pathvariable=mediaStorageDir.getAbsolutePath();
            Log.v("","pathvariable"+pathvariable);
            xex =pathvariable;

            ApiInterfaceImage apiService = ApiClient.getClient().create(ApiInterfaceImage.class);
            final File file = new File(xex);
            Log.v("", "filegetname" + file.getName());
            RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
            MultipartBody.Part body = MultipartBody.Part.createFormData("uploaded_file", file.getName(), requestFile);
            //  Call<ResponseBody> resultCall = ImageAPIService.uploadImage(body);
            Call<ResponseBody> resultCall = apiService.uploadImage(body);
            resultCall.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                    String messagev = "";
                    try {
                        if (response != null) {
                            if (response.body() != null) {
                                messagev = response.body().string();
                                Log.v("", "messagevaluehhv" + messagev);
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Log.v("", "messageafter" + messagev);
                    if (messagev != null && !messagev.isEmpty()) {
                        messagev = messagev.replace("\"", "");
                        Log.v("", "messagevnotnull" + messagev);
                        Log.v("", "messagevif)" + messagev);
                        if (root.isDirectory()) {
                            Log.v("", "messagev" + messagev);
                            new File(root, messagev).delete();
                            uploadBitMaps();
                        }


                    }

                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {




                }
            });
        }

    }


    public String GetDate()
    {
        Date endsd = new Date();
        String dateString = "";
        SimpleDateFormat sdfr = new SimpleDateFormat("yyyy-MM-dd");
        try {
            dateString = sdfr.format(endsd);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return  dateString;
    }
    public String GetCurrentdateNano()
    {
        Date endsd = new Date();
        String dateString = "";
        SimpleDateFormat sdfr = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        try {
            dateString = sdfr.format(endsd);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return  dateString;
    }

    public String GetCurrentdateNanoSeconds()
    {
        Date endsd = new Date();
        String dateString = "";
        SimpleDateFormat sdfr = new SimpleDateFormat("yyyyMMddHHmmssSSSSSSSSS");
        try {
            dateString = sdfr.format(endsd);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return  dateString;
    }
    public String GetCurrentdate()
    {
        Date endsd = new Date();
        String dateString = "";
        SimpleDateFormat sdfr = new SimpleDateFormat("yyyyMMddHHmmss");
        try {
            dateString = sdfr.format(endsd);
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return  dateString;
    }
}
