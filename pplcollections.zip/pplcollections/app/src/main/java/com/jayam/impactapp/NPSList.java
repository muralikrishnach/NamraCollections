package com.jayam.impactapp;

import com.jayam.impactapp.common.AppConstants;


import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;

public class NPSList extends Base 
{
	private LinearLayout llDashboard;
	private Button btnRenewals;
	@Override
	public void initialize() 
	{
		intializeControlles();
		
			
		btnRenewals.setOnClickListener(new OnClickListener()
			{
				
				@Override
				public void onClick(View v) 
				{
					startActivityForResult(new Intent(NPSList.this, NPSGroupsAndCenters.class),123);
					overridePendingTransition(R.anim.slide_left, R.anim.slide_right);
				}
			});
			
			ivLogout.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View v) 
				{
					Intent i = new Intent(NPSList.this,loginActivity.class);
					startActivity(i);
					//finish();
				}
			});
			
		
			ivHome.setOnClickListener(new  OnClickListener() 
			{
				@Override
				public void onClick(View v)
				{
					setResult(AppConstants.RESULTCODE_HOME);
					finish();
				}
			});
		
	}
	
	public void intializeControlles()
	{
		
		llDashboard 		= (LinearLayout)inflater.inflate(R.layout.npslist, null);
		btnRenewals			= (Button)llDashboard.findViewById(R.id.btnRenewals);
		ivLogout.setVisibility(View.VISIBLE);
		ivHome.setVisibility(View.VISIBLE);
		tvHeader.setText("NPS");
	}
	


}
