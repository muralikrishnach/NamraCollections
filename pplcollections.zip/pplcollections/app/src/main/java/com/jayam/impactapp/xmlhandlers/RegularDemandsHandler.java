package com.jayam.impactapp.xmlhandlers;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.jayam.impactapp.database.RegularDemandsBL;
import com.jayam.impactapp.database.RegularDemandsBLTemp;
import com.jayam.impactapp.objects.RegularDemandsDO;

public class RegularDemandsHandler extends BaseHandler {
    private StringBuffer appendString;
    private Boolean currentElement = false;
    private ArrayList<RegularDemandsDO> alRegularDemandsDOs;
    private RegularDemandsDO regularDemandsDO;
    RegularDemandsBL regularDemandsBL;
    RegularDemandsBLTemp regularDemandsBLTemp;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
	currentElement = true;
	appendString = new StringBuffer();
	regularDemandsBL = new RegularDemandsBL();
	regularDemandsBLTemp = new RegularDemandsBLTemp();
	if (localName.equalsIgnoreCase("NewDataSet")) {
	    alRegularDemandsDOs = new ArrayList<RegularDemandsDO>();
	} else if (localName.equalsIgnoreCase("RegDemands")) {
	    regularDemandsDO = new RegularDemandsDO();
	}
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
	currentElement = false;
	if (localName.equalsIgnoreCase("CNo")) {
	    regularDemandsDO.CNo = appendString.toString();
	} else if (localName.equalsIgnoreCase("CName")) {
	    regularDemandsDO.CName = appendString.toString();
	} else if (localName.equalsIgnoreCase("CNo")) {
	    regularDemandsDO.CNo = appendString.toString();
	} else if (localName.equalsIgnoreCase("GNo")) {
	    regularDemandsDO.GNo = appendString.toString();
	} else if (localName.equalsIgnoreCase("EII_EMP_ID")) {
	    regularDemandsDO.EII_EMP_ID = appendString.toString();
	} else if (localName.equalsIgnoreCase("GroupName")) {
	    regularDemandsDO.GroupName = appendString.toString();
	} else if (localName.equalsIgnoreCase("MemberCode")) {
	    regularDemandsDO.MemberCode = appendString.toString();
	} else if (localName.equalsIgnoreCase("MemberName")) {
	    regularDemandsDO.MemberName = appendString.toString();
	} else if (localName.equalsIgnoreCase("DemandDate")) {
	    regularDemandsDO.DemandDate = appendString.toString();
	} else if (localName.equalsIgnoreCase("MLAI_ID")) {
	    regularDemandsDO.MLAI_ID = appendString.toString();
	} else if (localName.equalsIgnoreCase("OSAmt")) {
	    regularDemandsDO.OSAmt = appendString.toString();
	} else if (localName.equalsIgnoreCase("DemandTotal")) {
	    regularDemandsDO.DemandTotal = appendString.toString();
	} else if (localName.equalsIgnoreCase("ODAmount")) {
	    regularDemandsDO.ODAmount = appendString.toString();
	} else if (localName.equalsIgnoreCase("Attendance")) {
	    regularDemandsDO.Attendance = appendString.toString();
	} else if (localName.equalsIgnoreCase("GLI")) {
	    regularDemandsDO.GLI = appendString.toString();
	} else if (localName.equalsIgnoreCase("Lateness")) {
	    regularDemandsDO.Lateness = appendString.toString();
	} else if (localName.equalsIgnoreCase("InstallNo")) {
	    regularDemandsDO.InstallNo = appendString.toString();
	} else if (localName.equalsIgnoreCase("SittingOrder")) {
	    regularDemandsDO.SittingOrder = appendString.toString();
	} else if (localName.equalsIgnoreCase("SO")) {
	    regularDemandsDO.SO = appendString.toString();
	} else if (localName.equalsIgnoreCase("NextRepayDate")) {
	    regularDemandsDO.NextRepayDate = appendString.toString();
	}
	else if (localName.equalsIgnoreCase("Renew")) {
	    regularDemandsDO.Renew = appendString.toString();
	}

	else if (localName.equalsIgnoreCase("MMI_Phone")) {
		regularDemandsDO.MobileNo = appendString.toString();
	}
	else if (localName.equalsIgnoreCase("primaryid")) {
		regularDemandsDO.AAdharNo = appendString.toString();
	}

	else if (localName.equalsIgnoreCase("CollectionMode")) {
		regularDemandsDO.BranchPaymode = appendString.toString();
	}

	else if (localName.equalsIgnoreCase("ProductName")) {
		regularDemandsDO.ProductName = appendString.toString();
	}
	else if (localName.equalsIgnoreCase("MobileNumber")) {
		regularDemandsDO.MobileNo = appendString.toString();
	}
	else if (localName.equalsIgnoreCase("LatitudeCenter")) {
		regularDemandsDO.LatitudeCenter = appendString.toString();
	}
	else if (localName.equalsIgnoreCase("LongitudeCenter")) {
		regularDemandsDO.LongitudeCenter = appendString.toString();
	}
	else if (localName.equalsIgnoreCase("LatitudeGroup")) {
		regularDemandsDO.LatitudeGroup = appendString.toString();
	}

	else if (localName.equalsIgnoreCase("LongitudeGroup")) {
		regularDemandsDO.LongitudeGroup = appendString.toString();
	}

	else if (localName.equalsIgnoreCase("LatitudeMember")) {
		regularDemandsDO.LatitudeMember = appendString.toString();
	}

	else if (localName.equalsIgnoreCase("LongitudeMember")) {
		regularDemandsDO.LongitudeMember = appendString.toString();
	}

	else if (localName.equalsIgnoreCase("RegDemands")) {
	    if (regularDemandsDO != null && regularDemandsDO.MLAI_ID != null) {
		regularDemandsBL.Insert(regularDemandsDO);
		regularDemandsBLTemp.Insert(regularDemandsDO);
		alRegularDemandsDOs.add(regularDemandsDO);
	    }

	}
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
	if (currentElement) {
	    appendString.append(ch, start, length);
	}
    }

    @Override
    public Object getData() {
	return alRegularDemandsDOs;
    }

    @Override
    public boolean getExecutionStatus() {
	if (alRegularDemandsDOs != null && alRegularDemandsDOs.size() > 0) {
	    return true;
	} else {
	    return false;
	}
    }

    @Override
    public String getErrorMessage() {
	return "Already Downloaded";
    }

}
