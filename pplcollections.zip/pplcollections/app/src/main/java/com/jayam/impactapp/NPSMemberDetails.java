package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.NPSDemandDO;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NPSMemberDetails extends Base
{
	private LinearLayout llCenterDetails;
	private TextView tvNPSMemebrName,tvNPSMemberCode,tvNPSRenDate, tvNPSRnwlInstallNo, tvNpsAmtColl;
	private EditText etNpsAmountTobeCollected;
	private NPSDemandDO npsDemandsDO;
	NPSDemandBL npsDemandBL;
	private String MLAID;
	private Button btnSave;
	private ArrayList<NPSDemandDO> alNPSDemands;
	float RnwlAmt=0;
	float PreCollAmt=0;
	
	
	@Override
	public void initialize() 
	{
		MLAID		= getIntent().getExtras().getString("MLAID");

		Log.e("MLAID",MLAID);
		npsDemandBL  = new NPSDemandBL();
		alNPSDemands = npsDemandBL.SelectAll(MLAID, "Memeber");
		npsDemandsDO = alNPSDemands.get(0);
		
		intializeControlles();
		
		tvNPSMemebrName.setText(""+npsDemandsDO.MName);
		tvNPSMemberCode.setText(""+npsDemandsDO.MMI_Code);
		tvNPSRenDate.setText(""+npsDemandsDO.NextPayDate);
		tvNPSRnwlInstallNo.setText(""+npsDemandsDO.InstallNo);
		tvNpsAmtColl.setText(""+npsDemandsDO.CollectedAmt);
		RnwlAmt=Float.valueOf(npsDemandsDO.RenewalAmt.trim()).floatValue();
		PreCollAmt=Float.valueOf(npsDemandsDO.CollectedAmt.trim()).floatValue();
		float AmtTobeColl=Float.valueOf(npsDemandsDO.RenewalAmt.trim()).floatValue()-Float.valueOf(npsDemandsDO.CollectedAmt.trim()).floatValue();
		etNpsAmountTobeCollected.setText(""+AmtTobeColl);
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent(NPSMemberDetails.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
				//finish();
			}
		});
		
		btnSave.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				String enterdAmount = etNpsAmountTobeCollected.getText().toString();
				
				float EntAmt=Float.valueOf(enterdAmount)+PreCollAmt;				
				
				if(enterdAmount.equalsIgnoreCase(""))
				{
					showAlertDailog("Please Enter Amount.");
				}
				float amount = Float.valueOf(enterdAmount.trim()).floatValue();
				if(amount==.0 || amount==.00)
				{
					showAlertDailog("Please Enter Valid Amount.");
				}
				else if(amount==0.0 || amount<=0)
				{
					showAlertDailog("Please Enter Amount Greater than Zero");
				}
				else if(amount<1.0){
					showAlertDailog("Please Enter Amount Greater than One Rupee");
				}
				else if(EntAmt>RnwlAmt)
				{
					showAlertDailog("Coll. Amt. cannot be more than Renewal Amt");
				}
				
				else
				{					
					savePayment(amount);
				}
				
			}
		});
		
		
		
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llCenterDetails			=	(LinearLayout)inflater.inflate(R.layout.npsmemberdetails, null);
		tvNPSMemebrName 		=	(TextView)llCenterDetails.findViewById(R.id.tvNPSMemebrName);
		tvNPSMemberCode 		=	(TextView)llCenterDetails.findViewById(R.id.tvNPSMemberCode);
		tvNPSRenDate 			=	(TextView)llCenterDetails.findViewById(R.id.tvNPSRenDate);		
		tvNPSRnwlInstallNo 		=	(TextView)llCenterDetails.findViewById(R.id.tvNPSRnwlInstallNo);
		tvNpsAmtColl 			=	(TextView)llCenterDetails.findViewById(R.id.tvNpsAmtColl);
		etNpsAmountTobeCollected=	(EditText)llCenterDetails.findViewById(R.id.etNpsAmountTobeCollected);
		btnSave 					=	(Button)llCenterDetails.findViewById(R.id.btnSave);
		
		
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llCenterDetails, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		showHomeIcons();
        ivLogout.setVisibility(View.GONE);
		tvHeader.setText("Member Detail");
		
	}
	public void savePayment(float paymnet)
	{
		float Bal=Float.valueOf(npsDemandsDO.RenewalAmt.trim()).floatValue()-paymnet;
		npsDemandBL.updateSavedAmt(npsDemandsDO.MLAI_ID, String.valueOf(paymnet).toString(),String.valueOf(Bal).toString());
		
		Intent intent = new Intent(this, NPSPaymentconfiramtion.class);
		Bundle bundle = new Bundle();
		bundle.putString("MemberName", ""+npsDemandsDO.MName);
		bundle.putString("MemberCode", ""+npsDemandsDO.MMI_Code);
		bundle.putString("DemandDate", ""+npsDemandsDO.NextPayDate);
		bundle.putString("paymnet", ""+paymnet);
		intent.putExtras(bundle);
		startActivityForResult(intent, 0);
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode == AppConstants.RESULTCODE_LOGOUT)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_HOME)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_CENTERDETAILS)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_GROPDETAILS)
		{
			setResult(resultCode);
			finish();
		}
	}

}
