package com.jayam.impactapp.database;

import java.util.ArrayList;

import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.FtodreasonsDO;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class FtodreasonsBL extends BaseBusinessLayer<FtodreasonsDO> {

	private ArrayList<FtodreasonsDO> allFtodreasons;
	private float amttobecollected;
	
	public void InsertArrayList(ArrayList<FtodreasonsDO> alFtodreasonsDO)
	{
		this.allFtodreasons = alFtodreasonsDO;
		
		for(int i=0 ; i< allFtodreasons.size(); i++)
		{
			FtodreasonsDO FtodreasonsDO = allFtodreasons.get(i);
			Insert(FtodreasonsDO);
		}
	}
	
	@Override
	public boolean Insert(BaseDO object)
	{
		FtodreasonsDO FtodreasonsDO = (FtodreasonsDO) object;
		
		try
		{
		  DatabaseHelper.openDataBase();
		}
		catch (Exception e) 
		{}
		
		ContentValues values = new ContentValues();
		
		values.put("ID", FtodreasonsDO.ID);
		values.put("FTODReason", FtodreasonsDO.FTODReason);
		
				
		try
		{
			SQLiteDatabase _database = DatabaseHelper.openDataBase();
			_database.insert("FTODs", null, values);
		}
		catch (Exception e) 
		{}
		return false;
	}

	@Override
	public boolean Update(BaseDO object)
	{
		// TODO Auto-generated method stub
		return false;
	}
	
	

	@Override
	public boolean Delete(BaseDO object) {
		
		try 
	  {
	   DatabaseHelper._database.execSQL("DELETE  FROM FTODs" );
	  } 
	  catch (Exception e) 
	  {  
		  Log.e("error occured while deleting data from table",e.toString());
	  }
	return false;
}

	
	@Override
	public ArrayList<FtodreasonsDO> SelectAll() 
	{
		ArrayList<FtodreasonsDO> vecRegularDemands = new ArrayList<FtodreasonsDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("select * from FTODs", null);
		   
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	FtodreasonsDO obj = 	new FtodreasonsDO();
		    	try
		    	{
		    	obj.ID		 =	c.getString(0);
		    	obj.FTODReason		 =	c.getString(1);
		    	
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    	
		     
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return vecRegularDemands;
	}
	public void updateFTODReasons(String Code , String ID, String Reason,String Date,String Type)
	{
		String query = null;
		if(Type.equalsIgnoreCase("Center")){
			query= "UPDATE RegularDemands SET FtodreasonID= '"+ID+"',Reason = '"+Reason+"',Demisedate='"+Date+"' where CNo = '"+Code+"' and CAST(ODAmount AS INT)=0";
		}else if(Type.equalsIgnoreCase("Group")){
			query = "UPDATE RegularDemands SET FtodreasonID= '"+ID+"',Reason = '"+Reason+"',Demisedate='"+Date+"' where GNo = '"+Code+"' and CAST(ODAmount AS INT)=0";
		}else if(Type.equalsIgnoreCase("Member")){
			query = "UPDATE RegularDemands SET FtodreasonID= '"+ID+"',Reason = '"+Reason+"',Demisedate='"+Date+"' where MLAI_ID = '"+Code+"'";
		}
		Log.e("updatequery", query);

		 SQLiteDatabase objSqliteDB = null;
		 try
			{
				objSqliteDB = DatabaseHelper.openDataBase();
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		 finally
			{
				if(objSqliteDB != null)
				{
					objSqliteDB.setTransactionSuccessful();
					objSqliteDB.endTransaction();
					objSqliteDB.close();
				}
			}
	}
	public void updateFTODReasonsTemp(String MLAID , String ID, String Reason,String Date)
	{
		String query = "UPDATE RegularDemandsTemp SET FtodreasonID= '"+ID+"',Reason = '"+Reason+"',Demisedate='"+Date+"' where MLAI_ID = '"+MLAID+"'";
		 Log.e("updatequery", query);
		 SQLiteDatabase objSqliteDB = null;
		 try
			{
				objSqliteDB = DatabaseHelper.openDataBase();
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		 finally
			{
				if(objSqliteDB != null)
				{
					objSqliteDB.setTransactionSuccessful();
					objSqliteDB.endTransaction();
					objSqliteDB.close();
				}
			}
	}
	public ArrayList<FtodreasonsDO> SelectAl() 
	{
		ArrayList<FtodreasonsDO> vecRegularDemands = new ArrayList<FtodreasonsDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("SELECT * FROM FTODs where ID not in (1,2)", null);
		   
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	FtodreasonsDO obj = 	new FtodreasonsDO();
		    	try
		    	{
		    	obj.ID		 	=	c.getString(0);
		    	obj.FTODReason	=	c.getString(1);
		    	
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    	
		     
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return vecRegularDemands;
	}
	
}
