package com.jayam.impactapp.database;

import java.util.ArrayList;

import com.jayam.impactapp.objects.AdvaceDemandDO;
import com.jayam.impactapp.objects.LastReceiptDO;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class LastRecieptBL 
{
	public void insert(String LastTxnId, String Print,String Type )
	{
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;
		query = "INSERT INTO LastReciept VALUES ('"+LastTxnId+"','"+Print+"','"+Type+"')";
	   try
		{
			objSqliteDB.beginTransaction();	
			SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
			sqLiteStatement.executeInsert();
			objSqliteDB.setTransactionSuccessful();
			objSqliteDB.endTransaction();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public String getcount()
	{
		String query = "SELECT count(*) from LastReciept";
		SQLiteDatabase sqLiteDatabase = DatabaseHelper.openDataBase();
		String count = "";
		 Cursor c = null;
		 try
		 {
			 c= sqLiteDatabase.rawQuery(query, null);
			 c.moveToFirst();
			 count=  c.getString(0);
		 }
		 catch(Exception exception)
		 {
			 
		 }
		return count;
	}
	public ArrayList<LastReceiptDO> SelectAll() {
		ArrayList<LastReceiptDO> vecRegularDemands = new ArrayList<LastReceiptDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {

		   c= _database.rawQuery("SELECT *  FROM LastReciept order by LastTxnId desc limit 1", null);
		   Log.e("Query:--","SELECT *  FROM LastReciept order by LastTxnId desc limit 1");
		   
		   if(vecRegularDemands != null)
		    vecRegularDemands.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	LastReceiptDO obj = 	new LastReceiptDO();
		    	try
		    	{
	    		obj.LastTxnId		=	c.getString(0);
	    		obj.Print		=	c.getString(1);
	    		obj.Type		=	c.getString(2);
	    		
		    	
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    
		     vecRegularDemands.add(obj);
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return vecRegularDemands;
}
	public void delete()
	{
		/*SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;
		query = "DELETE FROM LastReciept";
	   try
		{
			objSqliteDB.beginTransaction();	
			SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
			sqLiteStatement.executeInsert();
			objSqliteDB.setTransactionSuccessful();
			objSqliteDB.endTransaction();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}*/
	}
	public String  updateLastReceiptPrintFlag(String TxnCode, String status) 
	{
		String count = null ;
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("UPDATE LastReciept SET Print = '"+status+"' where LastTxnId = '"+TxnCode+"'", null);
		   
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	try
		    	{
		    		count = c.getString(0);
		    	}
		    	catch(Exception e)
		    	{
		    		Log.e("exception", "while getting from server");
		    	}
		    	
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  return count;

	}
}
