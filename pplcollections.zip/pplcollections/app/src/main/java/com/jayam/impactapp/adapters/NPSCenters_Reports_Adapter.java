package com.jayam.impactapp.adapters;

import java.util.ArrayList;
import java.util.List;

import com.jayam.impactapp.NPSCenterDetails_Reports;
import com.jayam.impactapp.R;
import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.NPSDemandDO;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

public class NPSCenters_Reports_Adapter extends GenericAdapter {

    private ArrayList<NPSDemandDO> alTransations;
    float collctdAmt = 0;
    String CenterName;

    public NPSCenters_Reports_Adapter(Context context, List<? extends BaseDO> listItems,
	    ArrayList<NPSDemandDO> alTransations) {
	super(context, listItems);
	this.alTransations = alTransations;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
	NPSDemandDO advaceDemandDO = (NPSDemandDO) getList().get(position);
	convertView = getLayoutInflater().inflate(R.layout.center_cell, null);
	TextView tvCenterName = (TextView) convertView.findViewById(R.id.tvCenterName);
	Log.e("position", "" + position);

	tvCenterName.setText("" + advaceDemandDO.CName);

	for (int i = 0; i < alTransations.size(); i++) {
	    String collctdAmt = advaceDemandDO.CollectedAmt;
	    tvCenterName.setText(advaceDemandDO.CName + " - (" + collctdAmt + ")");
	}

	convertView.setTag(advaceDemandDO);
	convertView.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		NPSDemandDO npsDemandDO = (NPSDemandDO) v.getTag();
		{
		    Intent intent = new Intent(mContext, NPSCenterDetails_Reports.class);
		    intent.putExtra("CenterName", npsDemandDO.CName);
		    intent.putExtra("CenterCode", npsDemandDO.CNo);
		    intent.putExtra("CollectedAmt", npsDemandDO.CollectedAmt);
		    ((Activity) (mContext)).startActivity(intent);
		}
	    }
	});
	return convertView;
    }

}
