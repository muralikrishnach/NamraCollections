package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.CustomDailoglistner;
import com.jayam.impactapp.common.PrintListner;
import com.jayam.impactapp.common.PrintValues;
import com.jayam.impactapp.database.IntialParametrsBL;
import com.jayam.impactapp.database.LastRecieptBL;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.database.TrnsactionsBL;
import com.jayam.impactapp.objects.IntialParametrsDO;
import com.jayam.impactapp.objects.NPSDemandDO;
import com.jayam.impactapp.objects.PrintDetailsDO;
import com.jayam.impactapp.objects.RegularDemandsDO;
import com.jayam.impactapp.utils.PrintUtils;
import com.jayam.impactapp.utils.SharedPrefUtils;
import com.jayam.impactapp.utils.StringUtils;


import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NPSTxnAck_CenterWise extends Base implements PrintListner
{
	private LinearLayout llAck;
	private TextView tvNPSreceiptno,tvNPSCenterName, tvNPSGroupName, tvNPSCollAmt,tvNPSRenewalAmt;
	private ArrayList<NPSDemandDO> alArrayList;
	private String CenterCode;
	private String LastTranScode;
	private Button btnadvMenu, btnPrint;
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;
    public static final String TOAST = "toast";
    private boolean isPrintTaken = false;
    float totAmt = 0;
	float totAmt_Collected = 0;
	float totDemand = 0;
	float collectedAmt = 0;
	float RenewalAmt = 0;
	int attendense = 0 ;
	LastRecieptBL recptBL;
	NPSDemandBL npsdemandBL;
	private ArrayList<IntialParametrsDO> alIntialParametrsDOs;
	private IntialParametrsBL intialParametrsBL;
	
	@Override
	public void initialize() 
	{
		recptBL = new LastRecieptBL();
		CenterCode = getIntent().getExtras().getString("CenterCode");
		LastTranScode = getIntent().getExtras().getString("LastTranScode");
		intializeControlles();
		
		npsdemandBL= new NPSDemandBL();
		alArrayList = npsdemandBL.SelectAll(CenterCode,"Center");
		intialParametrsBL = new  IntialParametrsBL();
		alIntialParametrsDOs = intialParametrsBL.SelectAll();
		tvNPSCenterName.setText(""+alArrayList.get(0).CName);
		tvNPSGroupName.setText(""+alArrayList.get(0).GName);
		tvNPSreceiptno.setText(""+LastTranScode);
		for(int i=0 ; i< alArrayList.size(); i++)
		{
			try
			{
				collectedAmt	= collectedAmt + Float.valueOf(alArrayList.get(i).CollectedAmt).floatValue() ;
				RenewalAmt		= RenewalAmt + Float.valueOf(alArrayList.get(i).RenewalAmt).floatValue() ;
			}
			catch (Exception e) 
			{
				Log.e("Exception", ""+e.toString());
			}
		}
		tvNPSCollAmt.setText(""+collectedAmt);
		tvNPSRenewalAmt.setText(""+RenewalAmt);
		
		btnadvMenu.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				if(!isPrintTaken)
				{
					showAlertDailog("Receipt is not printed. Are you sure want to exit the Menu ?", "OK", "Cancel", new CustomDailoglistner() 
					{
						@Override
						public void onPossitiveButtonClick(DialogInterface dialog)
						{
							dialog.dismiss();
							ShowLoader();
							new Thread(new  Runnable() 
							{
								public void run() 
								{
									// update print status Y/N
									recptBL.delete();
									recptBL.insert(LastTranScode,"N","N");
									npsdemandBL.updatePrintFlag(LastTranScode,"N") ;
									runOnUiThread(new  Runnable() {
										public void run() 
										{
											HideLoader();
											setResult(AppConstants.RESULTCODE_HOME);
											finish();
										}
									});
								}
							}).start();
						}
						@Override
						public void onNegativeButtonClick(DialogInterface dialog)
						{
							dialog.dismiss();
						}
					});
				}
				else
				{
					showAlertDailog("Receipt Printed Y / N ", "Yes", "No", new CustomDailoglistner() 
					{
						@Override
						public void onPossitiveButtonClick(DialogInterface dialog)
						{
							recptBL.updateLastReceiptPrintFlag(LastTranScode, "Y") ;
							dialog.dismiss();
							setResult(AppConstants.RESULTCODE_HOME);
							finish();
						}
						
						@Override
						public void onNegativeButtonClick(DialogInterface dialog)
						{
							dialog.dismiss();
							
							showAlertDailog("WARNING ! Do you want to overwrite printed confirmation, pls. confirm Y / N.", "Yes", "No", new CustomDailoglistner() 
							{
								@Override
								public void onPossitiveButtonClick(DialogInterface dialog)
								{
									recptBL.updateLastReceiptPrintFlag(LastTranScode, "N") ;
									dialog.dismiss();
									setResult(AppConstants.RESULTCODE_HOME);
									finish();
								}
								
								@Override
								public void onNegativeButtonClick(DialogInterface dialog)
								{
									recptBL.updateLastReceiptPrintFlag(LastTranScode, "Y") ;
									dialog.dismiss();
									setResult(AppConstants.RESULTCODE_HOME);
									finish();
								}
							});
						}
					});
				}
				//setResult(AppConstants.RESULTCODE_HOME);
			//	finish();
			}
				
		});
		
	btnPrint.setOnClickListener(new OnClickListener() 
      {
			@Override
			public void onClick(View v) 
			{
//				showAlertDailog("Center Wise Print Not Available");
				if(!isPrintTaken)
				{
//					showAlertDailog("Center Wise Print Not Available");
					BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();
					if (bluetooth.isEnabled()) 
					{
						ShowLoader();
						new Thread(new  Runnable() 
						{
							public void run() 
							{
								recptBL.delete();
								recptBL.insert(LastTranScode,"N","N");
								npsdemandBL.updatePrintFlag(LastTranScode, "Y");
								runOnUiThread(new Runnable() 
								{
									public void run() 
									{
										HideLoader();
										PrintUtils printUtils = new PrintUtils(NPSTxnAck_CenterWise.this, NPSTxnAck_CenterWise.this);
										printUtils.print();
									}
								});
							}
						}).start();
					}
					else
					{
						showAlertDailog("Please Switch On Mobile Bluetooth");
						return;
					}
					ShowLoader();
					new Thread(new  Runnable() 
					{
						public void run() 
						{
							recptBL.delete();
							recptBL.insert(LastTranScode,"N","N");
							npsdemandBL.updatePrintFlag(LastTranScode, "Y");
							runOnUiThread(new Runnable() 
							{
								public void run() 
								{
									HideLoader();
									PrintUtils printUtils = new PrintUtils(NPSTxnAck_CenterWise.this, NPSTxnAck_CenterWise.this);
									printUtils.print();
								}
							});
						}
					}).start();
				}
				else
				{
					showAlertDailog("Receipt Printed Y / N ", "Yes", "No", new CustomDailoglistner() 
					{
						@Override
						public void onPossitiveButtonClick(DialogInterface dialog)
						{
							recptBL.updateLastReceiptPrintFlag(LastTranScode, "Y") ;
							dialog.dismiss();
							setResult(AppConstants.RESULTCODE_HOME);
							finish();
						}
						@Override
						public void onNegativeButtonClick(DialogInterface dialog)
						{
							dialog.dismiss();
							showAlertDailog("WARNING ! Do you want to overwrite printed confirmation, pls. confirm Y / N.", "Yes", "No", new CustomDailoglistner() 
							{
								@Override
								public void onPossitiveButtonClick(DialogInterface dialog)
								{
									recptBL.updateLastReceiptPrintFlag(LastTranScode, "N") ;
									dialog.dismiss();
									setResult(AppConstants.RESULTCODE_HOME);
									finish();
								}
								@Override
								public void onNegativeButtonClick(DialogInterface dialog)
								{
									recptBL.updateLastReceiptPrintFlag(LastTranScode, "Y") ;
									dialog.dismiss();
									setResult(AppConstants.RESULTCODE_HOME);
									finish();
								}
							});
						}
					});
				}	
			}
		});
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_LOGOUT);
				finish();
			}
		});
		
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llAck				=	(LinearLayout)inflater.inflate(R.layout.npstxnack, null);
		tvNPSreceiptno		=	(TextView)llAck.findViewById(R.id.tvNPSreceiptno);
		tvNPSCenterName		=	(TextView)llAck.findViewById(R.id.tvNPSCenterName);
		tvNPSGroupName		=	(TextView)llAck.findViewById(R.id.tvNPSGroupName);
		LinearLayout llGroup=	(LinearLayout)llAck.findViewById(R.id.llGroup);
		tvNPSRenewalAmt		=	(TextView)llAck.findViewById(R.id.tvNPSRenewalAmt);
		tvNPSCollAmt		=	(TextView)llAck.findViewById(R.id.tvNPSCollAmt);
		btnadvMenu			=	(Button)llAck.findViewById(R.id.btnadvMenu);
		btnPrint			=	(Button)llAck.findViewById(R.id.btnadvPrint);
		
		svBase.setVisibility(View.GONE);
		llGroup.setVisibility(View.GONE);
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llAck, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		hidehomeIcons();
		tvHeader.setText("Transaction Acknowledgement");
	}
	
	
	
	public String getFromRecieptNum(ArrayList<RegularDemandsDO> list)
	{
		String fromReceiptNumber = null;
		String from[] = new String[list.size()];
		for(int i=0 ; i< list.size(); i++)
		{
			 from[i] = list.get(i).ReciptNumber.split("-")[4];
		}
		
		
		int smallest = Integer.parseInt(from[0]);
       
        for(int i=1; i< from.length; i++)
        {
            if (Integer.parseInt(from[i]) < smallest)
            {
                    smallest = Integer.parseInt(from[i]);
                    fromReceiptNumber = list.get(i).ReciptNumber;
            }
        }
        
        
        for(int i=0 ; i< list.size(); i++)
		{
			 String rNo = list.get(i).ReciptNumber.split("-")[4];
			 if(Integer.parseInt(rNo) == smallest)
			 {
				 fromReceiptNumber = list.get(i).ReciptNumber;
			 }
		}
        
        return fromReceiptNumber;
	}
	
	public String getToRecieptNum(ArrayList<RegularDemandsDO> list)
	{
		String toReceiptNumber = null;
		String from[] = new String[list.size()];
		for(int i=0 ; i< list.size(); i++)
		{
			 from[i] = list.get(i).ReciptNumber.split("-")[4];
		}
		
		
		int smallest = Integer.parseInt(from[0]);
        int largetst = Integer.parseInt(from[0]);
       
        for(int i=1; i< from.length; i++)
        {
                if(Integer.parseInt(from[i]) > largetst)
                {
                        largetst = Integer.parseInt(from[i]);
                        toReceiptNumber = list.get(i).ReciptNumber;
                }
                else if (Integer.parseInt(from[i]) < smallest)
                {
                        smallest = Integer.parseInt(from[i]);
                }
               
        }
        
        return toReceiptNumber;
	}

	
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if(keyCode == KeyEvent.ACTION_DOWN)
		{
			return false;
		}
		else
		{
			return true;
		}
		
	}
    

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == AppConstants.RESULTCODE_LOGOUT)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_HOME)
		{
			setResult(resultCode);
			finish();
		}
	}

	@Override
	public PrintDetailsDO getprintObject() {
		// TODO Auto-generated method stub
		PrintValues printValues = new PrintValues();
		IntialParametrsDO intialParametrsDO = alIntialParametrsDOs.get(0);
		NPSDemandBL npsDemandsBl=new NPSDemandBL();
		ArrayList<NPSDemandDO> alDos = npsDemandsBl.SelectGroups(CenterCode);
		if(intialParametrsDO.IndividualReceipts.equalsIgnoreCase("1")){
			for(int i =0 ; i < alDos.size(); i++ )
			{
				NPSDemandBL npsDemandsBl1=new NPSDemandBL();
				ArrayList<NPSDemandDO> alArrayList = npsDemandsBl1.SelectAllTransactions(LastTranScode);
				for(int j=0 ; j <alArrayList.size(); j++ ){
					NPSDemandDO obj=alArrayList.get(i);
					NPSDemandDO obj1=npsDemandsBl1.SelectAll(obj.MLAI_ID, "member").get(0);
//					String CollAmt=npsDemandsBl1.getCollectedAmtForMember(obj.MLAI_ID);
					String header=intialParametrsDO.ReceiptHeader;
		            String[] head = header.split("@");
		            String head1=head[0];
		            String head2=head[1];
		            String head3=head[2];
					printValues.add(head1,"true");
					String recnum=StringUtils.getRecieptNumberForNPS(obj);
		            if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head2,"true");
		            }
		             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head3,"true");
		            }
					printValues.add(" ","false");
					if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1"))
					{
					printValues.add("Customer Copy","true");	
					}
					printValues.add("NPS TXN Acknowledgement","true");
					printValues.add("---------------------------","true");
					printValues.add(" ","false");
					printValues.add("R.No:"+recnum,"false");
					printValues.add("Date:"+obj.DemandDT,"false");
					printValues.add(" ","false");
					String URL=SharedPrefUtils.getKeyValue(this, AppConstants.pref_name, AppConstants.UrlAddress);
    				if(URL.equals("Yes"))
    				{
    					printValues.add("Center Name:"+obj1.CName,"false");
						printValues.add("SHG Name:"+obj1.GName,"false");
						printValues.add("Member Name:"+obj.MName+(obj1.MMI_Code),"false");
						if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
    					{
    						printValues.add("Rnwl Installment No:"+obj1.InstallNo,"false");
    					}
    					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
						
					 }
    				 else
					 {
    					 printValues.add("Center:"+obj1.CName,"false");
 						printValues.add("Group:"+obj1.GName,"false");
 						printValues.add("Member:"+obj.MName+"("+obj1.MMI_Code+")","false");
 						printValues.add("Loan A/C No:"+obj.MLAI_ID,"false");
 						if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
     					{
     						printValues.add("Rnwl Installment No:"+obj1.InstallNo,"false");
     					}
     					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
 					}
    				printValues.add(" ","false");
					printValues.add(intialParametrsDO.ReceiptFooter,"true");
				}
				printValues.add(" ","false");
				printValues.add(intialParametrsDO.ReceiptFooter,"true");
				printValues.add(" ","false");
				printValues.add(" ","false");
				printValues.add(" ","false");
			}
			if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1"))
			{
				// print agent copy
				for(int i=0 ; i <alDos.size(); i++ )
				{
					NPSDemandDO obj=alArrayList.get(i);
					NPSDemandBL npsDemandsBl1= new NPSDemandBL();
					NPSDemandDO npsDemandsDo=npsDemandsBl1.SelectAll(obj.MLAI_ID, "member").get(0);
//					String CollAmt=npsDemandsBl.getCollectedAmtForMember(obj.MLAI_ID);
					String header=intialParametrsDO.ReceiptHeader;
		            String[] head = header.split("@");
		            String head1=head[0];
		            String head2=head[1];
		            String head3=head[2];
					printValues.add(head1,"true");
					String reciptNum=StringUtils.getRecieptNumberForNPS(obj);
//		            Log.d("mfimo", reciptNum);
		            if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head2,"true");
		            }
		             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
		            { }
		            else
		            {
		            	printValues.add(head3,"true");
		            }
					printValues.add(" ","false");
					printValues.add("Agent Copy","true");	
					printValues.add("NPS TXN Acknowledgement","true");
					printValues.add("---------------------------","true");
					printValues.add(" ","false");
					printValues.add("R.No:"+reciptNum,"false");
					printValues.add("Date:"+obj.DemandDT,"false");
					printValues.add(" ","false");
					String URL=SharedPrefUtils.getKeyValue(this, AppConstants.pref_name, AppConstants.UrlAddress);
    				if(URL.equals("Yes"))
    				{
    					printValues.add("Center Name:"+npsDemandsDo.CName,"false");
    					printValues.add("SHG Name:"+npsDemandsDo.GName,"false");
    					printValues.add("Member Name:"+obj.MName+"("+npsDemandsDo.MMI_Code+")","false");
    					if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
    					{
    						printValues.add("Rnwl Installment No:"+npsDemandsDo.InstallNo,"false");
    					}
    					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
//    					float DmdTot=Float.valueOf(regularDemandsDO.DemandTotal)+Float.valueOf(regularDemandsDO.ODAmount);
//    					printValues.add("Planned Savings:"+DmdTot,"false");
//    					printValues.add("Savings Collected:"+obj.collectedAmount,"false");
    					printValues.add(" ","false");
    					printValues.add("Total Group Rnwl Amount:"+RenewalAmt,"false");
    					printValues.add("Total Group Coll Amount:"+collectedAmt,"false");
    					printValues.add("Next Installment Date:"+alArrayList.get(0).NextPayDate,"false");
    				}
    				else
    				{
    					printValues.add("Center:"+npsDemandsDo.CName,"false");
    					printValues.add("Group:"+npsDemandsDo.GName,"false");
    					printValues.add("Member:"+obj.MName+"("+npsDemandsDo.MMI_Code+")","false");
    					if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
    					{
    						printValues.add("Rnwl Installment No:"+npsDemandsDo.InstallNo,"false");
    					}
    					printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
    					printValues.add(" ","false");
    					printValues.add("Total Group Rnwl Amount:"+RenewalAmt,"false");
    					printValues.add("Total Group Coll Amount:"+collectedAmt,"false");
    					printValues.add("Next Installment Date:"+alArrayList.get(0).NextPayDate,"false");
//    					printValues.add("Next Installment Date:"+npsDemandsDo.NextRepayDate,"false");
//    					float DmdTot=Float.valueOf(npsDemandsDo.DemandTotal)+Float.valueOf(regularDemandsDO.ODAmount);
//    					printValues.add("Demand:"+DmdTot,"false");
//    					printValues.add("collection Amt:"+obj.collectedAmount,"false");
//    					float OSAmt=Float.valueOf(obj.OSAmt)-Float.valueOf(CollAmt);
//    					printValues.add("Curr OS(P+I):"+OSAmt,"false");
    				}
					
					printValues.add(" ","false");
					printValues.add(intialParametrsDO.ReceiptFooter,"true");
					printValues.add(" ","false");
					printValues.add(" ","false");
					printValues.add(" ","false");
				}
			}
		}else{
			NPSDemandBL npsbl=new NPSDemandBL();
			ArrayList<NPSDemandDO> objj=npsbl.SelectAll(CenterCode,"Center");
			String URL=SharedPrefUtils.getKeyValue(this, AppConstants.pref_name, AppConstants.UrlAddress);
			String header=intialParametrsDO.ReceiptHeader;
            String[] head = header.split("@");
            String head1=head[0];
            String head2=head[1];
            String head3=head[2];
			printValues.add(head1,"true");
            if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
            { }
            else
            {
            	printValues.add(head2,"true");
            }
             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
            { }
            else
            {
            	printValues.add(head3,"true");
            }
			printValues.add(" ","false");
			if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1"))
			{
			printValues.add("Customer Copy","true");	
			}
			printValues.add("NPS TXN Acknowledgement","true");
			printValues.add("---------------------------","true");
			printValues.add(" ","false");
			if(URL.equals("Yes")){
				for(int i =0 ; i < alDos.size(); i++ ){
					float GroupCollectedAmt= 0, GroupDemandAmt = 0;
					NPSDemandBL npsDemandsBl1= new NPSDemandBL();
					ArrayList<NPSDemandDO> alArrayList = npsDemandsBl1.SelectAllGroupTransactions(LastTranScode, alDos.get(i).GNo);
					if(alArrayList.size()>0)
					{
						String reciptNum=StringUtils.getRecieptNumberForNPS(alArrayList.get(0));
						if(i==0)
						{
							printValues.add("Date : "+alArrayList.get(0).DemandDT,"false");
							printValues.add("R.No:"+reciptNum,"false");
							printValues.add(" ","false");
							printValues.add("Center Name:"+objj.get(0).CName,"false");
							printValues.add(" ","false");
						}
						for(int k=0 ; k <alArrayList.size(); k++ )
						{
							NPSDemandDO obj=alArrayList.get(k);
							NPSDemandBL npsDemandsBL = new NPSDemandBL();
							NPSDemandDO npsDemandsDO = npsDemandsBL.SelectAll(obj.MLAI_ID, "memeber").get(0);
							if(k==0){
								printValues.add("SHG Name:"+npsDemandsDO.GName,"false");
								printValues.add(" ","false");
							}
							printValues.add("Member Name:"+obj.MName+"("+npsDemandsDO.MMI_Code+")","false");
							if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
							{
								printValues.add("Rnwl Installment No:"+npsDemandsDO.InstallNo,"false");
							}
							printValues.add("Next Rnwl Date:"+npsDemandsDO.NextPayDate,"false");
							printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
							printValues.add("Bal. Rnwl/Arrs Amt:"+npsDemandsDO.BalanceAmt,"false");
							GroupCollectedAmt = GroupCollectedAmt+Float.parseFloat(obj.CollectedAmt);
							GroupDemandAmt= GroupDemandAmt+(Float.parseFloat(npsDemandsDO.RenewalAmt));
						}
						printValues.add(" ","false");
						printValues.add("Total SHG Rnwl Amount:"+GroupDemandAmt,"false");
						printValues.add("Total SHG Coll Amount:"+GroupCollectedAmt,"false");
						printValues.add("Next Installment Date:"+objj.get(0).NextPayDate,"false");
					}
					printValues.add("Total Rnwl Amount:"+RenewalAmt,"false");
					printValues.add("Total Coll Amount:"+collectedAmt,"false");
				}
			}else{
				for(int i =0 ; i < alDos.size(); i++ ){
					float GroupCollectedAmt= 0, GroupDemandAmt = 0;
					NPSDemandBL npsDemandsBl1= new NPSDemandBL();
					ArrayList<NPSDemandDO> alArrayList = npsDemandsBl1.SelectAllGroupTransactions(LastTranScode, alDos.get(i).GNo);
					if(alArrayList.size()>0)
					{
						String reciptNum=StringUtils.getRecieptNumberForNPS(alArrayList.get(0));
						if(i==0)
						{
							printValues.add("Date : "+alArrayList.get(0).DemandDT,"false");
							printValues.add("R.No:"+reciptNum,"false");
							printValues.add(" ","false");
							printValues.add("Center:"+objj.get(0).CName,"false");
							printValues.add(" ","false");
						}
						for(int k=0 ; k <alArrayList.size(); k++ )
						{
							NPSDemandDO obj=alArrayList.get(k);
							NPSDemandBL npsDemandsBL = new NPSDemandBL();
							NPSDemandDO npsDemandsDO = npsDemandsBL.SelectAll(obj.MLAI_ID, "memeber").get(0);
							if(k==0){
								printValues.add("Group:"+npsDemandsDO.GName,"false");
								printValues.add(" ","false");
							}
							printValues.add("Member Name:"+obj.MName+"("+npsDemandsDO.MMI_Code+")","false");
							if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
							{
								printValues.add("Rnwl Installment No:"+npsDemandsDO.InstallNo,"false");
							}
							printValues.add("Next Rnwl Date:"+npsDemandsDO.NextPayDate,"false");
							printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
							printValues.add("Bal. Rnwl/Arrs Amt:"+npsDemandsDO.BalanceAmt,"false");
							GroupCollectedAmt = GroupCollectedAmt+Float.parseFloat(obj.CollectedAmt);
							GroupDemandAmt= GroupDemandAmt+(Float.parseFloat(npsDemandsDO.RenewalAmt));
						}
						printValues.add(" ","false");
						printValues.add("Total Group Rnwl Amount:"+GroupDemandAmt,"false");
						printValues.add("Total Group Coll Amount:"+GroupCollectedAmt,"false");
						printValues.add("Next Installment Date:"+objj.get(0).NextPayDate,"false");
					}
				}
			}
			printValues.add(" ","false");
			printValues.add(intialParametrsDO.ReceiptFooter,"true");
			printValues.add("","false");
			printValues.add("","false");
			if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1"))
			{
				printValues.add(head1,"true");
	            if(head2.equals("0")||head2.equals("")||head2.equals("null") || head2.equals("NULL")|| head2.equals("Null"))
	            { }
	            else
	            {
	            	printValues.add(head2,"true");
	            }
	             if(head3.equals("0")||head3.equals("")||head3.equals("null")|| head3.equals("NULL")|| head3.equals("Null"))
	            { }
	            else
	            {
	            	printValues.add(head3,"true");
	            }
				printValues.add(" ","false");
				if(intialParametrsDO.AgentCopy.equalsIgnoreCase("1"))
				{
				printValues.add("Customer Copy","true");	
				}
				printValues.add("NPS TXN Acknowledgement","true");
				printValues.add("---------------------------","true");
				printValues.add(" ","false");
				if(URL.equals("Yes")){
					for(int i =0 ; i < alDos.size(); i++ ){
						float GroupCollectedAmt= 0, GroupDemandAmt = 0;
						NPSDemandBL npsDemandsBl1= new NPSDemandBL();
						ArrayList<NPSDemandDO> alArrayList = npsDemandsBl1.SelectAllGroupTransactions(LastTranScode, alDos.get(i).GNo);
						if(alArrayList.size()>0)
						{
							String reciptNum=StringUtils.getRecieptNumberForNPS(alArrayList.get(0));
							if(i==0)
							{
								printValues.add("Date : "+alArrayList.get(0).DemandDT,"false");
								printValues.add("R.No:"+reciptNum,"false");
								printValues.add(" ","false");
								printValues.add("Center Name:"+objj.get(0).CName,"false");
							}
							for(int k=0 ; k <alArrayList.size(); k++ )
							{
								NPSDemandDO obj=alArrayList.get(k);
								NPSDemandBL npsDemandsBL = new NPSDemandBL();
								NPSDemandDO npsDemandsDO = npsDemandsBL.SelectAll(obj.MLAI_ID, "memeber").get(0);
								printValues.add(" ","false");
								if(k==0)
									printValues.add("SHG Name:"+npsDemandsDO.GName,"false");
								printValues.add(" ","false");
								printValues.add("Member Name:"+obj.MName+"("+npsDemandsDO.MMI_Code+")","false");
								if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
								{
									printValues.add("Rnwl Installment No:"+npsDemandsDO.InstallNo,"false");
								}
								printValues.add("Next Rnwl Date:"+npsDemandsDO.NextPayDate,"false");
								printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
								printValues.add("Bal. Rnwl/Arrs Amt:"+npsDemandsDO.BalanceAmt,"false");
								GroupCollectedAmt = GroupCollectedAmt+Float.parseFloat(obj.CollectedAmt);
								GroupDemandAmt= GroupDemandAmt+(Float.parseFloat(npsDemandsDO.RenewalAmt));
							}
							printValues.add(" ","false");
							printValues.add("Total SHG Rnwl Amount:"+GroupDemandAmt,"false");
							printValues.add("Total SHG Coll Amount:"+GroupCollectedAmt,"false");
							printValues.add("Next Installment Date:"+objj.get(0).NextPayDate,"false");
						}
						printValues.add("Total Rnwl Amount:"+RenewalAmt,"false");
						printValues.add("Total Coll Amount:"+collectedAmt,"false");
					}
				}else{
					for(int i =0 ; i < alDos.size(); i++ ){
						float GroupCollectedAmt= 0, GroupDemandAmt = 0;
						NPSDemandBL npsDemandsBl1= new NPSDemandBL();
						ArrayList<NPSDemandDO> alArrayList = npsDemandsBl1.SelectAllGroupTransactions(LastTranScode, alDos.get(i).GNo);
						if(alArrayList.size()>0)
						{
							String reciptNum=StringUtils.getRecieptNumberForNPS(alArrayList.get(0));
							if(i==0)
							{
								printValues.add("Date : "+alArrayList.get(0).DemandDT,"false");
								printValues.add("R.No:"+reciptNum,"false");
								printValues.add(" ","false");
								printValues.add("Center:"+objj.get(0).CName,"false");
								printValues.add(" ","false");
							}
							for(int k=0 ; k <alArrayList.size(); k++ )
							{
								NPSDemandDO obj=alArrayList.get(k);
								NPSDemandBL npsDemandsBL = new NPSDemandBL();
								NPSDemandDO npsDemandsDO = npsDemandsBL.SelectAll(obj.MLAI_ID, "memeber").get(0);
								if(k==0){
									printValues.add("Group: "+npsDemandsDO.GName,"false");
									printValues.add(" ","false");
								}
								printValues.add("Member Name:"+obj.MName+"("+npsDemandsDO.MMI_Code+")","false");
								if(intialParametrsDO.InstRequired.equalsIgnoreCase("1"))
								{
									printValues.add("Rnwl Installment No:"+npsDemandsDO.InstallNo,"false");
								}
								printValues.add("Next Rnwl Date:"+npsDemandsDO.NextPayDate,"false");
								printValues.add("Rnwl Coll Amt:"+obj.CollectedAmt,"false");
								printValues.add("Bal. Rnwl/Arrs Amt:"+npsDemandsDO.BalanceAmt,"false");
								GroupCollectedAmt = GroupCollectedAmt+Float.parseFloat(obj.CollectedAmt);
								GroupDemandAmt= GroupDemandAmt+(Float.parseFloat(npsDemandsDO.RenewalAmt));
							}
							printValues.add(" ","false");
							printValues.add("Total Group Rnwl Amount:"+GroupDemandAmt,"false");
							printValues.add("Total Group Coll Amount:"+GroupCollectedAmt,"false");
							printValues.add("Next Installment Date:"+objj.get(0).NextPayDate,"false");
						}
					}
				}
				printValues.add(" ","false");
				printValues.add(intialParametrsDO.ReceiptFooter,"true");
				printValues.add("","false");
				printValues.add("","false");
			}
		}
		isPrintTaken = true;
		return printValues.getDetailObj();
	}
}
