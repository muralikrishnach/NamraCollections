package com.jayam.impactapp.database;

import java.util.ArrayList;

import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.RegularDemandsDO;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

public class DemandsTempBL extends BaseBusinessLayer<RegularDemandsDO>
{

	@Override
	public boolean Insert(BaseDO object)
	{

		RegularDemandsDO parametrsDO = (RegularDemandsDO) object;
		
		try
		{
			DatabaseHelper.openDataBase();
		}
		catch (Exception e) 
		{}
		
		ContentValues values = new ContentValues();
		
		
		values.put("MemberCode", parametrsDO.MemberCode);
		values.put("AmountPaid", parametrsDO.MemberCode);
		/*
		Attendense
		MeetingStartTime
		MeetingEndTime
		RecieptNumber
		MLAIID
		GroupCode
		*/
			values.put("CNo", parametrsDO.CNo);
			values.put("CName", parametrsDO.CName);
			values.put("GNo", parametrsDO.GNo);
			values.put("EII_EMP_ID", parametrsDO.EII_EMP_ID);
			values.put("GroupName", parametrsDO.GroupName);
			
			values.put("MemberName", parametrsDO.MemberName);
			values.put("DemandDate", parametrsDO.DemandDate);
			values.put("MLAI_ID", parametrsDO.MLAI_ID);
			values.put("OSAmt", parametrsDO.OSAmt);
			values.put("DemandTotal", parametrsDO.DemandTotal);
			values.put("ODAmount", parametrsDO.ODAmount);
			values.put("Attendance", parametrsDO.Attendance);
			
			
		//CREATE TABLE "RegularDemands" ("CNo" VARCHAR PRIMARY KEY  NOT NULL , "CName" VARCHAR, "GNo" VARCHAR, 
			//"EII_EMP_ID" VARCHAR, "GroupName" VARCHAR, "MemberCode" VARCHAR, "MemberName" VARCHAR, "DemandDate" VARCHAR, 
			//"MLAI_ID" VARCHAR, "OSAmt" VARCHAR, "DemandTotal" VARCHAR, "ODAmount" VARCHAR, "Attendance" VARCHAR)
			
		//edit here
		try
		{
			SQLiteDatabase _database = DatabaseHelper.openDataBase();
			_database.insert("RegularDemands", null, values);
		}
		catch (Exception e) 
		{}
		return false;
	
	}

	@Override
	public boolean Update(BaseDO object) 
	{
		return false;
	}

	@Override
	public boolean Delete(BaseDO object)
	{
		return false;
	}

	@Override
	public ArrayList<RegularDemandsDO> SelectAll() 
	{
		return null;
	}


}
