package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.CustomDailoglistner;
import com.jayam.impactapp.database.IntialParametrsBL;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.NPSDemandDO;
import com.jayam.impactapp.utils.StringUtils;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NPSConfirmationScreen_Centerwise extends Base implements NPSUpdatereciptNumbers
{
	private LinearLayout llConfirmation;
	private TextView tvNPSCenterName, tvNPSCollAmt;
	private String centernumber;
	private Button btnConfirmation;
	String Name,Amount;
	int LastTaxn ;
	private ArrayList<NPSDemandDO> vecNPSDemands;
	@Override
	public void initialize()
	{
		intialControlles();
		Bundle bundle 	= 	getIntent().getExtras();
		Name			=	bundle.getString("Name");
		Amount			=	bundle.getString("Amount");
		centernumber	=	bundle.getString("CenterCode");
		
		
		tvNPSCenterName.setText(""+Name);
		tvNPSCollAmt.setText(""+Amount);
		NPSDemandBL bl = new NPSDemandBL();
		vecNPSDemands  = bl.SelectAllData(centernumber, "CNo");
		
		btnConfirmation.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				showAlertDailog("Are you Sure to submit the Center Detail.", "Yes", "No", new CustomDailoglistner()
				{
					@Override
					public void onPossitiveButtonClick(DialogInterface dialog) 
					{
						dialog.dismiss();
						ShowLoader();
						UpdatereciptNumbers updatereciptNumbers = new  UpdatereciptNumbers(vecNPSDemands, NPSConfirmationScreen_Centerwise.this);
						updatereciptNumbers.start();
					}
					
					@Override
					public void onNegativeButtonClick(DialogInterface dialog) 
					{
						dialog.dismiss();
					}
				});
			}
		});
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent(NPSConfirmationScreen_Centerwise.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
				//finish();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	public void intialControlles()
	{
		llConfirmation			=	(LinearLayout)inflater.inflate(R.layout.npsconfirmation_centerwise, null);
		tvNPSCenterName			=	(TextView)llConfirmation.findViewById(R.id.tvNPSCenterName);
		tvNPSCollAmt			=	(TextView)llConfirmation.findViewById(R.id.tvNPSCollAmt);
		
		btnConfirmation		=	(Button)llConfirmation.findViewById(R.id.btnNPSConfirm);
				
		showHomeIcons();
		llBaseMiddle.addView(llConfirmation, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		tvHeader.setText("Final Confirmation");
		
	}
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == AppConstants.RESULTCODE_LOGOUT)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_HOME)
		{
			setResult(resultCode);
			finish();
		}
	}
	class UpdatereciptNumbers extends Thread
	{
		private ArrayList<NPSDemandDO> alArrayList;
		private NPSUpdatereciptNumbers listner;
		public UpdatereciptNumbers(ArrayList<NPSDemandDO> alArrayList, NPSUpdatereciptNumbers listner) 
		{
			this.alArrayList = alArrayList;
			this.listner =listner;
		}
		@Override
		public void run()
		{
			super.run();
			
			for(int i=0; i< alArrayList.size(); i++)
			{
				NPSDemandBL advanceDemandBL = new NPSDemandBL();
				advanceDemandBL.updateReciptNumbers(alArrayList.get(i).MLAI_ID, StringUtils.getRecieptNumberForNPS(alArrayList.get(i)));
			}
			
			runOnUiThread(new Runnable() 
			{
				@Override
				public void run()
				{
					listner.onUpdateCompleted();
				}
			});
		}
	}
	@Override
	public void onUpdateCompleted() {
		new Thread(new  Runnable() 
		{
			public void run() 
			{
				NPSDemandBL npsDemandBL = new NPSDemandBL();
				
				vecNPSDemands  = npsDemandBL.SelectAll(centernumber, "Center");
				
				//updateTransactionTable(vecAdvanceDemands);
				final IntialParametrsBL intialParametrsBL = new IntialParametrsBL();
				final String LastTranScode= StringUtils.getTransactionCodeForNPS_C(vecNPSDemands.get(0));
				LastTaxn = Integer.parseInt(intialParametrsBL.SelectAll().get(0).LastTransactionCode);
				LastTaxn = LastTaxn+1;
				for(NPSDemandDO  obj : vecNPSDemands)
				{
					String[] id = StringUtils.getRecieptNumberForNPS(obj).split("-");
					
					float AmntC = Float.valueOf(obj.BalanceAmt);
					if(obj.BalanceAmt != null &&  AmntC > 0)
					{
						Log.e("Inserted", "saved");
						intialParametrsBL.updateReceiptNumber(String.valueOf(Integer.parseInt(id[id.length-1])+1).toString());
						npsDemandBL.Insert(obj, StringUtils.getRecieptNumberForNPS(obj),LastTranScode);
						npsDemandBL.updateCollectedAmt(obj.MLAI_ID, obj.CollectedAmt,obj.BalanceAmt);
					}
//					else if(obj.CollectedAmt == null)
//					{
//						Log.e("Inserted", "notsaved");
//						intialParametrsBL.updateReceiptNumber(String.valueOf(Integer.parseInt(id[id.length-1])+1).toString());
//						npsDemandBL.Insert(obj,StringUtils.getRecieptNumberForNPS(obj),LastTranScode);
//					}
//					npsDemandBL.updateCollectedAmt(obj.MLAI_ID, obj.CollectedAmt,obj.BalanceAmt);
				}
				
				intialParametrsBL.updateLastTransctionCode(LastTaxn+"");
				runOnUiThread(new Runnable() {
					public void run() 
					{
						HideLoader();
						
						Intent intent = new Intent(NPSConfirmationScreen_Centerwise.this, NPSTxnAck_CenterWise.class);
						
						intent.putExtra("LastTranScode", LastTranScode);
						intent.putExtra("CenterCode", centernumber);
						startActivityForResult(intent,1234);
					}
				});
			}
		}).start();
		
		
		
	}

	@Override
	public void transactionAdded() {
		// TODO Auto-generated method stub
		
	}

}
interface NPSUpdatereciptNumbers
{
	public abstract void onUpdateCompleted();
	public void transactionAdded();
}

