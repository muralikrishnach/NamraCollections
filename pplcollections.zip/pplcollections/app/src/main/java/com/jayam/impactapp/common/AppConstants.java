package com.jayam.impactapp.common;

public class AppConstants {
    public static String TransactioType = "transtype";
    public static String TransactionCode = "transcode";
    public static int RESULTCODE_LOGOUT = 9087657;
    public static int RESULTCODE_HOME = 93340876;
    public static int RESULTCODE_GROPMEMBERS = 67575;
    public static int RESULTCODE_CENTERDETAILS = 675675;

    public static int RESULTCODE_GROPDETAILS = 6753434;
    public static String username = "username";
    public static String password = "password";
    public static String pref_name = "MfimoPref";
    public static String intialDownload = "Initialdownload";
    public static String DATABASE_NAME = "MFIMO.sqlite";
    public static String DATABASE_PATH = "/data/data/com.jayam.impactapp/";
    public static String printeraddress = "printer";
    public static String UrlAddress = "No";
    public static String FolderName = "mFIMO_Images";

    public static String memberDetails_pref = "MemberDetails";
    public static String amountTobeCollected = "AmountTobeCollected";
    public static String attendense = "attendense";
    public static String meetingStartTime = "MeetingStart";
    public static String meetingEnd = "MeetingEnd";
    public static String attendense_total = "attendense_total";
    public static String macid = "null";

    public static String ADVANCECENTER = "";
    public static String NPSCENTER = "";
    public static int DATABASE_VERSION = 5;
}
