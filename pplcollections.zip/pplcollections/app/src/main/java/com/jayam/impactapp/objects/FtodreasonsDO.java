package com.jayam.impactapp.objects;

public class FtodreasonsDO extends BaseDO{
	public String ID;
	public String FTODReason;

}
