package com.jayam.impactapp.database;

public class DictionaryEntry
{
	public String key;
	public Object value;
}
