package com.jayam.impactapp;

import com.jayam.impactapp.common.AppConstants;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NPSPaymentconfiramtion extends Base
{
	private LinearLayout llPaymentConfirmation;
	private TextView tvMemebrName, tvMemebrCode, tvRenewalDate , tvCollectedAmount;
	private Button btnCenters, btnGroups;
	String paymnet,MemberName,MemberCode,DemandDate;
	@Override
	public void initialize()
	{
		intialControlles();
		Bundle bundle 		= 	getIntent().getExtras();
		
		MemberName			=	bundle.getString("MemberName");
		MemberCode			=	bundle.getString("MemberCode");
		DemandDate			=	bundle.getString("DemandDate");
		paymnet				=	bundle.getString("paymnet");
		
		tvMemebrName.setText(""+MemberName);
		tvMemebrCode.setText(""+MemberCode);
		tvRenewalDate.setText(""+DemandDate);
		tvCollectedAmount.setText(""+paymnet);
		
		btnCenters.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v) 
			{
				setResult(AppConstants.RESULTCODE_CENTERDETAILS);
				finish();
			}
		});
		
		btnGroups.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v) 
			{
				setResult(AppConstants.RESULTCODE_GROPDETAILS);
				finish();
			}
		});
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent(NPSPaymentconfiramtion.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
				//finish();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	public void intialControlles()
	{
		llPaymentConfirmation	=	(LinearLayout)inflater.inflate(R.layout.npspaymentconfiramtion, null);
		tvMemebrName			=	(TextView)llPaymentConfirmation.findViewById(R.id.tvNPSMemebrName);
		tvMemebrCode			=	(TextView)llPaymentConfirmation.findViewById(R.id.tvNPSMemebrCode);
		tvRenewalDate			=	(TextView)llPaymentConfirmation.findViewById(R.id.tvRenewalDate);
		tvCollectedAmount		=	(TextView)llPaymentConfirmation.findViewById(R.id.tvNPSCollectedAmount);
		btnCenters				=	(Button)llPaymentConfirmation.findViewById(R.id.btnCenters);
		btnGroups				=	(Button)llPaymentConfirmation.findViewById(R.id.btnGroups);
		
		String YESNO			=	AppConstants.NPSCENTER;
		Log.e("YESNO:----",YESNO);
		if(YESNO.equals("YES"))
		{
			
		}
		else
		{
			btnCenters.setVisibility(View.GONE);
		}
		showHomeIcons();
        ivLogout.setVisibility(View.GONE);
		llBaseMiddle.addView(llPaymentConfirmation, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		tvHeader.setText("Member Collection");
		
	}
	
	

}

