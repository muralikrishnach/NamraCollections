package com.jayam.impactapp.database;

import java.util.ArrayList;
import java.util.List;

import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.IntialParametrsDO;
import com.jayam.impactapp.objects.LoanProduct;
import com.jayam.impactapp.objects.MasterDataDo;
import com.jayam.impactapp.objects.RepaymentDetails;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class IntialParametrsBL extends BaseBusinessLayer<IntialParametrsDO>
{

	@Override
	public boolean Insert(BaseDO object)
	{
		IntialParametrsDO parametrsDO = (IntialParametrsDO) object;
		
		try
		{
			DatabaseHelper.openDataBase();
		}
		catch (Exception e) 
		{e.printStackTrace();}
		
		ContentValues values = new ContentValues();

			values.put("WorkMode", parametrsDO.WorkMode);
			values.put("TerminalID", parametrsDO.TerminalID);
			values.put("MACID", parametrsDO.MACID);
			values.put("ReceiptHeader", parametrsDO.ReceiptHeader);
			values.put("ReceiptFooter", parametrsDO.ReceiptFooter);
			values.put("PrinterBTAddress", parametrsDO.BTPrinterAddress);
			values.put("AgentCopy", parametrsDO.AgentCopy);
			values.put("DaysOffset", parametrsDO.DaysOffSet);
			values.put("MeetingTime", parametrsDO.MeetingTime);
			values.put("TimeOut", parametrsDO.TimeOut);
			values.put("ServerUrl", parametrsDO.ServerUrl);
			values.put("MaxTransactions", parametrsDO.MaxTransactions);
			values.put("MaxAmount", parametrsDO.MaxAmount);
			values.put("Code", parametrsDO.Code);
			values.put("UserName", parametrsDO.UserName);
			values.put("LastTransactionID", parametrsDO.LastTransactionID);
			values.put("PartialPayment", parametrsDO.PartialPayment);
			values.put("AdvPayment", parametrsDO.AdvPayment);
			values.put("AdvDemandDwds", parametrsDO.AdvDemandDwds);
			values.put("MemberAttendance", parametrsDO.MemberAttendance);
			values.put("IndividualReceipts", parametrsDO.IndividualReceipts);
			values.put("GLI", parametrsDO.GLI);
			values.put("Lateness", parametrsDO.Lateness);
			values.put("GroupPhoto", parametrsDO.GroupPhoto);
			values.put("LastTxnCode", parametrsDO.LastTransactionCode);
			values.put("PrintType", parametrsDO.PrintType);
			values.put("InstRequired", parametrsDO.InstRequired);
			values.put("PhotoNos", parametrsDO.PhotoNos);
			values.put("ValidatePrinter", parametrsDO.ValidatePrinter);
			values.put("PrintValidate", parametrsDO.PrintValidate);
			values.put("LogoPrinting", parametrsDO.LogoPrinting);
			values.put("QOM", parametrsDO.qom);
			values.put("ProbInCenter", parametrsDO.probInCenter);
			values.put("GroupDiscipline", parametrsDO.groupDiscipline);
			values.put("CollExp", parametrsDO.collExp);
			values.put("CollExpRMEL", parametrsDO.collExpRMEL);
			values.put("CollPlace", parametrsDO.collPlace);
			values.put("RepaymentMadeBy", parametrsDO.repaymentMadeBy);
			values.put("RmelUser", parametrsDO.rmelUser);

		values.put("BranchName", parametrsDO.BranchName);
		values.put("UserId", parametrsDO.UserID);
			Log.d("mfimo", parametrsDO.qom+"asdfds "+parametrsDO.probInCenter+"adfasf "+parametrsDO.groupDiscipline+"dfdfd "+parametrsDO.collExp+""+parametrsDO.collExpRMEL+""+parametrsDO.collPlace+""+parametrsDO.repaymentMadeBy);
		//edit here
		try
		{
			SQLiteDatabase _database = DatabaseHelper.openDataBase();
			_database.insert("Intialparameters", null, values);
		}
		catch (Exception e) 
		{e.printStackTrace();}
		return false;
	}

	@Override
	public boolean Update(BaseDO object) 
	{
		return false;
	}

	public void updateReceiptNumber(String reciptNumber)
	{

		String query = "UPDATE Intialparameters SET LastTransactionID= '"+reciptNumber+"'";
		 Log.e("updatequery", query);
		 SQLiteDatabase objSqliteDB = null;
		 try
			{
				objSqliteDB = DatabaseHelper.openDataBase();
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		 finally
			{
				if(objSqliteDB != null)
				{
					objSqliteDB.setTransactionSuccessful();
					objSqliteDB.endTransaction();
					objSqliteDB.close();
				}
			}
	
	}
	
	public void updateLastTransctionCode(String TxnNumber)
	{

		String query = "UPDATE Intialparameters SET LastTxnCode= '"+TxnNumber+"'";
		 Log.e("updatequery", query);
		 SQLiteDatabase objSqliteDB = null;
		 try
			{
				objSqliteDB = DatabaseHelper.openDataBase();
				objSqliteDB.beginTransaction();	
				SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
				sqLiteStatement.executeInsert();
				
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		 finally
			{
				if(objSqliteDB != null)
				{
					objSqliteDB.setTransactionSuccessful();
					objSqliteDB.endTransaction();
					objSqliteDB.close();
				}
			}
	
	}
	
	@Override
	public boolean Delete(BaseDO object)
	{
		
			try 
		  {
		   DatabaseHelper._database.execSQL("DELETE  FROM Intialparameters" );
		  } 
		  catch (Exception e) 
		  {  
			  Log.e("error occured while deleting data from table",e.toString());
		  }
		return false;
	}

	@Override
	public ArrayList<IntialParametrsDO> SelectAll()
	{

		ArrayList<IntialParametrsDO> vecIntialParams = new ArrayList<IntialParametrsDO>();
		  SQLiteDatabase _database = DatabaseHelper.openDataBase();
		  Cursor c = null;
		  try 
		  {
		   c= _database.rawQuery("select * from Intialparameters", null);
		   
		   if(vecIntialParams != null)
		    vecIntialParams.clear();
		   
		   if(c.moveToFirst())
		   {
		    do
		    {
		    	
		    	IntialParametrsDO obj = new IntialParametrsDO();
		    	obj.WorkMode 			= c.getString(0);
		    	obj.TerminalID 			= c.getString(1);
		    	obj.MACID 				= c.getString(2);
		    	obj.ReceiptHeader 		= c.getString(3);
		    	obj.ReceiptFooter 		= c.getString(4);
		    	obj.BTPrinterAddress 	= c.getString(5);
		    	obj.AgentCopy 			= c.getString(6);
		    	obj.DaysOffSet 			= c.getString(7);
		    	obj.MeetingTime 		= c.getString(8);
		    	obj.TimeOut 			= c.getString(9);
		    	obj.ServerUrl 			= c.getString(10);
		    	obj.MaxTransactions 	= c.getString(11);
		    	obj.MaxAmount 			= c.getString(12);
		    	obj.Code 				= c.getString(13);
		    	obj.UserName 			= c.getString(14);
		    	obj.LastTransactionID 	= c.getString(15);
		    	obj.PartialPayment 		= c.getString(16);
		    	obj.AdvPayment 			= c.getString(17);
		    	obj.AdvDemandDwds 		= c.getString(18);
		    	obj.MemberAttendance 	= c.getString(19);
		    	obj.IndividualReceipts 	= c.getString(20);
		    	obj.GLI 				= c.getString(21);
		    	obj.Lateness 			= c.getString(22);
		    	obj.GroupPhoto 			= c.getString(23);
		    	obj.LastTransactionCode = c.getString(24);
		    	obj.PrintType			= c.getString(25);
		    	obj.InstRequired		= c.getString(26);
		    	obj.PhotoNos			= c.getString(27);
		    	obj.ValidatePrinter		= c.getString(28);
		    	obj.PrintValidate		= c.getString(29);
		    	obj.LogoPrinting		= c.getString(30);
		    	obj.qom					= c.getString(31);
		    	obj.probInCenter		= c.getString(32);
		    	obj.groupDiscipline		= c.getString(33);
		    	obj.collExp				= c.getString(34);
		    	obj.collExpRMEL			= c.getString(35);
		    	obj.collPlace			= c.getString(36);
		    	obj.repaymentMadeBy		= c.getString(37);
		    	obj.rmelUser			= c.getString(38);
				obj.BranchName			= c.getString(39);
				obj.UserID			= c.getString(40);
		     vecIntialParams.add(obj);
		    	
		    	
//				CREATE TABLE "Intialparameters" ("WorkMode" VARCHAR, "TerminalID" VARCHAR, "MACID" VARCHAR PRIMARY KEY  NOT NULL ,
//				"ReceiptHeader" VARCHAR, "ReceiptFooter" VARCHAR, "PrinterBTAddress" VARCHAR, "AgentCopy" VARCHAR, 
//				"DaysOffset" VARCHAR, "MeetingTime" VARCHAR, "TimeOut" VARCHAR, "ServerUrl" VARCHAR, "MaxTransactions"
//				VARCHAR, "MaxAmount" VARCHAR, "Code" VARCHAR, "UserName" VARCHAR, "LastTransactionID" VARCHAR, 
//				"PartialPayment" VARCHAR, "AdvPayment" VARCHAR, "AdvDemandDwds" VARCHAR, "MemberAttendance" VARCHAR, 
//				"IndividualReceipts" VARCHAR)
		    }
		    while(c.moveToNext());
		    c.close();
		   }
		  }
		  catch (Exception e)
		  {
		   e.printStackTrace();
		  }
		  
		  finally{
			  if(c != null )
			  c.close(); 
		  }
		  return vecIntialParams;
	}

	public ArrayList<RepaymentDetails> SelectAllRepayment()
	{

		ArrayList<RepaymentDetails> vecIntialParams = new ArrayList<RepaymentDetails>();
		SQLiteDatabase _database = DatabaseHelper.openDataBase();
		Cursor c = null;
		try
		{
			c= _database.rawQuery("select * from RepaymentDetails", null);

			if(vecIntialParams != null)
				vecIntialParams.clear();

			if(c.moveToFirst())
			{
				do
				{

					RepaymentDetails obj = new RepaymentDetails();
					obj.sno 			= c.getString(0);
					obj.PaidDate 			= c.getString(1);
					obj.Principle 				= c.getString(2);
					obj.Interest 		= c.getString(3);
					obj.Total 		= c.getString(4);

					vecIntialParams.add(obj);

				}
				while(c.moveToNext());
				c.close();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		finally{
			if(c != null )
				c.close();
		}
		return vecIntialParams;
	}
	public void TruncatetabelProduct() {
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;

		query = "DELETE FROM LoanProduct  ";
		Log.e("query", query);
		try {
			objSqliteDB.beginTransaction();
			SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
			sqLiteStatement.executeInsert();
			objSqliteDB.setTransactionSuccessful();
			objSqliteDB.endTransaction();

		} catch (Exception e) {
			e.printStackTrace();
		}
//		if (objSqliteDB != null) {
//			objSqliteDB.close();
//		}

	}

	public void Loanproducttablesave(MasterDataDo masterDataModel)
	{
		List<LoanProduct> center=masterDataModel.getLoanProduct();
		for(int l=0;l<center.size();l++)
		{
			LoanProduct centerv=center.get(l);
			Log.v("","centervname"+centerv.name);
			try {
				DatabaseHelper.openDataBase();
			} catch (Exception e) {
			}
			ContentValues values3 = new ContentValues();
			values3.put("id", centerv.id);
			values3.put("name", centerv.name);



			try {
				SQLiteDatabase _database = DatabaseHelper.openDataBase();
				_database.insert("LoanProduct", null, values3);
			} catch (Exception e) {
			}
		}
	}

	public synchronized ArrayList<BaseDO> getLoanProduct() {

		String query = "SELECT  * from LoanProduct ";

		Log.v("", "getLoanProduct"+query);

		SQLiteDatabase sqLiteDatabase = DatabaseHelper.openDataBase();
		Cursor c = null;
		ArrayList<BaseDO> alArrayList = new ArrayList<BaseDO>();
		try {
			c = sqLiteDatabase.rawQuery(query, null);
			if (c.moveToFirst()) {
				do {
					BaseDO baseDO = new BaseDO();
					baseDO.id = c.getString(0);
					baseDO.name = c.getString(1);


					alArrayList.add(baseDO);


				} while (c.moveToNext());
				c.close();
			}
		} catch (Exception exception) {

		}

		return alArrayList;
	}



	public void deleteBorrowersearch() {
		SQLiteDatabase objSqliteDB = null;
		objSqliteDB = DatabaseHelper.openDataBase();
		String query = null;

		query = "DELETE FROM RepaymentDetails  ";
		Log.e("query", query);
		try {
			objSqliteDB.beginTransaction();
			SQLiteStatement sqLiteStatement = objSqliteDB.compileStatement(query);
			sqLiteStatement.executeInsert();
			objSqliteDB.setTransactionSuccessful();
			objSqliteDB.endTransaction();

		} catch (Exception e) {
			e.printStackTrace();
		}
//		if (objSqliteDB != null) {
//			objSqliteDB.close();
//		}

	}


	public void Repaymentsave(MasterDataDo masterDataModel)
	{
		List<RepaymentDetails> center=masterDataModel.getRepaymentDetails();
		for(int l=0;l<center.size();l++)
		{
			RepaymentDetails centerv=center.get(l);
			try {
				DatabaseHelper.openDataBase();
			} catch (Exception e) {
			}
			ContentValues values3 = new ContentValues();
			values3.put("sno", centerv.sno);
			values3.put("PaidDate", centerv.PaidDate);
			values3.put("Principle", centerv.Principle);
			values3.put("Interest", centerv.Interest);
			values3.put("Total", centerv.Total);



			try {
				SQLiteDatabase _database = DatabaseHelper.openDataBase();
				_database.insert("RepaymentDetails", null, values3);
			} catch (Exception e) {
			}
		}
	}
}
