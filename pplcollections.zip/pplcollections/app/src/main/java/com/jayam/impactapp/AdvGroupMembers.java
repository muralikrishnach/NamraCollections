package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.adapters.AdvGroupMembersAdapter;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.database.AdvanceDemandBL;
import com.jayam.impactapp.objects.AdvaceDemandDO;


import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ListView;

public class AdvGroupMembers extends Base
{
	private LinearLayout llGroupMembers;
	private ListView lvGroupMembers;
	private String groupnumber;
	private AdvGroupMembersAdapter groupMembersAdapter;
	private AdvanceDemandBL  advanceDemandsBL;;
	@Override
	public void initialize()
	{
		groupnumber		=	 getIntent().getExtras().getString("groupnumber");
		intializeControlles();

		advanceDemandsBL = new AdvanceDemandBL();
		ArrayList<AdvaceDemandDO> alAdvanceDemandsDOs = advanceDemandsBL.SelectAll(groupnumber,"Groups");
		groupMembersAdapter.refresh(alAdvanceDemandsDOs);
		
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent(AdvGroupMembers.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
				//finish();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llGroupMembers		=	(LinearLayout)inflater.inflate(R.layout.centers, null);
		lvGroupMembers		=	(ListView)llGroupMembers.findViewById(R.id.lvCenters);
		
		groupMembersAdapter = new AdvGroupMembersAdapter(AdvGroupMembers.this, null);
		lvGroupMembers.setAdapter(groupMembersAdapter);
		svBase.setVisibility(View.GONE);
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llGroupMembers, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		showHomeIcons();
        ivLogout.setVisibility(View.GONE);
		tvHeader.setText("Group Members");
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == AppConstants.RESULTCODE_GROPDETAILS)
		{
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_LOGOUT)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_HOME)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_CENTERDETAILS)
		{
			setResult(resultCode);
			finish();
		}
		
		
	}
	
	

}
