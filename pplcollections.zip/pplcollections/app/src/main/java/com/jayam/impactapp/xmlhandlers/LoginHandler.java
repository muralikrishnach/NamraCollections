package com.jayam.impactapp.xmlhandlers;

public class LoginHandler extends BaseHandler
{

	@Override
	public Object getData()
	{
		return null;
	}

	@Override
	public boolean getExecutionStatus() 
	{
		return false;
	}

	@Override
	public String getErrorMessage() 
	{
		return null;
	}

}
