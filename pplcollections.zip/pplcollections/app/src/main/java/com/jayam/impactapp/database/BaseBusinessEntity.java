package com.jayam.impactapp.database;

public class BaseBusinessEntity 
{

}
