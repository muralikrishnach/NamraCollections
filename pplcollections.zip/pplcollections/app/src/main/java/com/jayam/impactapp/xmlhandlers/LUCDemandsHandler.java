package com.jayam.impactapp.xmlhandlers;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.jayam.impactapp.database.LUCDemandsBL;
import com.jayam.impactapp.objects.LucDemandsDO;

public class LUCDemandsHandler extends BaseHandler {

    private StringBuffer appendString;
    private Boolean currentElement = false;
    private ArrayList<LucDemandsDO> alLucDemandsDOs;
    private LucDemandsDO lucDemandsDO;
    LUCDemandsBL lucDemandsBl;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
	// TODO Auto-generated method stub
	currentElement = true;
	appendString = new StringBuffer();
	lucDemandsBl = new LUCDemandsBL();
	if (localName.equalsIgnoreCase("NewDataSet")) {
	    alLucDemandsDOs = new ArrayList<LucDemandsDO>();
	} else if (localName.equalsIgnoreCase("LUCDemands")) {
	    lucDemandsDO = new LucDemandsDO();
	}
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
	// TODO Auto-generated method stub
	currentElement = false;
	if (localName.equalsIgnoreCase("CNo")) {
	    lucDemandsDO.CNo = appendString.toString();
	} else if (localName.equalsIgnoreCase("CName")) {
	    lucDemandsDO.CName = appendString.toString();
	} else if (localName.equalsIgnoreCase("GNo")) {
	    lucDemandsDO.GNo = appendString.toString();
	} else if (localName.equalsIgnoreCase("GName")) {
	    lucDemandsDO.GName = appendString.toString();
	} else if (localName.equalsIgnoreCase("MMI_Code")) {
	    lucDemandsDO.MMI_Code = appendString.toString();
	} else if (localName.equalsIgnoreCase("MName")) {
	    lucDemandsDO.MName = appendString.toString();
	} else if (localName.equalsIgnoreCase("DemandDate")) {
	    lucDemandsDO.DemandDate = appendString.toString();
	} else if (localName.equalsIgnoreCase("LoanID")) {
	    lucDemandsDO.LoanID = appendString.toString();
	} else if (localName.equalsIgnoreCase("LoanAmount")) {
	    lucDemandsDO.LoanAmount = appendString.toString();
	} else if (localName.equalsIgnoreCase("DisbDate")) {
	    lucDemandsDO.DisbDate = appendString.toString();
	} else if (localName.equalsIgnoreCase("PurposeID")) {
	    lucDemandsDO.PurposeID = appendString.toString();
	} else if (localName.equalsIgnoreCase("Purpose")) {
	    lucDemandsDO.Purpose = appendString.toString();
	} else if (localName.equalsIgnoreCase("SittingOrder")) {
	    lucDemandsDO.SittingOrder = appendString.toString();
	} else if (localName.equalsIgnoreCase("SO")) {
	    lucDemandsDO.SO = appendString.toString();
	} else if (localName.equalsIgnoreCase("LUCDemands")) {
	    if (lucDemandsDO != null && lucDemandsDO.MMI_Code != null) {
		lucDemandsBl.Insert(lucDemandsDO);
		alLucDemandsDOs.add(lucDemandsDO);
	    }

	}
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
	// TODO Auto-generated method stub
	if (currentElement) {
	    appendString.append(ch, start, length);
	}
    }

    @Override
    public Object getData() {
	// TODO Auto-generated method stub
	return alLucDemandsDOs;
    }

    @Override
    public boolean getExecutionStatus() {
	// TODO Auto-generated method stub
	if (alLucDemandsDOs != null && alLucDemandsDOs.size() > 0) {
	    return true;
	} else {
	    return false;
	}
    }

    @Override
    public String getErrorMessage() {
	// TODO Auto-generated method stub
	return "No LUC Demands Available";
    }

}
