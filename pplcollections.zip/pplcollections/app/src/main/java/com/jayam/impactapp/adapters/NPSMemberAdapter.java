package com.jayam.impactapp.adapters;

import java.util.List;

import com.jayam.impactapp.NPSMemberDetails;
import com.jayam.impactapp.R;
import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.NPSDemandDO;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

public class NPSMemberAdapter extends GenericAdapter {

    public NPSMemberAdapter(Context context, List<? extends BaseDO> listItems) {
	super(context, listItems);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
	NPSDemandDO npsDemandsDO = (NPSDemandDO) getList().get(position);
	convertView = getLayoutInflater().inflate(R.layout.center_cell, null);
	TextView tvCenterName = (TextView) convertView.findViewById(R.id.tvCenterName);

	tvCenterName.setText("" + npsDemandsDO.MName);

	Log.e("position", "" + position);
	convertView.setTag(npsDemandsDO);
	convertView.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		NPSDemandDO npsDemandsDO = (NPSDemandDO) v.getTag();
		Intent intent = new Intent(mContext, NPSMemberDetails.class);
		intent.putExtra("MLAID", npsDemandsDO.MLAI_ID);
		((Activity) (mContext)).startActivityForResult(intent, 0);
	    }
	});
	return convertView;
    }

}
