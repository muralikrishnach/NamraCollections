package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.CustomDailoglistner;
import com.jayam.impactapp.database.LUCDemandsBL;
import com.jayam.impactapp.objects.LucDemandsDO;


import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

public class LUCCapture extends Base {

    private LinearLayout llCapture, llLUCReason, llLUCRemark;
    private TextView tvLoanAmount, tvLoanID, tvDisbursementDate, tvLoanPurpose;
    private RadioGroup rgLUCResult, rgLUCReason;
    private RadioButton rbConsumption, rbIncGen, rbPass, rbFail;
    private View view1;
    private EditText etLUCRemark;
    private Button btnSave;
    public String MNo, result = null, reason = null, remark = null;
    private ArrayList<LucDemandsDO> alLUCDemandsDOs;
    private LUCDemandsBL lucDemandsBL;

    @Override
    public void initialize() {
	// TODO Auto-generated method stub
	MNo = getIntent().getExtras().getString("membernumber");
	intializeControlles();
	lucDemandsBL = new LUCDemandsBL();
	alLUCDemandsDOs = lucDemandsBL.SelectMemberDetails(MNo);
	tvLoanAmount.setText(alLUCDemandsDOs.get(0).LoanAmount);
	tvLoanID.setText(alLUCDemandsDOs.get(0).LoanID);
	tvDisbursementDate.setText(alLUCDemandsDOs.get(0).DisbDate);
	tvLoanPurpose.setText(alLUCDemandsDOs.get(0).Purpose);
	rgLUCResult.setOnCheckedChangeListener(new OnCheckedChangeListener() {

	    @Override
	    public void onCheckedChanged(RadioGroup arg0, int arg1) {
		// TODO Auto-generated method stub
		if (arg1 == R.id.rbPass) {
		    result = "P";
		    llLUCReason.setVisibility(View.INVISIBLE);
		    llLUCRemark.setVisibility(View.INVISIBLE);
		    view1.setVisibility(View.INVISIBLE);
		} else if (arg1 == R.id.rbFail) {
		    result = "F";
		    llLUCReason.setVisibility(View.VISIBLE);
		    llLUCRemark.setVisibility(View.VISIBLE);
		    view1.setVisibility(View.VISIBLE);
		}
	    }
	});

	rgLUCReason.setOnCheckedChangeListener(new OnCheckedChangeListener() {

	    @Override
	    public void onCheckedChanged(RadioGroup group, int checkedId) {
		// TODO Auto-generated method stub
		if (checkedId == R.id.rbConsumption) {
		    reason = "C";
		} else if (checkedId == R.id.rbIncGen) {
		    reason = "I";
		}
	    }
	});

	btnSave.setOnClickListener(new OnClickListener() {

	    @Override
	    public void onClick(View v) {
		// TODO Auto-generated method stub
		if (result == null) {
		    showAlertDailog("Please Select LUC Result");
		} else if (result.equalsIgnoreCase("F") && reason == null) {
		    showAlertDailog("Please Select LUC Reason");
		} else {
		    showAlertDailog("Are you sure you want to Confirm!", "Yes", "Cancel", new CustomDailoglistner() {

			@Override
			public void onPossitiveButtonClick(DialogInterface dialog) {
			    // TODO Auto-generated method stub
			    dialog.dismiss();
			    remark = etLUCRemark.getText().toString().trim();
			    if (remark.equalsIgnoreCase("")) {
				remark = "null";
			    }
			    Log.d("mfimo", "result: " + result + " reason:" + reason + " remark:" + remark);
			    lucDemandsBL.updateConfirm(result, reason, remark, MNo);
			    if (lucDemandsBL.getConfirmedStatus(MNo).equalsIgnoreCase("yes")) {
				Intent intent = new Intent(LUCCapture.this, LUCConfirmation.class);
				intent.putExtra("membernumber", MNo);
				startActivityForResult(intent, 0);
			    }
			}

			@Override
			public void onNegativeButtonClick(DialogInterface dialog) {
			    // TODO Auto-generated method stub
			    dialog.dismiss();
			}
		    });
		}
	    }
	});

	ivHome.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		setResult(AppConstants.RESULTCODE_HOME);
		finish();
	    }
	});

	ivLogout.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		Intent i = new Intent(LUCCapture.this, loginActivity.class);
		startActivity(i);
		// setResult(AppConstants.RESULTCODE_LOGOUT);
		// finish();
	    }
	});
    }

    @SuppressWarnings("deprecation")
    public void intializeControlles() {
	llCapture = (LinearLayout) inflater.inflate(R.layout.luccapture, null);
	llLUCReason = (LinearLayout) llCapture.findViewById(R.id.llLUCReason);
	llLUCRemark = (LinearLayout) llCapture.findViewById(R.id.llLUCRemark);
	tvLoanAmount = (TextView) llCapture.findViewById(R.id.tvLoanAmount);
	tvLoanID = (TextView) llCapture.findViewById(R.id.tvLoanID);
	tvDisbursementDate = (TextView) llCapture.findViewById(R.id.tvDisbursementDate);
	tvLoanPurpose = (TextView) llCapture.findViewById(R.id.tvLoanPurpose);
	rgLUCResult = (RadioGroup) llCapture.findViewById(R.id.rgLUCResult);
	rgLUCReason = (RadioGroup) llCapture.findViewById(R.id.rgLUCReason);
	rbConsumption = (RadioButton) llCapture.findViewById(R.id.rbConsumption);
	rbIncGen = (RadioButton) llCapture.findViewById(R.id.rbIncGen);
	rbPass = (RadioButton) llCapture.findViewById(R.id.rbPass);
	rbFail = (RadioButton) llCapture.findViewById(R.id.rbFail);
	view1 = llCapture.findViewById(R.id.view1);
	etLUCRemark = (EditText) llCapture.findViewById(R.id.etLUCRemark);
	btnSave = (Button) llCapture.findViewById(R.id.btnSave);
	svBase.setVisibility(View.GONE);
	llBaseMiddle_lv.setVisibility(View.VISIBLE);
	llBaseMiddle_lv.addView(llCapture, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
	showHomeIcons();
        ivLogout.setVisibility(View.GONE);
	tvHeader.setText("LUC Member Details");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	super.onActivityResult(requestCode, resultCode, data);
	if (resultCode == AppConstants.RESULTCODE_LOGOUT) {
	    setResult(resultCode);
	    finish();
	} else if (resultCode == AppConstants.RESULTCODE_HOME) {
	    setResult(resultCode);
	    finish();
	}
    }

}
