package com.jayam.impactapp.objects;

public class LastReceiptDO extends BaseDO{
	public String LastTxnId;
	public String Print;
	public String Type;

}
