package com.jayam.impactapp.adapters;

import java.util.List;

import com.jayam.impactapp.LUCMembers;
import com.jayam.impactapp.R;
import com.jayam.impactapp.database.LUCDemandsBL;
import com.jayam.impactapp.objects.BaseDO;
import com.jayam.impactapp.objects.LucDemandsDO;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class LUCGroupsAdapter extends GenericAdapter {

    public LUCGroupsAdapter(Context context, List<? extends BaseDO> listItems) {
	super(context, listItems);
	// TODO Auto-generated constructor stub
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
	// TODO Auto-generated method stub
	LucDemandsDO regularDemandsDO = (LucDemandsDO) getList().get(position);
	convertView = getLayoutInflater().inflate(R.layout.center_cell, null);
	TextView tvCenterName = (TextView) convertView.findViewById(R.id.tvCenterName);
	ImageView imgConfirmed = (ImageView) convertView.findViewById(R.id.imgConfirmed);
	LUCDemandsBL lucDemandsBL = new LUCDemandsBL();
	if (lucDemandsBL.getConfirmedCount(regularDemandsDO.GNo, "Group").equals("0")) {
	    imgConfirmed.setVisibility(View.VISIBLE);
	} else {
	    imgConfirmed.setVisibility(View.GONE);
	}
	tvCenterName.setText("" + regularDemandsDO.GName + "_" + regularDemandsDO.GNo);
	Log.e("position", "" + position);
	convertView.setTag(regularDemandsDO);
	convertView.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		LucDemandsDO regularDemandsDO = (LucDemandsDO) v.getTag();
		Intent intent = new Intent(mContext, LUCMembers.class);
		intent.putExtra("groupsnumber", regularDemandsDO.GNo);
		((Activity) (mContext)).startActivityForResult(intent, 0);
	    }
	});
	return convertView;
    }
}
