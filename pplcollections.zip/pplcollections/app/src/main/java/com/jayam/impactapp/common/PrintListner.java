package com.jayam.impactapp.common;

import com.jayam.impactapp.objects.PrintDetailsDO;

public interface PrintListner 
{
	public PrintDetailsDO getprintObject();
}
