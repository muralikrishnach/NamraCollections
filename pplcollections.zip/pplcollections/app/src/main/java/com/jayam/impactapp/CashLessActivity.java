package com.jayam.impactapp;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.tapits.fingpay.ScannerScreen;
import com.tapits.fingpay.utils.Constants;
import com.tapits.fingpay.utils.Utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CashLessActivity extends Activity {
    private Context context;

    private EditText merchIdEt, passwordEt, aadhaarEt, mobileEt, amountEt, remarksEt;
    private Button fingPayBtn;
    private TextView respTv, transIdTv;

    private static final int CODE = 1;

    public static final String SUPER_MERCHANT_ID = "2"; // will be given by FingPay send that only from App to SDK
    public static  String TXN_ID = "";
    public String imei = "";


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cashless);

        context = CashLessActivity.this;

        merchIdEt = (EditText) findViewById(R.id.et_merch_id);
        passwordEt = (EditText) findViewById(R.id.et_merch_pin);
        aadhaarEt = (EditText) findViewById(R.id.et_aadhaar);
        mobileEt = (EditText) findViewById(R.id.et_mobile);
        amountEt = (EditText) findViewById(R.id.et_amount);
        remarksEt = (EditText) findViewById(R.id.et_remarks);

        fingPayBtn = (Button) findViewById(R.id.btn_fingpay);
        fingPayBtn.setOnClickListener(listener);


        respTv = (TextView) findViewById(R.id.tv_transaction);
        transIdTv = (TextView) findViewById(R.id.tv_trans_id);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // write code to get permission from user to READ_PHONE_STATE to get imei
        } else {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            imei = telephonyManager.getDeviceId();
            if (!Utils.isValidString(imei))
                imei = Settings.Secure.getString(context.getContentResolver(),
                        Settings.Secure.ANDROID_ID);
        }
    }

    private View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.btn_fingpay:


                    Calendar current = Calendar.getInstance();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    TXN_ID = sdf.format(current.getTime());

                    Log.v("","TXN_ID"+TXN_ID);
                    String merchantId = merchIdEt.getText().toString().trim();
                    String password = passwordEt.getText().toString().trim();
                    String aadhaar = aadhaarEt.getText().toString().trim();
                    String mobile = mobileEt.getText().toString().trim();
                    String amount = amountEt.getText().toString().trim();
                    String remarks = remarksEt.getText().toString().trim();
                    if (isValidString(merchantId)) {
                        if (isValidString(password)) {
//                            if (isValidString(amount)) {
//                                if (isValidString(remarks)) {


                            Utils.dissmissKeyboard(merchIdEt);
                            Intent intent = new Intent(CashLessActivity.this, ScannerScreen.class);
                            intent.putExtra(Constants.MERCHANT_USERID, merchantId);
                            // this MERCHANT_USERID be given by FingPay depending on the merchant, only that value need to sent from App to SDK

                            intent.putExtra(Constants.MERCHANT_PASSWORD, password);
                            // this MERCHANT_PASSWORD be given by FingPay depending on the merchant, only that value need to sent from App to SDK

                            intent.putExtra(Constants.AMOUNT, amount);
                            intent.putExtra(Constants.REMARKS, remarks);

                            intent.putExtra(Constants.AADHAAR_NUMBER, aadhaar);
                            // send a valid 12 digit aadhaar number from the app to SDK

                            intent.putExtra(Constants.MOBILE_NUMBER, mobile);
                            // send a valid 10 digit mobile number from the app to SDK

                            intent.putExtra(Constants.AMOUNT_EDITABLE, false);
                            // send true if Amount can be edited in the SDK or send false then Amount cant be edited in the SDK

                            intent.putExtra(Constants.TXN_ID, TXN_ID);
                            // some dummy value is given in TXN_ID for now but some proper value should come from App to SDK

                            intent.putExtra(Constants.SUPER_MERCHANTID, SUPER_MERCHANT_ID);
                            // this SUPER_MERCHANT_ID be given by FingPay to you, only that value need to sent from App to SDK

                            intent.putExtra(Constants.IMEI, imei);

                            startActivityForResult(intent, CODE);
//                                } else {
//                                    Toast.makeText(context, "Please enter remarks", Toast.LENGTH_SHORT).show();
//                                }
//                            } else {
//                                Toast.makeText(context, "Please enter the amount", Toast.LENGTH_SHORT).show();
//                            }
                        } else {
                            Toast.makeText(context, "Please enter the password", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(context, "Please enter the merchant id", Toast.LENGTH_SHORT).show();
                    }
                    break;


                default:
                    break;
            }
        }
    };

    public static boolean isValidString(String str) {
        if (str != null) {
            str = str.trim();
            if (str.length() > 0)
                return true;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == CODE) {
            String response = data.getStringExtra(Constants.MESSAGE);
//            String transId = data.getStringExtra(Constants.TRANS_ID);
            String bankRrn = data.getStringExtra(Constants.RRN);
            int type = data.getIntExtra(Constants.TRANS_TYPE, Constants.AADHAAR_PAY);
            double transAmount = data.getDoubleExtra(Constants.TRANS_AMOUNT, 0);
            double balAmount = data.getDoubleExtra(Constants.BALANCE_AMOUNT, 0);
            boolean status = data.getBooleanExtra(Constants.TRANS_STATUS, false);
            String transType = "";
            switch (type) {
                case Constants.AADHAAR_PAY:
                    transType = "Aadhaar Pay";
                    break;

                case Constants.UPI:
                    transType = "UPI";
                    break;

                case Constants.UPI_QR:
                    transType = "UPI QR";
                    break;

                case Constants.CASH_WITHDRAWAL:
                    transType = "Cash Withdrawal";
                    break;

                case Constants.CASH_DEPOSIT:
                    transType = "Cash Deposit";
                    break;

                case Constants.BALANCE_ENQUIRY:
                    transType = "Balance Enquiry";
                    break;

                default:
                    break;
            }
            if (isValidString(response)) {
                respTv.setText(response);
                respTv.setVisibility(View.VISIBLE);
                if (type == Constants.BALANCE_ENQUIRY) {
                    if (status && isValidString(bankRrn)) {
                        String s = "Transaction Type : " + transType + "\nTransaction Id : " + bankRrn + "\nBalance Amount : " + balAmount;
                        transIdTv.setText(s);
                        transIdTv.setVisibility(View.VISIBLE);
                    } else
                        transIdTv.setVisibility(View.GONE);
                } else if (type == Constants.UPI || type == Constants.UPI_QR) {
                    if (status && isValidString(bankRrn)) {
                        String s = "Transaction Type : " + transType + "\nTransaction Id : " + bankRrn + "\nTransaction Amount : " + transAmount;
                        transIdTv.setText(s);
                        transIdTv.setVisibility(View.VISIBLE);
                    } else
                        transIdTv.setVisibility(View.GONE);
                } else {
                    if (status && isValidString(bankRrn)) {
                        String s = "Transaction Type : " + transType + "\nTransaction Id : " + bankRrn + "\nTransaction Amount : " + transAmount;
                        transIdTv.setText(s);
                        transIdTv.setVisibility(View.VISIBLE);
                    } else
                        transIdTv.setVisibility(View.GONE);
                }

            }
        } else if (resultCode == RESULT_CANCELED) {
            respTv.setText("");
        }
    }
}
