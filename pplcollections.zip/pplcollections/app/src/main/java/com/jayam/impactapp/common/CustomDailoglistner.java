package com.jayam.impactapp.common;

import android.content.DialogInterface;

public interface CustomDailoglistner 
{
	public void onPossitiveButtonClick(DialogInterface dialog);
	public void onNegativeButtonClick(DialogInterface dialog);
}
