package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.database.LUCDemandsBL;
import com.jayam.impactapp.objects.LucDemandsDO;


import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class LUCConfirmation extends Base {

    private LinearLayout llConfirmation, llLUCReason, llLUCRemark;
    private TextView tvLoanAmount, tvLoanID, tvDisbursementDate, tvLoanPurpose;
    private TextView tvLUCResult, tvLUCReason, tvLUCRemark;
    private View view1;
    private Button btnSave;
    public String MNo;
    private ArrayList<LucDemandsDO> alLUCDemandsDOs;
    private LUCDemandsBL lucDemandsBL;

    @Override
    public void initialize() {
	// TODO Auto-generated method stub
	MNo = getIntent().getExtras().getString("membernumber");
	intializeControlles();
	lucDemandsBL = new LUCDemandsBL();
	alLUCDemandsDOs = lucDemandsBL.SelectMemberDetails(MNo);
	tvLoanAmount.setText(alLUCDemandsDOs.get(0).LoanAmount);
	tvLoanID.setText(alLUCDemandsDOs.get(0).LoanID);
	tvDisbursementDate.setText(alLUCDemandsDOs.get(0).DisbDate);
	tvLoanPurpose.setText(alLUCDemandsDOs.get(0).Purpose);
	if (alLUCDemandsDOs.get(0).Result.equalsIgnoreCase("P")) {
	    tvLUCResult.setText("Pass");
	} else {
	    tvLUCResult.setText("Fail");
	    llLUCReason.setVisibility(View.VISIBLE);
	    view1.setVisibility(View.VISIBLE);
	    llLUCRemark.setVisibility(View.VISIBLE);
	    if (alLUCDemandsDOs.get(0).Reason.equalsIgnoreCase("C")) {
		tvLUCReason.setText("Consumption");
	    } else {
		tvLUCReason.setText("Income Generation");
	    }
	    if (alLUCDemandsDOs.get(0).Remark.equalsIgnoreCase("null")) {
		tvLUCRemark.setText("");
	    } else {
		tvLUCRemark.setText(alLUCDemandsDOs.get(0).Remark);
	    }

	}

	btnSave.setOnClickListener(new OnClickListener() {

	    @Override
	    public void onClick(View v) {
		// TODO Auto-generated method stub
		setResult(AppConstants.RESULTCODE_HOME);
		finish();
	    }
	});

	ivHome.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		setResult(AppConstants.RESULTCODE_HOME);
		finish();
	    }
	});

	ivLogout.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		Intent i = new Intent(LUCConfirmation.this, loginActivity.class);
		startActivity(i);
		// setResult(AppConstants.RESULTCODE_LOGOUT);
		// finish();
	    }
	});
    }

    @SuppressWarnings("deprecation")
    public void intializeControlles() {
	llConfirmation = (LinearLayout) inflater.inflate(R.layout.lucconfirmation, null);
	llLUCReason = (LinearLayout) llConfirmation.findViewById(R.id.llLUCReason);
	llLUCRemark = (LinearLayout) llConfirmation.findViewById(R.id.llLUCRemark);
	tvLoanAmount = (TextView) llConfirmation.findViewById(R.id.tvLoanAmount);
	tvLoanID = (TextView) llConfirmation.findViewById(R.id.tvLoanID);
	tvDisbursementDate = (TextView) llConfirmation.findViewById(R.id.tvDisbursementDate);
	tvLoanPurpose = (TextView) llConfirmation.findViewById(R.id.tvLoanPurpose);
	tvLUCResult = (TextView) llConfirmation.findViewById(R.id.tvLUCResult);
	tvLUCReason = (TextView) llConfirmation.findViewById(R.id.tvLUCReason);
	view1 = llConfirmation.findViewById(R.id.view1);
	tvLUCRemark = (TextView) llConfirmation.findViewById(R.id.tvLUCRemark);
	btnSave = (Button) llConfirmation.findViewById(R.id.btnSave);
	svBase.setVisibility(View.GONE);
	llBaseMiddle_lv.setVisibility(View.VISIBLE);
	llBaseMiddle_lv.addView(llConfirmation, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
	showHomeIcons();
        ivLogout.setVisibility(View.GONE);
	tvHeader.setText("LUC Member Confirmation");
    }
}
