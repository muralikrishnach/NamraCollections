package com.jayam.impactapp.objects;

public class LucDemandsDO extends BaseDO {

    public String CNo;
    public String CName;
    public String GNo;
    public String GName;
    public String MMI_Code;
    public String MName;
    public String DemandDate;
    public String LoanID;
    public String LoanAmount;
    public String DisbDate;
    public String PurposeID;
    public String Purpose;
    public String SittingOrder;
    public String SO;
    public String Reason;
    public String Result;
    public String Remark;
    public String Confirmed;
}
