package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.adapters.NPSGroupsAdapter;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.NPSDemandDO;


import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ListView;

public class NPSGroups extends Base
{
	private LinearLayout llGroups;
	private ListView lvGroups;
	private NPSGroupsAdapter groupsAdapter;
	private String CenterCode;
	private ArrayList<NPSDemandDO> alNPSDemandsDOs;
	private NPSDemandBL  npsDemandsBL;
	@Override
	public void initialize()
	{
		CenterCode		=	getIntent().getExtras().getString("CenterCode");
		intializeControlles();
		npsDemandsBL = new NPSDemandBL();
		alNPSDemandsDOs = npsDemandsBL.SelectGroups(CenterCode);
		groupsAdapter.refresh(alNPSDemandsDOs);
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent( NPSGroups.this,loginActivity.class);
				startActivity(i);
			//	setResult(AppConstants.RESULTCODE_LOGOUT);
				//finish();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llGroups		=	(LinearLayout)inflater.inflate(R.layout.centers, null);
		lvGroups		=	(ListView)llGroups.findViewById(R.id.lvCenters);
		groupsAdapter = new NPSGroupsAdapter(NPSGroups.this, null);
		lvGroups.setAdapter(groupsAdapter);
		svBase.setVisibility(View.GONE);
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llGroups, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		showHomeIcons();
        ivLogout.setVisibility(View.GONE);
		tvHeader.setText("Groups");
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode == AppConstants.RESULTCODE_LOGOUT)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_HOME)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_CENTERDETAILS)
		{
			setResult(resultCode);
			finish();
		}
	}
	
	@Override
	protected void onResume() 
	{
		super.onResume();
		alNPSDemandsDOs = npsDemandsBL.SelectGroups(CenterCode);
		groupsAdapter.refresh(alNPSDemandsDOs);
	}
	

}
