package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.adapters.LUCCenterAdapter;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.database.LUCDemandsBL;
import com.jayam.impactapp.objects.LucDemandsDO;


import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ListView;

public class LUCCenters extends Base {

    private LinearLayout llCenters;
    private ListView lvCenters;
    private LUCDemandsBL lucDemandsBL;
    private ArrayList<LucDemandsDO> alLUCDemandsDOs;
    private LUCCenterAdapter adapter;

    @SuppressWarnings("unchecked")
    @Override
    public void initialize() {
	// TODO Auto-generated method stub
	intializeControlles();
	lucDemandsBL = new LUCDemandsBL();
	alLUCDemandsDOs = lucDemandsBL.SelectAllCenters();
	adapter = new LUCCenterAdapter(LUCCenters.this, alLUCDemandsDOs);
	lvCenters.setAdapter(adapter);

	ivHome.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		setResult(AppConstants.RESULTCODE_HOME);
		finish();
	    }
	});

	ivLogout.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		Intent i = new Intent(LUCCenters.this, loginActivity.class);
		startActivity(i);
		// setResult(AppConstants.RESULTCODE_LOGOUT);
		// finish();
	    }
	});
    }

    @SuppressWarnings("deprecation")
    public void intializeControlles() {
	llCenters = (LinearLayout) inflater.inflate(R.layout.centers, null);
	lvCenters = (ListView) llCenters.findViewById(R.id.lvCenters);
	svBase.setVisibility(View.GONE);
	llBaseMiddle_lv.setVisibility(View.VISIBLE);
	llBaseMiddle_lv.addView(llCenters, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
	showHomeIcons();
        ivLogout.setVisibility(View.GONE);
	tvHeader.setText("LUC Centers");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	super.onActivityResult(requestCode, resultCode, data);
	if (resultCode == AppConstants.RESULTCODE_LOGOUT) {
	    setResult(resultCode);
	    finish();
	} else if (resultCode == AppConstants.RESULTCODE_HOME) {
	    setResult(resultCode);
	    finish();
	}
    }
}
