package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.adapters.AdvGroupsAdapter_Centerwise;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.database.AdvanceDemandBL;
import com.jayam.impactapp.objects.AdvaceDemandDO;


import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ListView;

public class AdvGroups_centerwise extends Base
{
	private LinearLayout llGroups;
	private ListView lvGroups;
	private AdvGroupsAdapter_Centerwise groupsAdapter;
	private String centernuber;
	private ArrayList<AdvaceDemandDO> alAdvanceDemandsDOs;
	private AdvanceDemandBL  advanceDemandsBL;
	@Override
	public void initialize()
	{
		centernuber		=	getIntent().getExtras().getString("centernuber");
		intializeControlles();
		advanceDemandsBL = new AdvanceDemandBL();
		alAdvanceDemandsDOs = advanceDemandsBL.SelectGroups(centernuber);
		groupsAdapter.refresh(alAdvanceDemandsDOs);
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent(AdvGroups_centerwise.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
				//finish();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llGroups		=	(LinearLayout)inflater.inflate(R.layout.centers, null);
		lvGroups		=	(ListView)llGroups.findViewById(R.id.lvCenters);
		groupsAdapter = new AdvGroupsAdapter_Centerwise(AdvGroups_centerwise.this, null);
		lvGroups.setAdapter(groupsAdapter);
		svBase.setVisibility(View.GONE);
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llGroups, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		showHomeIcons();
		tvHeader.setText("Groups");
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode == AppConstants.RESULTCODE_LOGOUT)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_HOME)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_CENTERDETAILS)
		{
			setResult(resultCode);
			finish();
		}
	}
	
	@Override
	protected void onResume() 
	{
		super.onResume();
		alAdvanceDemandsDOs = advanceDemandsBL.SelectGroups(centernuber);
		groupsAdapter.refresh(alAdvanceDemandsDOs);
	}
	

}
