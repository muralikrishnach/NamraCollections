package com.jayam.impactapp.objects;

public class NPSDemandDO extends BaseDO{
	public String CName;
	public String CNo;
	public String GName;
	public String GNo;
	public String MName;
	public String MMI_Code;
	public String MLAI_ID;
	public String Coll;
	public String RenewalAmt;
	public String NextPayDate;
	public String RNo;
	public String DemandDT;
	public String SO;
	public String InstallNo;
	public String NxtRenDate;
	
	public String BalanceAmt;
	public String CollectedAmt;
	public String ReceiptNO;
	public String TXNCode;
	public String DupNo;
	public String PrintFlag;
	public String ActualPrintFlag;

}
