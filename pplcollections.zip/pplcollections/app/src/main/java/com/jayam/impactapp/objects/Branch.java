package com.jayam.impactapp.objects;

public class Branch extends BaseDO {
	public String id="";
	public String name="";
	

}
