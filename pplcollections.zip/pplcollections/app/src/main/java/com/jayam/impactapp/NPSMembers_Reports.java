package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.adapters.NPSMembers_Reports_Adapter;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.NPSDemandDO;


import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ListView;

public class NPSMembers_Reports extends Base
{
	private LinearLayout llCenters;
	private ListView lvCenters;
	private NPSMembers_Reports_Adapter npsGroupAdapter;
	private ArrayList<NPSDemandDO> npsDemandsDO;
	NPSDemandBL advanceDemandsBL;
	String centername = null;
	String GroupCode;
	@Override
	public void initialize() 
	{
		GroupCode		=	getIntent().getExtras().getString("GroupCode");
		intializeControlles();
		
		advanceDemandsBL = new NPSDemandBL();
		npsDemandsDO = advanceDemandsBL.SelectReports_Members(GroupCode);
		
		npsGroupAdapter = new  NPSMembers_Reports_Adapter(NPSMembers_Reports.this, null,npsDemandsDO);
		lvCenters.setAdapter(npsGroupAdapter);
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent(NPSMembers_Reports.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
			//	finish();
			}
		});
		
		
		
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llCenters		=	(LinearLayout)inflater.inflate(R.layout.centers, null);
		lvCenters		=	(ListView)llCenters.findViewById(R.id.lvCenters);
		
		svBase.setVisibility(View.GONE);
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llCenters, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		showHomeIcons();
        ivLogout.setVisibility(View.GONE);
		tvHeader.setText("Centers");
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode == AppConstants.RESULTCODE_LOGOUT)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_HOME)
		{
			setResult(resultCode);
			finish();
		}
			
	}
	
	@Override
	protected void onResume()
	{
		
		super.onResume();
		npsDemandsDO = advanceDemandsBL.SelectReports_Members(GroupCode);
		npsGroupAdapter.refresh(npsDemandsDO);
	}
	
	

}
