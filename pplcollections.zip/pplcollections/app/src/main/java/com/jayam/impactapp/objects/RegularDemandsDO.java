package com.jayam.impactapp.objects;

public class RegularDemandsDO extends BaseDO {

    public String LatitudeCenter;
    public String LongitudeCenter;
    public String LatitudeGroup;
    public String LongitudeGroup;
    public String LatitudeMember;
    public String LongitudeMember;
    public String ProductName="";
    public String DateTime="";
    public String ImageName="";



    public String BranchPaymode;


    public String TXNID;

    public String PaymentMode;

    public String MobileNo;
    public String AAdharNo;

    public String TransactionID;
    public String Status;

    public String CNo;
    public String CName;
    public String GNo;
    public String EII_EMP_ID;
    public String GroupName;
    public String MemberCode;
    public String MemberName;
    public String DemandDate;
    public String MLAI_ID;
    public String OSAmt;
    public String DemandTotal;
    public String ODAmount;
    public String Attendance = "1";
    public String GLI = "0";
    public String Lateness = "0";
    public String updated;
    public String APFlag;
    public String collectedAmount;
    public boolean attended = true;
    public boolean late = false;
    public boolean gli = false;

    public String Confirmed;
    public String ReciptNumber;
    public String savedAmt;

    public String RecieptGenerated;
    public String meetingStartTime;
    public String meetingEndTime;

    public String SittingOrder;
    public String InstallNo;

    public String Print;

    public String TransactionCode;
    public String CollType;

    public String FTODID;
    public String FTODReason;
    public String DemiseDate;

    public String SO;
    public String NextRepayDate;

    public String Renew="";
    public String RenewFeed;

    public String qom;
    public String probInCenter;
    public String groupDiscipline;
    public String collExp;
    public String collExpRMEL;
    public String collPlace;
    public String repaymentMadeBy;

    public String langitude;
    public String latitude;

    public String Overlap_Report_Link;
    public String MMI_Name;
    public String MMI_BrrowerAadhar;
    public String Eamount;
    public String OwnAssociation;
    public String OthersAssociation;
    public String OwnAl;
    public String OthersAl;
    public String OwnDisb;
    public String OthersDisb;
    public String OwnInstl;
    public String Code;
    public String Value;
}
