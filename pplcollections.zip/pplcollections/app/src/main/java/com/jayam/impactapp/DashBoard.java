package com.jayam.impactapp;

import android.bluetooth.BluetoothAdapter;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;

import com.jayam.ODCASHLESSPending;
import com.jayam.impactapp.businesslayer.GetDataBL;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.common.CustomDailoglistner;
import com.jayam.impactapp.common.DataListner;
import com.jayam.impactapp.database.FtodreasonsBL;
import com.jayam.impactapp.database.IntialParametrsBL;
import com.jayam.impactapp.database.LastRecieptBL;
import com.jayam.impactapp.database.Transaction_OD_BL;
import com.jayam.impactapp.objects.IntialParametrsDO;
import com.jayam.impactapp.objects.LastReceiptDO;
import com.jayam.impactapp.utils.PrintUtils;
import com.jayam.impactapp.webacceslayer.ADVRegularScheduleService;
import com.jayam.impactapp.webacceslayer.ODRegularScheduleService;
import com.jayam.impactapp.webacceslayer.RegularScheduleService;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

public class DashBoard extends Base implements DataListner {
    private LinearLayout llDashboard;
    private Button btndash,btnrepayment,btnAdmin, btnTransaction, btndataSync, btnReports, btnUtilities, btnNPSTransaction,
	    btnLastreceiptprint,regularcashless,odcashless,advancecashless;
    private GetDataBL getDataBL, Loginevent, FTODevent;
    LastRecieptBL lastrecieptBL;
    LastReceiptDO LastReceiptDO;
    private String status;
    private ArrayList<IntialParametrsDO> alIntialParametrsDOs;
    private IntialParametrsBL intialParametrsBL;
	Transaction_OD_BL tobl;
    @Override
    public void initialize() {
		tobl=new Transaction_OD_BL();
	intializeControlles();
	// status
	//copyDataBase();
	status = getIntent().getExtras().getString("status");
	Log.d("mfimo", status);
	if (status.equalsIgnoreCase("online")) {
	    // Toast.makeText(DashBoard.this, "Connected To Server",
	    // Toast.LENGTH_SHORT).show();
	    // if(isIntialdownload.equalsIgnoreCase("false"))
	    // {
	    getDataBL = new GetDataBL(DashBoard.this, DashBoard.this);
	    ShowLoader();
	    getDataBL.getIntialParameters();
	    // }
	    // online
	    new Handler().postDelayed(new Runnable() {
		@Override
		public void run() {
		    llBaseMiddle.addView(llDashboard, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		}
	    }, 1500);
	} else {
	    llBaseMiddle.addView(llDashboard, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
	    IntialParametrsBL intialParametrsBL = new IntialParametrsBL();
	    alIntialParametrsDOs = intialParametrsBL.SelectAll();
	    IntialParametrsDO intialParametrsDO = alIntialParametrsDOs.get(0);
	    String print = intialParametrsDO.PrintValidate;
	    if (print.equals("1")) {
		btnLastreceiptprint.setVisibility(View.VISIBLE);
	    } else {
		btnLastreceiptprint.setVisibility(View.GONE);
	    }
	}
	btnAdmin.setOnClickListener(new OnClickListener() {

	    @Override
	    public void onClick(View v) {
		startActivityForResult(new Intent(DashBoard.this, Administration.class), 123);
		overridePendingTransition(R.anim.slide_left, R.anim.slide_right);
	    }
	});

	btnTransaction.setOnClickListener(new OnClickListener() {

	    @Override
	    public void onClick(View v) {
		startActivityForResult(new Intent(DashBoard.this, Transactions.class), 123);
		overridePendingTransition(R.anim.slide_left, R.anim.slide_right);
	    }
	});
	btnNPSTransaction.setOnClickListener(new OnClickListener() {

	    @Override
	    public void onClick(View v) {
		startActivityForResult(new Intent(DashBoard.this, NPSGroupsAndCenters.class), 123);
		overridePendingTransition(R.anim.slide_left, R.anim.slide_right);
	    }
	});
	btndataSync.setOnClickListener(new OnClickListener() {

	    @Override
	    public void onClick(View v) {
		startActivityForResult(new Intent(DashBoard.this, NewDataSync.class), 123);
		overridePendingTransition(R.anim.slide_left, R.anim.slide_right);
	    }
	});

	btnReports.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		startActivityForResult(new Intent(DashBoard.this, Reports.class), 123);
		overridePendingTransition(R.anim.slide_left, R.anim.slide_right);
	    }
	});

	btnUtilities.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		startActivityForResult(new Intent(DashBoard.this, Utilities.class), 123);
		overridePendingTransition(R.anim.slide_left, R.anim.slide_right);
	    }
	});
	btnLastreceiptprint.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {
		LastRecieptBL lastrecieptBL = new LastRecieptBL();
		String count1 = lastrecieptBL.getcount();
		int count = Integer.parseInt(count1);
		if (count > 0) {
		    startActivityForResult(new Intent(DashBoard.this, LastReceiptPrintMenu.class), 123);
		    overridePendingTransition(R.anim.slide_left, R.anim.slide_right);
		} else {
		    showAlertDailog("Data Not Available For Print");
		}
	    }
	});
	ivLogout.setOnClickListener(new OnClickListener() {
	    @Override
	    public void onClick(View v) {

			tobl.TruncatetabelServerUploadData();
		Intent i = new Intent(DashBoard.this, loginActivity.class);
		i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(i);
		// setResult(AppConstants.RESULTCODE_LOGOUT);
		// String logut =
		// Integer.toString(AppConstants.RESULTCODE_LOGOUT);
		// Log.d("mfimo", "logt" + logut);
		// finish();
	    }
	});


		regularcashless.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(DashBoard.this, RegularCbCheck.class);
				i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(i);

			}
		});

		odcashless.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(DashBoard.this, ODCASHLESSPending.class);
				i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(i);

			}
		});

		advancecashless.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(DashBoard.this, AdvanceCashLessPending.class);
				i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(i);

			}
		});

    }

    public static boolean isSdPresent() {
	return android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);
    }

    public void intializeControlles() {
	// tvHeader.setText(getResources().getString(R.string.MainMenu));
	llDashboard = (LinearLayout) inflater.inflate(R.layout.dashboard, null);
	btnAdmin = (Button) llDashboard.findViewById(R.id.btnAdmin);
	btnTransaction = (Button) llDashboard.findViewById(R.id.btnTransaction);
	btndataSync = (Button) llDashboard.findViewById(R.id.btndataSync);
	btnReports = (Button) llDashboard.findViewById(R.id.btnReports);
	btnUtilities = (Button) llDashboard.findViewById(R.id.btnUtilities);
	btnNPSTransaction = (Button) llDashboard.findViewById(R.id.btnNPSTransaction);
	btnLastreceiptprint = (Button) llDashboard.findViewById(R.id.btnLastreceiptprint);
		regularcashless = (Button) llDashboard.findViewById(R.id.btnregularstaus);

		btnrepayment = (Button) llDashboard.findViewById(R.id.btnrepay);
		btndash = (Button) llDashboard.findViewById(R.id.btndash);




		odcashless = (Button) llDashboard.findViewById(R.id.btnodstatus);
		advancecashless = (Button) llDashboard.findViewById(R.id.btnadvancedstatus);
	tvHeader.setText(getResources().getString(R.string.dashboard));
	ivLogout.setVisibility(View.VISIBLE);
	ivHome.setVisibility(View.GONE);

		Intent inte=new Intent(DashBoard.this, RegularScheduleService.class);
		startService(inte);
		Intent odreg=new Intent(DashBoard.this, ODRegularScheduleService.class);
		startService(odreg);
		Intent advsc=new Intent(DashBoard.this, ADVRegularScheduleService.class);
		startService(advsc);

		btnrepayment.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				Intent inten=new Intent(DashBoard.this,MemberViewCycle.class);
				startActivity(inten);
			}
		});

		btndash.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				Intent inten=new Intent(DashBoard.this,CollectionDashbord.class);
				startActivity(inten);
			}
		});
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	super.onActivityResult(requestCode, resultCode, data);
	//copyDataBase();
	Log.v("onActivityResult", "onActivityResult" + resultCode);
	if (resultCode == AppConstants.RESULTCODE_LOGOUT) {
	    finish();
	}
    }

    @Override
    public void onDataretrieved(Object objs) {
	IntialParametrsBL intialParametrsBL = new IntialParametrsBL();
	intialParametrsBL.Delete(null);
	intialParametrsBL.Insert((IntialParametrsDO) objs);
	Log.e("onDataretrieved", "onDataretrieved");
	HideLoader();
	Loginevent = new GetDataBL(DashBoard.this, new DataListner() {
	    @Override
	    public void onDataretrieved(Object objs) {
		Log.e("onDataretrieved- downlaod", "" + objs);
	    }

	    @Override
	    public void onDataretrievalFailed(String errorMessage) {
		Log.e("onDataretrievalFailed - download", "" + errorMessage);
	    }
	});

	alIntialParametrsDOs = intialParametrsBL.SelectAll();
	IntialParametrsDO intialParametrsDO = alIntialParametrsDOs.get(0);
	String TerminalID = intialParametrsDO.TerminalID;
	String printerAddress = intialParametrsDO.BTPrinterAddress;
	String print = intialParametrsDO.PrintValidate;
	String printerValidation = intialParametrsDO.ValidatePrinter;
	Log.d("mfimo", "printerValidation" + printerValidation);
	if (print.equals("1")) {
	    btnLastreceiptprint.setVisibility(View.VISIBLE);
	} else {
	    btnLastreceiptprint.setVisibility(View.GONE);
	}

	if (printerValidation.equals("1")) {
	    BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();
	    if (bluetooth!=null&&bluetooth.isEnabled()) {
		String PAdd = printerAddress;
		// Toast.makeText(getApplicationContext(), PAdd.toString(),
		// Toast.LENGTH_LONG).show();
		String PrinterAddress = null;
		for (int x = 0; x < PAdd.length(); x++) {
		    char PBT = PAdd.charAt(x);
		    if (x == 2 || x == 4 || x == 6 || x == 8 || x == 10) {
			PrinterAddress = PrinterAddress + ":" + String.valueOf(PBT);
		    } else {
			if (x == 0) {
			    PrinterAddress = String.valueOf(PBT);
			} else {
			    PrinterAddress = PrinterAddress + "" + String.valueOf(PBT);
			}

		    }
		}
		
		Log.v("", "printerAddress"+printerAddress);
		Log.v("", "PrinterAddress"+PrinterAddress);
		PrintUtils printUtils = new PrintUtils(DashBoard.this);
		String con = printUtils.getConnection(PrinterAddress);
		// Toast.makeText(getApplicationContext(),
		// con.toString(),Toast.LENGTH_LONG).show();
		// String con=printUtils.getConnection("00:06:66:4D:1B:44");

		Log.v("con", String.valueOf(con));
		if (con.equals("Not Connected")) {
		    showAlertDailog1("PLEASE, SWITCH ON THE PRINTER TO CONTINUE");
		    return;

		}
	    } else {
		showAlertDailog1("Please Switch On Mobile Bluetooth");
		return;
	    }
	}

	// Loginevent = new GetDataBL(DashBoard.this, DashBoard.this);
	// Log.d("mfimo", "check login event start");
	Loginevent.loginEvent(TerminalID, printerAddress);

	FTODevent = new GetDataBL(DashBoard.this, new DataListner() {
	    @Override
	    public void onDataretrieved(Object objs) {
		Log.e("onDataretrieved FTODevent downlaod", "true");
	    }

	    @Override
	    public void onDataretrievalFailed(String errorMessage) {
		Log.e("onDataretrievalFailed FTODevent download", "" + errorMessage);
		showAlertDailog("There are no FTOD Reasons to Download.", "OK", null, new CustomDailoglistner() {

		    @Override
		    public void onPossitiveButtonClick(DialogInterface dialog) {
			dialog.dismiss();
			finish();
		    }

		    @Override
		    public void onNegativeButtonClick(DialogInterface dialog) {
			// TODO Auto-generated method stub

		    }
		});

	    }
	});
	FtodreasonsBL ftodreasonsBL = new FtodreasonsBL();
	ftodreasonsBL.Delete(null);
	// Log.d("mfimo", "ftod reasons start");
	FTODevent.getFTODreasons();
    }

    @Override
    public void onDataretrievalFailed(String errorMessage) {
	HideLoader();
	Log.e("onDataretrievalFailed", "onDataretrievalFailed");
	showAlertDailog("Please Try Again.", "OK", null, new CustomDailoglistner() {

	    @Override
	    public void onPossitiveButtonClick(DialogInterface dialog) {
		dialog.dismiss();
		finish();
	    }

	    @Override
	    public void onNegativeButtonClick(DialogInterface dialog) {
		// TODO Auto-generated method stub

	    }
	});
    }

    public void copyDataBase() {
	Log.d("test", "in copy data base at finally");
	try {
	    File sd = new File(Environment.getExternalStorageDirectory() + "/MFIMO");
	    if (!sd.exists()) {
		sd.mkdirs();
	    }
	    File data = Environment.getDataDirectory();
	    if (sd.canWrite()) {
		String currentDBPath = "/data/" + DashBoard.this.getPackageName() + "/MFIMO.sqlite";
		Log.d("mfimo", "currentDBPath" + currentDBPath);
		String backupDBPath = "MFIMO.sqlite";
		Log.d("mfimo", "backupDBPath" + backupDBPath);
		File currentDB = new File(data, currentDBPath);
		File backupDB = new File(sd, backupDBPath);
		if (currentDB.exists()) {
		    Log.v("", "currentDB.exists()" + currentDB.exists());
		    FileChannel src = new FileInputStream(currentDB).getChannel();
		    FileChannel dst = new FileOutputStream(backupDB).getChannel();
		    dst.transferFrom(src, 0, src.size());
		    src.close();
		    dst.close();
		}
	    }
	} catch (Exception e) {

	    e.printStackTrace();
	    Log.i("info", "in copy of bata base 10 ");

	}
    }

}
