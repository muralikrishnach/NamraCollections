package com.jayam.impactapp;

import java.util.ArrayList;

import com.jayam.impactapp.adapters.NPSGroupsAdapter_CenterWise;
import com.jayam.impactapp.common.AppConstants;
import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.NPSDemandDO;


import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ListView;

public class NPSGroups_CenterWise extends Base
{
	private LinearLayout llGroups;
	private ListView lvGroups;
	private NPSGroupsAdapter_CenterWise groupsAdapter;
	private String centercode;
	private ArrayList<NPSDemandDO> alNPSDemandsDOs;
	private NPSDemandBL  npsDemandsBL;
	@Override
	public void initialize()
	{
		centercode		=	getIntent().getExtras().getString("centercode");
		intializeControlles();
		npsDemandsBL = new NPSDemandBL();
		alNPSDemandsDOs = npsDemandsBL.SelectGroups(centercode);
		groupsAdapter.refresh(alNPSDemandsDOs);
		
		ivHome.setOnClickListener(new  OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				setResult(AppConstants.RESULTCODE_HOME);
				finish();
			}
		});
		
		ivLogout.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent( NPSGroups_CenterWise.this,loginActivity.class);
				startActivity(i);
				//setResult(AppConstants.RESULTCODE_LOGOUT);
				//finish();
			}
		});
	}
	
	@SuppressWarnings("deprecation")
	public void intializeControlles()
	{
		llGroups		=	(LinearLayout)inflater.inflate(R.layout.centers, null);
		lvGroups		=	(ListView)llGroups.findViewById(R.id.lvCenters);
		groupsAdapter = new NPSGroupsAdapter_CenterWise(NPSGroups_CenterWise.this, null);
		lvGroups.setAdapter(groupsAdapter);
		svBase.setVisibility(View.GONE);
		llBaseMiddle_lv.setVisibility(View.VISIBLE);
		llBaseMiddle_lv.addView(llGroups, LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		showHomeIcons();
		tvHeader.setText("Groups");
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode == AppConstants.RESULTCODE_LOGOUT)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_HOME)
		{
			setResult(resultCode);
			finish();
		}
		else if(resultCode == AppConstants.RESULTCODE_CENTERDETAILS)
		{
			setResult(resultCode);
			finish();
		}
	}
	
	@Override
	protected void onResume() 
	{
		super.onResume();
		alNPSDemandsDOs = npsDemandsBL.SelectGroups(centercode);
		groupsAdapter.refresh(alNPSDemandsDOs);
	}
	

}
