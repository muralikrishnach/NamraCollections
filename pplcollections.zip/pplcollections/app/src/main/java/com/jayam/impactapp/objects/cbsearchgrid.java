package com.jayam.impactapp.objects;

/**
 * Created by administrator_pc on 12-03-2018.
 */

public class cbsearchgrid {
    public String Sno;
    public String MMI_ID;
    public String MMI_Name;
    public String MMI_SPOUSE_NAME;
    public String MMI_BrrowerAadhar;
    public String MVI_Id;
    public String MVI_Name;
    public String MCI_Id;
    public String MCI_Name;
    public String MGI_Id;
    public String MGI_Name;
    public String mmi_status;
    public String Overlap_Report_Link;
    public String MMI_FormNO;


    public String Mcode;
    public String Appno;
    public String DisbDate;
    public String LAmount;
    public String NoofInst;
    public String Outstanding;
    public String Stage_name;


    public String Code;
    public String Value;






}
