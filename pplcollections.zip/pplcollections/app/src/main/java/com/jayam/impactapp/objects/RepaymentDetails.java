package com.jayam.impactapp.objects;

/**
 * Created by administrator_pc on 18-02-2020.
 */

public class RepaymentDetails extends BaseDO {
    public String sno="";
    public String PaidDate="";
    public String Principle="";
    public String Interest="";

    public String Total="";




}