package com.jayam.impactapp.xmlhandlers;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

import com.jayam.impactapp.database.NPSDemandBL;
import com.jayam.impactapp.objects.NPSDemandDO;

public class NPSDemandsHandler extends BaseHandler
{
	private StringBuffer appendString;
	private Boolean currentElement = false;
	private ArrayList<NPSDemandDO> alDemandsDOs;
	private NPSDemandDO npsDemandsDO;
	@Override
	public void startElement(String uri, String localName, String qName,Attributes attributes) throws SAXException 
	{
		currentElement = true;
		appendString = new StringBuffer();
		
		if(localName.equalsIgnoreCase("NewDataSet"))
		{
			alDemandsDOs = new ArrayList<NPSDemandDO>();
		}
		else if(localName.equalsIgnoreCase("NPSDmnds"))
		{
			npsDemandsDO = new NPSDemandDO();
		}
		
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException
	{
		currentElement = false;
		
		if(localName.equalsIgnoreCase("CName"))
		{
			npsDemandsDO.CName = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("CNo"))
		{
			npsDemandsDO.CNo = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("GName"))
		{
			npsDemandsDO.GName = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("GNo"))
		{
			npsDemandsDO.GNo = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("MName"))
		{
			npsDemandsDO.MName = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("MMI_Code"))
		{
			npsDemandsDO.MMI_Code = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("MLAI_ID"))
		{
			npsDemandsDO.MLAI_ID = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("Coll"))
		{
			npsDemandsDO.Coll = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("RenewalAmt"))
		{
			npsDemandsDO.RenewalAmt = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("NextPayDate"))
		{
			npsDemandsDO.NextPayDate = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("RNo"))
		{
			npsDemandsDO.RNo = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("DemandDT"))
		{
			npsDemandsDO.DemandDT = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("SO"))
		{
			npsDemandsDO.SO = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("InstallNo"))
		{
			npsDemandsDO.InstallNo = appendString.toString();
		}
		else if(localName.equalsIgnoreCase("NxtRenDate"))
		{
			npsDemandsDO.NxtRenDate = appendString.toString();
		}
		
		else if(localName.equalsIgnoreCase("NPSDmnds"))
		{
			alDemandsDOs.add(npsDemandsDO);
		}
		else if(localName.equalsIgnoreCase("NewDataSet"))
		{
			NPSDemandBL npsDemandsBL = new NPSDemandBL();
			npsDemandsBL.InsertArrayList(alDemandsDOs);
		}
	}
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException 
	{
		if(currentElement)
		{
			appendString.append(ch, start, length);
		}
	}
	
	@Override
	public Object getData() 
	{
		return alDemandsDOs;
	}

	@Override
	public boolean getExecutionStatus()
	{
		if(alDemandsDOs != null && alDemandsDOs.size() > 0)
		return true;
		else return false;
	}

	@Override
	public String getErrorMessage()
	{
		return "error";
	}

}

