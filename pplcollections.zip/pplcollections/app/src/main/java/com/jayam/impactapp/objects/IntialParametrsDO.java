package com.jayam.impactapp.objects;

public class IntialParametrsDO extends BaseDO
{

	public String BranchName="";
	public String UserID="";
	public String WorkMode;
	public String TerminalID;
	public String MACID;
	public String ReceiptHeader;
	public String ReceiptFooter;
	public String BTPrinterAddress;
	public String AgentCopy;
	public String DaysOffSet;
	public String MeetingTime;
	public String TimeOut;
	public String ServerUrl;
	public String MaxTransactions;
	public String MaxAmount;
	public String Code;
	public String UserName;
	public String LastTransactionID;
	public String PartialPayment;
	public String AdvPayment;
	public String AdvDemandDwds;
	public String MemberAttendance;
	public String IndividualReceipts;
	public String GLI;
	public String Lateness;
	public String GroupPhoto;
	public String LastTransactionCode;
	public String PrintType;
	
	public String InstRequired;
	public String PhotoNos;
	public String ValidatePrinter;
	public String PrintValidate;
	public String LogoPrinting;
	
	public String qom;
	public String probInCenter;
	public String groupDiscipline;
	public String collExp;
	public String collExpRMEL;
	public String collPlace;
	public String repaymentMadeBy;
	public String rmelUser;

}


