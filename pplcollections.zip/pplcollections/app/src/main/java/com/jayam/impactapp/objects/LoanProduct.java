package com.jayam.impactapp.objects;

/**
 * Created by administrator_pc on 28-08-2017.
 */

public class LoanProduct extends BaseDO {
    public String id="";
    public String name="";
    public String branchid="";
    public String Modeid="";

    public String ProductType="";

    public String MLP_Min_Amount="";
    public String MLP_Max_Amount="";


}